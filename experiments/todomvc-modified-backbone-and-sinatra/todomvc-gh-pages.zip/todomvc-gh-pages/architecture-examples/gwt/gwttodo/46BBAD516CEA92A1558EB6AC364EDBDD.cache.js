(function(){var $gwt_version = "2.5.0";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $strongName = '46BBAD516CEA92A1558EB6AC364EDBDD';var $stats = $wnd.__gwtStatsEvent ? function(a) {return $wnd.__gwtStatsEvent(a);} : null;var $sessionId = $wnd.__gwtStatsSessionId ? $wnd.__gwtStatsSessionId : null;$stats && $stats({moduleName:'gwttodo',sessionId:$sessionId,subSystem:'startup',evtGroup:'moduleStartup',millis:(new Date()).getTime(),type:'moduleEvalStart'});function W(){}
function RA(){}
function _b(){}
function nc(){}
function kd(){}
function td(){}
function Jd(){}
function Zd(){}
function ge(){}
function Pe(){}
function wf(){}
function mg(){}
function al(){}
function Vl(){}
function Yl(){}
function Fn(){}
function ko(){}
function no(){}
function tp(){}
function Ip(){}
function Kq(){}
function Nq(){}
function Ar(){}
function Dr(){}
function Pr(){}
function Us(){}
function Vt(){}
function ov(){}
function wz(){}
function pp(){op()}
function Tp(){Sp()}
function fv(){ec()}
function xv(){ec()}
function Iv(){ec()}
function Lv(){ec()}
function _v(){ec()}
function Jw(){ec()}
function PA(){ec()}
function uA(){cx(this)}
function vA(){cx(this)}
function Fw(){Dw(this)}
function $y(){Py(this)}
function $e(){this.b=[]}
function de(){this.b={}}
function He(a){this.b=a}
function _e(a){this.b=a}
function eb(a){this.b=a}
function lf(a){this.b=a}
function Bf(a){this.b=a}
function Of(a){this.b=a}
function _l(a){this.b=a}
function pn(a){this.b=a}
function zn(a){this.b=a}
function Cn(a){this.b=a}
function fo(a){this.b=a}
function Ro(a){this.b=a}
function kp(a){this.c=a}
function Bs(a){this.c=a}
function Bt(a){this.b=a}
function Gt(a){this.d=a}
function Uq(a){this.v=a}
function Kr(a){this.v=a}
function Ku(a){this.b=a}
function Vu(a){this.b=a}
function Yu(a){this.b=a}
function iv(a){this.b=a}
function Bv(a){this.b=a}
function Ov(a){this.b=a}
function Ox(a){this.b=a}
function xx(a){this.b=a}
function Ky(a){this.b=a}
function oy(a){this.e=a}
function Mz(a){this.c=a}
function gA(a){this.c=a}
function Ed(a,b){a.c=b}
function Bd(a,b){a.j=b}
function Dd(a,b){a.b=b}
function km(a,b){a.v=b}
function lc(a,b){a.b+=b}
function mc(a,b){a.b+=b}
function Sd(){this.d=++Pd}
function Z(){Z=RA;new ab}
function Zr(){Zr=RA;fs()}
function ir(){ir=RA;nr()}
function ab(){new $y;Gp()}
function zf(){return null}
function _f(){return null}
function ff(a){return a.b}
function pf(a){return a.b}
function Gf(a){return a.b}
function Uf(a){return a.b}
function lg(a){return a.b}
function Ut(a){Xs(a.b,a.c)}
function Ou(a,b){Hs(b,a.j)}
function Ju(a,b){Eu(a.b,b)}
function lm(a,b){pm(a.v,b)}
function mm(a,b){jq(a.v,b)}
function Zm(a,b){Go(a.o,b)}
function Tq(a,b){yc(a.v,b)}
function ce(a,b,c){a.b[b]=c}
function Dw(a){a.b=new nc}
function Aw(){this.b=new nc}
function AA(){this.b=new uA}
function BA(){this.b=new vA}
function ql(){this.b=new Fw}
function Or(){throw new PA}
function Vc(){this.c='NONE'}
function Xc(){this.c='BLOCK'}
function ms(){this.c='LEFT'}
function os(){this.c='RIGHT'}
function ob(a){ec();this.f=a}
function nb(a){ec();this.f=a}
function Tc(){Sc();return Nc}
function dp(){bp();return Zo}
function lp(){jp();return fp}
function gs(){fs();return as}
function vf(){vf=RA;uf=new wf}
function Xb(){Xb=RA;Wb=new _b}
function od(){od=RA;nd=new td}
function op(){op=RA;np=new Sd}
function po(){po=RA;jo=new no}
function Sp(){Sp=RA;Rp=new Sd}
function Zc(){this.c='INLINE'}
function Hc(b,a){b.checked=a}
function zc(b,a){b.tabIndex=a}
function Tm(a,b){gn(a,a.d,b)}
function qs(a,b){ts(a,b,a.d)}
function Aq(a,b){tq(a,b,a.v)}
function Ll(a,b){Rl(a.b,RB,b)}
function Cp(a,b){$p();kq(a,b)}
function Dp(a,b){$p();mq(a,b)}
function lq(a,b){$p();mq(a,b)}
function jq(a,b){$p();kq(a,b)}
function be(a,b){return a.b[b]}
function Ab(b,a){b[b.length]=a}
function Bb(b,a){b[b.length]=a}
function rf(a){nb.call(this,a)}
function sf(a){pb.call(this,a)}
function Ne(a){Ke.call(this,a)}
function Nf(){Of.call(this,{})}
function dr(){W.call(this,Z())}
function $t(a){Ee(a.b,a.d,a.c)}
function $m(a,b,c){Ho(a.o,b,c)}
function Eo(a){$b((Xb(),Wb),a)}
function Gv(a){nb.call(this,a)}
function Jv(a){nb.call(this,a)}
function Mv(a){nb.call(this,a)}
function aw(a){nb.call(this,a)}
function Kw(a){nb.call(this,a)}
function ew(a){Gv.call(this,a)}
function eA(a){Rz.call(this,a)}
function cg(a){throw new rf(a)}
function Yf(a){return new Bf(a)}
function $f(a){return new fg(a)}
function el(a){return new cl[a]}
function ku(a,b){return a.c==b}
function Yv(a,b){return a>b?a:b}
function Zv(a,b){return a<b?a:b}
function _p(a,b){a.__listener=b}
function on(a,b){Xm(a.b,b,true)}
function uu(a,b){a.b=b;Cu(a.c,a)}
function vu(a,b){a.d=b;Cu(a.c,a)}
function mz(a,b,c){a.splice(b,c)}
function Wr(a){this.v=a;new Pe}
function kA(){this.b=new Date}
function is(){this.c='CENTER'}
function ks(){this.c='JUSTIFY'}
function Rz(a){this.c=a;this.b=a}
function aA(a){this.c=a;this.b=a}
function Xp(){re.call(this,null)}
function Gr(){ur.call(this,yr())}
function hd(a){fd();Bb(cd,a);id()}
function dm(a){sc(a.parentNode,a)}
function tm(a,b){!!a.t&&qe(a.t,b)}
function Qm(a,b){return so(a.o,b)}
function Rm(a,b){return to(a.o,b)}
function Uo(a,b){return Uy(a.n,b)}
function vq(a,b){return ss(a.c,b)}
function yA(a,b){return dx(a.b,b)}
function et(a,b){return a.g.fb(b)}
function Bz(a,b){return a.c.eb(b)}
function Tk(a){return a.l|a.m<<22}
function xo(a){return !a.f?a.j:a.f}
function Xf(a){return kf(),a?jf:hf}
function qc(a){return a.firstChild}
function gx(b,a){return b.f[FB+a]}
function yc(b,a){b.innerHTML=a||rB}
function cp(a,b){this.c=a;this.b=b}
function Ot(a,b){this.c=a;this.b=b}
function Tx(a,b){this.c=a;this.b=b}
function Ms(a,b){this.b=a;this.c=b}
function Su(a,b){this.b=a;this.c=b}
function Ey(a,b){this.b=a;this.c=b}
function KA(a,b){this.b=a;this.c=b}
function xq(){this.c=new ws(this)}
function _c(){this.c='INLINE_BLOCK'}
function Ml(){this.b='localStorage'}
function sz(){sz=RA;rz=new wz}
function tw(){tw=RA;qw={};sw={}}
function Op(){if(!Kp){nq();Kp=true}}
function $p(){if(!Yp){iq();Yp=true}}
function Xm(a,b,c){Fo(a.o,b,c,true)}
function ou(a,b,c){nu(a,Ag(b,37),c)}
function Ap(a,b){oc(a,(ir(),jr(b)))}
function yw(a,b){lc(a.b,b);return a}
function zw(a,b){mc(a.b,b);return a}
function Ew(a,b){mc(a.b,b);return a}
function Ec(a,b){a.textContent=b||rB}
function Py(a){a.b=qg(sk,VA,0,0,0)}
function ly(a){return a.c<a.e.mb()}
function Dc(a,b){return a.contains(b)}
function ix(b,a){return FB+a in b.f}
function zg(a,b){return a.cM&&a.cM[b]}
function Fg(a){return a==null?null:a}
function nA(a){return a<10?KB+a:rB+a}
function zk(a){return Ak(a.l,a.m,a.h)}
function sn(a,b,c){return sm(a.b,b,c)}
function yr(){tr();return $doc.body}
function Hq(a){Gq();Ne.call(this,a)}
function Gw(a){Dw(this);mc(this.b,a)}
function re(a){this.b=new Fe;this.c=a}
function Tb(a){$wnd.clearTimeout(a)}
function an(a){bn.call(this,new mn(a))}
function Ys(){Zs.call(this,new $y)}
function $b(a,b){a.c=ac(a.c,[b,false])}
function $x(a,b){(a<0||a>=b)&&dy(a,b)}
function fr(a,b,c){var d;d=c;gr(a,b,d)}
function nz(a,b,c,d){a.splice(b,c,d)}
function Rl(a,b,c){$wnd[a].setItem(b,c)}
function pl(a,b){Ew(a.b,b.b);return a}
function pc(a,b){return a.childNodes[b]}
function yg(a,b){return a.cM&&!!a.cM[b]}
function Sb(a){return a.$H||(a.$H=++Kb)}
function Eg(a){return a.tM==RA||yg(a,1)}
function aq(a){return !Dg(a)&&Cg(a,22)}
function vb(a){return Dg(a)?fc(Bg(a)):rB}
function jw(b,a){return b.charCodeAt(a)}
function oc(b,a){return b.appendChild(a)}
function sc(b,a){return b.removeChild(a)}
function kr(b,a){b.__gwt_resolve=lr(a)}
function Cg(a,b){return a!=null&&yg(a,b)}
function gl(c,a,b){return a.replace(c,b)}
function zA(a,b){return nx(a.b,b)!=null}
function Ao(a){return (!a.f?a.j:a.f).n.c}
function pb(a){ec();this.f=!a?null:kb(a)}
function mn(a){this.b=a;km(this,this.b)}
function Fe(){this.e=new uA;this.d=false}
function Gq(){Gq=RA;Eq=new Kq;Fq=new Nq}
function Gp(){Gp=RA;Fp=new $y;Mp(new Ip)}
function Id(){Id=RA;Hd=new Td(yB,new Jd)}
function Yd(){Yd=RA;Xd=new Td(zB,new Zd)}
function Xv(){Xv=RA;Wv=qg(rk,VA,48,256,0)}
function Ty(a){a.b=qg(sk,VA,0,0,0);a.c=0}
function Bu(a,b){gt(a.c.b,b);Gu(a);Fu(a)}
function mu(a,b,c,d){lu(a,b,Ag(c,37),d)}
function xe(a,b,c){var d;d=Ae(a,b);d.bb(c)}
function Be(a,b){var c;c=Ce(a,b);return c}
function Uy(a,b){$x(b,a.c);return a.b[b]}
function dy(a,b){throw new Mv(BC+a+CC+b)}
function Ql(a,b){return $wnd[a].getItem(b)}
function zo(a,b){return Uo(!a.f?a.j:a.f,b)}
function ub(a){return a==null?null:a.name}
function sb(a){return a==null?null:a.message}
function Dx(a){return a.c=Ag(my(a.b),57)}
function rb(a){return Dg(a)?sb(Bg(a)):a+rB}
function Nb(a,b,c){return a.apply(b,c);var d}
function Gc(b,a){return b.getElementById(a)}
function tc(c,a,b){return c.replaceChild(a,b)}
function rc(c,a,b){return c.insertBefore(a,b)}
function pe(a,b,c){return new He(we(a.b,b,c))}
function ve(a,b){!a.b&&(a.b=new $y);Ry(a.b,b)}
function ie(a){var b;if(fe){b=new ge;qe(a,b)}}
function Wn(a){var b;b=Tn(a);!!b&&vc(b,ZB)}
function Jy(a){var b;b=Dx(a.b);return b.tb()}
function sv(a){var b=cl[a.c];a=null;return b}
function gc(){try{null.a()}catch(a){return a}}
function Mn(){Ln=pB(function(a){Pn(a)})}
function oo(){oo=RA;io=new il((Hl(),new El))}
function hv(){hv=RA;new iv(false);new iv(true)}
function dv(){nb.call(this,'divide by zero')}
function ur(a){xq.call(this);this.v=a;um(this)}
function qb(a){ec();this.c=a;this.b=rB;dc(this)}
function fm(a,b,c){this.c=a;this.d=b;this.b=c}
function _t(a,b,c){this.b=a;this.d=b;this.c=c}
function bu(a,b,c){this.b=a;this.d=b;this.c=c}
function eu(a,b,c){this.b=a;this.d=b;this.c=c}
function xu(a,b,c){this.d=a;this.b=b;this.c=c}
function wu(a,b){this.d=a;this.b=false;this.c=b}
function ws(a){this.c=a;this.b=qg(qk,VA,30,4,0)}
function _n(a){ao.call(this,a,!Rn&&(Rn=new ko))}
function fd(){fd=RA;cd=[];dd=[];ed=[];ad=new kd}
function vg(){vg=RA;tg=[];ug=[];wg(new mg,tg,ug)}
function fg(a){if(a==null){throw new _v}this.b=a}
function uq(a,b){if(b<0||b>=a.c.d){throw new Lv}}
function Ry(a,b){sg(a.b,a.c++,b);return true}
function Po(c){c.sort(function(a,b){return a-b})}
function lw(b,a){return b.substr(a,b.length-a)}
function tv(a){return typeof a=='number'&&a>0}
function Dg(a){return a!=null&&a.tM!=RA&&!yg(a,1)}
function bt(a){a.g.db();a.j=a.i=0;a.k=true;ct(a)}
function vr(a){tr();try{a.P()}finally{zA(sr,a)}}
function id(){if(!bd){bd=true;$b((Xb(),Wb),ad)}}
function yn(a,b){a.b.k=true;Xn(a.b,b);a.b.k=false}
function xn(a,b,c,d){a.b.j=a.b.j||d;$n(a.b,b,c,d)}
function ac(a,b){!a&&(a=[]);a[a.length]=b;return a}
function rd(a,b){var c;c=pd(b);oc(qd(a),c);return c}
function zb(a){var b;return b=a,Eg(b)?b.hC():Sb(b)}
function Mp(a){Op();return Np(fe?fe:(fe=new Sd),a)}
function Jm(a){if(a.q){return a.q.M()}return false}
function Hg(a){if(a!=null){throw new xv}return null}
function ww(){if(rw==256){qw=sw;sw={};rw=0}++rw}
function xp(){xp=RA;vp=new tp;wp=new tp;up=new tp}
function tr(){tr=RA;qr=new Ar;rr=new uA;sr=new AA}
function Vo(a){this.n=new $y;this.o=new AA;this.g=a}
function gw(a){this.b='Unknown';this.d=a;this.c=-1}
function il(a){this.c=0;this.d=0;this.b=26;this.e=a}
function Ke(a){ob.call(this,Me(a),Le(a));this.b=a}
function ht(a,b){it.call(this,a,b,null,0);Is(a,b.c)}
function Jr(){Kr.call(this,$doc.createElement(SB))}
function Yw(a){var b;b=new xx(a);return new Ey(a,b)}
function xA(a,b){var c;c=jx(a.b,b,a);return c==null}
function Xs(a,b){var c;c=a.b.g.mb();c>0&&Ks(b,0,a.b)}
function yb(a,b){var c;return c=a,Eg(c)?c.eQ(b):c===b}
function uz(a){sz();return a?new eA(a):new Rz(null)}
function wk(a){if(Cg(a,52)){return a}return new qb(a)}
function wn(a){a.c&&(!Hn&&(Hn=new On),Bn(new Cn(a)))}
function Np(a,b){return pe((!Lp&&(Lp=new Xp),Lp),a,b)}
function Vk(a,b){return Ak(a.l^b.l,a.m^b.m,a.h^b.h)}
function Lk(a,b){return a.l==b.l&&a.m==b.m&&a.h==b.h}
function Ak(a,b,c){return _=new al,_.l=a,_.m=b,_.h=c,_}
function wc(b,a){return b[a]==null?null:String(b[a])}
function cc(a,b){a.length>=b&&a.splice(0,b);return a}
function cx(a){a.b=[];a.f={};a.d=false;a.c=null;a.e=0}
function kf(){kf=RA;hf=new lf(false);jf=new lf(true)}
function Dy(a){var b;b=new Fx(a.c.b);return new Ky(b)}
function Vm(a){var b;b=Tn(a);!!b&&(b.focus(),undefined)}
function ju(a,b){var c;c=qc(a.firstChild);vu(b,c.value)}
function Ee(a,b,c){a.c>0?ve(a,new eu(a,b,c)):ze(a,b,c)}
function Xt(a){var b;if(Tt){b=new Vt;!!a.t&&qe(a.t,b)}}
function kl(a){if(a==null){throw new aw(LB)}this.b=a}
function sl(a){if(a==null){throw new aw(LB)}this.b=a}
function Jf(a,b){if(b==null){throw new _v}return Kf(a,b)}
function tA(a,b){return Fg(a)===Fg(b)||a!=null&&yb(a,b)}
function QA(a,b){return Fg(a)===Fg(b)||a!=null&&yb(a,b)}
function so(a,b){return sn(a.k,b,(!Os&&(Os=new Sd),Os))}
function to(a,b){return sn(a.k,b,(!Tt&&(Tt=new Sd),Tt))}
function sm(a,b,c){return pe(!a.t?(a.t=new re(a)):a.t,c,b)}
function yo(a){return (jp(),hp)==a.e?-1:(!a.f?a.j:a.f).e}
function Co(a){return (!a.f?a.j:a.f).k&&(!a.f?a.j:a.f).j==0}
function jr(a){return a.__gwt_resolve?a.__gwt_resolve():a}
function Fb(a){var b=Cb[a.charCodeAt(0)];return b==null?a:b}
function tz(a){sz();var b;b=new BA;xA(b,a);return new gA(b)}
function qg(a,b,c,d,e){var f;f=pg(e,d);rg(a,b,c,f);return f}
function Ag(a,b){if(a!=null&&!zg(a,b)){throw new xv}return a}
function rs(a,b){if(b<0||b>=a.d){throw new Lv}return a.b[b]}
function zs(a){if(a.b>=a.c.d){throw new PA}return a.c.b[++a.b]}
function kw(a,b){if(!Cg(b,1)){return false}return String(a)==b}
function Ac(a){if(uc(a)){return !!a&&a.nodeType==1}return false}
function wr(){tr();try{Iq(sr,qr)}finally{cx(sr.b);cx(rr)}}
function qu(){cb.call(this,rg(uk,VA,1,[yB,zB,WB,eC]))}
function $q(){xq.call(this);km(this,$doc.createElement(SB))}
function Hl(){Hl=RA;new RegExp('%5B',NB);new RegExp('%5D',NB)}
function Zs(a){this.c=new AA;this.f=new uA;this.b=new ht(this,a)}
function vs(a,b){var c;c=ss(a,b);if(c==-1){throw new PA}us(a,c)}
function tq(a,b,c){wm(b);qs(a.c,b);oc(c,(ir(),jr(b.v)));xm(b,a)}
function Qy(a,b,c){(b<0||b>a.c)&&dy(b,a.c);nz(a.b,b,0,c);++a.c}
function Yy(a,b,c){var d;d=($x(b,a.c),a.b[b]);sg(a.b,b,c);return d}
function qv(a,b,c){var d;d=new ov;d.d=a+b;tv(c)&&uv(c,d);return d}
function sd(a,b){var c;c=pd(b);rc(qd(a),c,a.b.firstChild);return c}
function rg(a,b,c,d){vg();xg(d,tg,ug);d.cZ=a;d.cM=b;d.qI=c;return d}
function lx(a,b){var c;c=a.c;a.c=b;if(!a.d){a.d=true;++a.e}return c}
function kb(a){var b,c;b=a.cZ.d;c=a.w();return c!=null?b+qB+c:b}
function Qb(a,b,c){var d;d=Ob();try{return Nb(a,b,c)}finally{Rb(d)}}
function Ym(a,b){if(a.n){$t(a.n.b);a.n=null}!!b&&(a.n=so(a.o,b))}
function ym(a,b){a.s==-1?lq(a.v,b|(a.v.__eventBits||0)):(a.s|=b)}
function Bo(a){return new Ot((!a.f?a.j:a.f).i,(!a.f?a.j:a.f).g)}
function ny(a){if(a.d<0){throw new Iv}a.e.kb(a.d);a.c=a.d;a.d=-1}
function V(a){if(!a.f){return}a.i=a.g;a.f=false;a.g=false;a.i&&br(a)}
function px(a){var b;b=a.c;a.c=null;if(a.d){a.d=false;--a.e}return b}
function og(a,b){var c,d;c=a;d=pg(0,b);rg(c.cZ,c.cM,c.qI,d);return d}
function uc(b){try{return !!b&&!!b.nodeType}catch(a){return false}}
function lr(a){return function(){this.__gwt_resolve=mr;return a.J()}}
function Gg(a){return ~~Math.max(Math.min(a,2147483647),-2147483648)}
function _y(a){Py(this);oz(this.b,0,0,a.g.ob());this.c=this.b.length}
function Ps(a,b,c,d,e){this.g=a;this.c=b;this.b=c;this.e=d;this.f=e}
function Ye(d,a,b){if(b){var c=b.D();b=c(b)}else{b=undefined}d.b[a]=b}
function Mf(d,a,b){if(b){var c=b.D();d.b[a]=c(b)}else{delete d.b[a]}}
function xg(a,b,c){vg();for(var d=0,e=b.length;d<e;++d){a[b[d]]=c[d]}}
function oz(a,b,c,d){Array.prototype.splice.apply(a,[b,c].concat(d))}
function pu(a,b,c){var d;d=new ql;nu(a,c,d);yc(b,(new sl(d.b.b.b)).b)}
function cn(a,b,c){b.__listener=a;yc(b,c.b);b.__listener=null;return b}
function Wy(a,b){var c;c=($x(b,a.c),a.b[b]);mz(a.b,b,1);--a.c;return c}
function vo(a){!a.f&&(a.f=new Xo(a.j));a.g=new Ro(a);Eo(a.g);return a.f}
function Bg(a){if(a!=null&&(a.tM==RA||yg(a,1))){throw new xv}return a}
function my(a){if(a.c>=a.e.mb()){throw new PA}return a.e.fb(a.d=a.c++)}
function As(a){if(a.b<0||a.b>=a.c.d){throw new Iv}a.c.c.X(a.c.b[a.b--])}
function Cu(a,b){if(a.b){return}kw(mw(b.d),rB)&&gt(a.c.b,b);Gu(a);Fu(a)}
function In(a,b){return yA(a.c,b.tagName.toLowerCase())||b.tabIndex>=0}
function mr(){throw 'A PotentialElement cannot be resolved twice.'}
function Pl(){this.b=$wnd.localStorage!=null;$wnd.sessionStorage!=null}
function Ub(){return $wnd.setTimeout(function(){Jb!=0&&(Jb=0);Mb=-1},10)}
function Rb(a){a&&Zb((Xb(),Wb));--Jb;if(a){if(Mb!=-1){Tb(Mb);Mb=-1}}}
function Cc(a){var b=a.parentNode;(!b||b.nodeType!=1)&&(b=null);return b}
function Le(a){var b;b=a.Y();if(!b.$()){return null}return Ag(b._(),52)}
function bm(a){var b,c;cm();b=Cc(a);c=Bc(a);oc(am,a);return new fm(b,c,a)}
function Pp(){var a;if(Kp){a=new Tp;!!Lp&&qe(Lp,a);return null}return null}
function Vy(a,b,c){for(;c<a.c;++c){if(QA(b,a.b[c])){return c}}return -1}
function ng(a,b){var c,d;c=a;d=c.slice(0,b);rg(c.cZ,c.cM,c.qI,d);return d}
function wg(a,b,c){var d=0,e;for(var f in a){if(e=a[f]){b[d]=f;c[d]=e;++d}}}
function ss(a,b){var c;for(c=0;c<a.d;++c){if(a.b[c]==b){return c}}return -1}
function mx(e,a,b){var c,d=e.f;a=FB+a;a in d?(c=d[a]):++e.e;d[a]=b;return c}
function dx(a,b){return b==null?a.d:Cg(b,1)?ix(a,Ag(b,1)):hx(a,b,~~zb(b))}
function ex(a,b){return b==null?a.c:Cg(b,1)?gx(a,Ag(b,1)):fx(a,b,~~zb(b))}
function nx(a,b){return b==null?px(a):Cg(b,1)?qx(a,Ag(b,1)):ox(a,b,~~zb(b))}
function Et(a){if(a.b>=a.d.g.mb()){throw new PA}return et(a.d,a.c=a.b++)}
function Fc(a){!a.gwt_uid&&(a.gwt_uid=1);return 'gwt-uid-'+a.gwt_uid++}
function Xy(a,b){var c;c=Vy(a,b,0);if(c==-1){return false}Wy(a,c);return true}
function gt(a,b){var c;c=a.g.gb(b);if(c==-1){return false}ft(a,c);return true}
function Lf(a,b,c){var d;if(b==null){throw new _v}d=Jf(a,b);Mf(a,b,c);return d}
function rv(a,b,c,d){var e;e=new ov;e.d=a+b;tv(c)&&uv(c,e);e.b=d?8:0;return e}
function it(a,b,c,d){this.o=a;this.e=new Bt(this);this.g=b;this.c=c;this.n=d}
function ty(a,b){var c;this.b=a;this.e=a;c=a.mb();(b<0||b>c)&&dy(b,c);this.c=b}
function Td(a,b){Sd.call(this);this.b=b;!Cd&&(Cd=new de);ce(Cd,a,this);this.c=a}
function hr(a){xq.call(this);km(this,$doc.createElement(SB));yc(this.v,a)}
function hu(){var a;Zr();$r.call(this,(a=$doc.createElement(DC),a.type='text',a))}
function cm(){if(!am){am=$doc.createElement(SB);pm(am,false);oc(yr(),am)}}
function Bq(a){a.style['left']=rB;a.style['top']=rB;a.style['position']=rB}
function pm(a,b){a.style.display=b?rB:TB;a.setAttribute('aria-hidden',String(!b))}
function nw(a,b,c){a=a.slice(b,c);return String.fromCharCode.apply(null,a)}
function Bp(a,b,c){var d;d=yp;yp=a;b==zp&&Zp(a.type)==8192&&(zp=null);c.O(a);yp=d}
function Bn(a){var b;if(!Zn(a.b.b)){b=Tn(a.b.b);!!b&&(b.focus(),undefined)}}
function Yb(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=bc(b,c)}while(a.b);a.b=c}}
function Zb(a){var b,c;if(a.c){c=null;do{b=a.c;a.c=null;c=bc(b,c)}while(a.c);a.c=c}}
function qx(d,a){var b,c=d.f;a=FB+a;if(a in c){b=c[a];--d.e;delete c[a]}return b}
function Xe(d,a){var b=d.b[a];var c=(Wf(),Vf)[typeof b];return c?c(b):dg(typeof b)}
function Bc(a){var b=a.nextSibling;while(b&&b.nodeType!=1)b=b.nextSibling;return b}
function qd(a){var b;if(!a.b){b=$doc.getElementsByTagName('head')[0];a.b=b}return a.b}
function Um(a,b,c){var d;d=cn(a,(!Pm&&(Pm=$doc.createElement(SB)),Pm),c);hn(a.d,d,b)}
function Js(a,b,c){var d,e;for(e=Dy(Yw(a.c.b));ly(e.b.b);){d=Ag(Jy(e),32);Ks(d,b,c)}}
function jx(a,b,c){return b==null?lx(a,c):Cg(b,1)?mx(a,Ag(b,1),c):kx(a,b,c,~~zb(b))}
function tb(a){var b;return a==null?sB:Dg(a)?ub(Bg(a)):Cg(a,1)?tB:(b=a,Eg(b)?b.cZ:Pg).d}
function pd(a){var b;b=$doc.createElement(xB);b['language']='text/css';Ec(b,a);return b}
function pv(a,b,c){var d;d=new ov;d.d=a+b;tv(c!=0?-c:0)&&uv(c!=0?-c:0,d);d.b=4;return d}
function Rs(a,b,c,d,e,f){var g;g=new Ps(b,c,d,e,f);!!Os&&!!a.t&&qe(a.t,g);return g}
function Nl(){!Kl&&(Kl=new Pl);if(Kl.b){!Jl&&(Jl=new Ml);return Jl}return null}
function or(b){ir();try{return !!b&&!!b.__gwt_resolve}catch(a){return false}}
function Pb(b){return function(){try{return Qb(b,this,arguments)}catch(a){throw a}}}
function Sv(a){var b,c;if(a==0){return 32}else{c=0;for(b=1;(b&a)==0;b<<=1){++c}return c}}
function If(e,a){var b=e.b;var c=0;for(var d in b){b.hasOwnProperty(d)&&(a[c++]=d)}return a}
function at(a,b){var c;a.j=Zv(a.j,a.g.mb());c=a.g.cb(b);a.i=a.g.mb();a.k=true;ct(a);return c}
function Ht(a,b){var c;this.d=a;c=a.g.mb();if(b<0||b>c){throw new Mv(BC+b+CC+c)}this.b=b}
function Zq(a,b){var c;uq(a,b);c=a.b;a.b=rs(a.c,b);if(a.b!=c){!Xq&&(Xq=new dr);cr(Xq,c,a.b)}}
function yk(a){var b,c,d;b=a&4194303;c=a>>22&4194303;d=a<0?1048575:0;return Ak(b,c,d)}
function Tn(a){var b;b=yo(a.o);if(b>=0&&a.d.childNodes.length>b){return pc(a.d,b)}return null}
function Mw(a,b){var c;while(a.$()){c=a._();if(b==null?c==null:yb(b,c)){return a}}return null}
function Un(a,b){Do(a.o,null);Sm(a,b);if(a.d.childNodes.length>b){return pc(a.d,b)}return null}
function _s(a,b){var c;c=a.g.bb(b);a.j=Zv(a.j,a.g.mb()-1);a.i=a.g.mb();a.k=true;ct(a);return c}
function Lo(a,b){this.d=(bp(),$o);this.e=(jp(),ip);this.b=a;this.k=b;this.j=new Vo(25)}
function Fx(a){var b;this.d=a;b=new $y;a.d&&Ry(b,new Ox(a));bx(a,b);ax(a,b);this.b=new oy(b)}
function fs(){fs=RA;bs=new is;cs=new ks;ds=new ms;es=new os;as=rg(pk,VA,29,[bs,cs,ds,es])}
function Sc(){Sc=RA;Rc=new Vc;Oc=new Xc;Pc=new Zc;Qc=new _c;Nc=rg(lk,VA,3,[Rc,Oc,Pc,Qc])}
function $k(){$k=RA;Wk=Ak(4194303,4194303,524287);Xk=Ak(0,0,524288);Yk=Nk(1);Nk(2);Zk=Nk(0)}
function Wf(){Wf=RA;Vf={'boolean':Xf,number:Yf,string:$f,object:Zf,'function':Zf,undefined:_f}}
function _m(a,b){if(!a){return}b?(a.style[UB]=rB,undefined):(a.style[UB]=(Sc(),TB),undefined)}
function Ir(a,b){if(a.b!=b){return false}try{xm(b,null)}finally{sc(a.v,b.v);a.b=null}return true}
function Sy(a,b){var c,d;c=b.ob();d=c.length;if(d==0){return false}oz(a.b,a.c,0,c);a.c+=d;return true}
function Hk(a){var b,c;c=Rv(a.h);if(c==32){b=Rv(a.m);return b==32?Rv(a.l)+32:b+20-10}else{return c-12}}
function Au(a){var b,c;c=new Gt(a.c.b);while(c.b<c.d.g.mb()){b=Ag(Et(c),37);b.b&&Ft(c)}Gu(a);Fu(a)}
function Is(a,b){var c,d;a.d=b;a.e=true;for(d=Dy(Yw(a.c.b));ly(d.b.b);){c=Ag(Jy(d),32);c.U(b,true)}}
function Ho(a,b,c){if(b==(!a.f?a.j:a.f).j&&c==(!a.f?a.j:a.f).k){return}vo(a).j=b;vo(a).k=c;Ko(a)}
function Go(a,b){if(!b){throw new aw('KeyboardSelectionPolicy cannot be null')}a.e=b}
function Sm(a,b){if(!(b>=0&&b<Ao(a.o))){throw new Mv('Row index: '+b+', Row size: '+xo(a.o).j)}}
function $r(a){Wr.call(this,a,(!Xl&&(Xl=new Yl),!Ul&&(Ul=new Vl)));this.v[tC]='gwt-TextBox'}
function Vq(){var a;Uq.call(this,(a=$doc.createElement(sC),a.type=aC,a));this.v[tC]='gwt-Button'}
function Hu(a){this.e=new Ku(this);this.c=new Ys;this.d=a;Du(this);Mu(a,this.e);Ou(a,this.c);Gu(this)}
function dg(a){Wf();throw new rf("Unexpected typeof result '"+a+"'; please report this bug to the GWT team")}
function wq(a,b){var c;if(b.u!=a){return false}try{xm(b,null)}finally{c=b.v;sc(Cc(c),c);vs(a.c,b)}return true}
function us(a,b){var c;if(b<0||b>=a.d){throw new Lv}--a.d;for(c=b;c<a.d;++c){sg(a.b,c,a.b[c+1])}sg(a.b,a.d,null)}
function De(a){var b,c;if(a.b){try{for(c=new oy(a.b);c.c<c.e.mb();){b=Ag(my(c),35);b.x()}}finally{a.b=null}}}
function hc(a){var b,c,d;d=ic(a);for(b=0,c=d.length;b<c;++b){d[b]=d[b].length==0?'anonymous':d[b]}return d}
function jb(a){var b,c,d;c=qg(tk,VA,51,a.length,0);for(d=0,b=a.length;d<b;++d){if(!a[d]){throw new _v}c[d]=a[d]}}
function bx(e,a){var b=e.f;for(var c in b){if(c.charCodeAt(0)==58){var d=new Tx(e,c.substring(1));a.bb(d)}}}
function vw(a){tw();var b=FB+a;var c=sw[b];if(c!=null){return c}c=qw[b];c==null&&(c=uw(a));ww();return sw[b]=c}
function hq(a,b){var c=0,d=a.firstChild;while(d){if(d===b){return c}d.nodeType==1&&++c;d=d.nextSibling}return -1}
function mv(a){if(a>=48&&a<58){return a-48}if(a>=97&&a<97){return a-97+10}if(a>=65&&a<65){return a-65+10}return -1}
function Vv(a){var b,c;if(a>-129&&a<128){b=a+128;c=(Xv(),Wv)[b];!c&&(c=Wv[b]=new Ov(a));return c}return new Ov(a)}
function Ok(a){var b,c,d;b=~a.l+1&4194303;c=~a.m+(b==0?1:0)&4194303;d=~a.h+(b==0&&c==0?1:0)&1048575;return Ak(b,c,d)}
function Gk(a){var b,c,d;b=~a.l+1&4194303;c=~a.m+(b==0?1:0)&4194303;d=~a.h+(b==0&&c==0?1:0)&1048575;a.l=b;a.m=c;a.h=d}
function Gu(a){var b,c,d,e;e=a.c.b.g.mb();b=0;for(d=new Gt(a.c.b);d.b<d.d.g.mb();){c=Ag(Et(d),37);c.b&&++b}Pu(a.d,e,b)}
function zu(a){var b,c;b=mw(wc(a.d.g.v,FC));if(kw(b,rB))return;c=new wu(b,a);a.d.g.v[FC]=rB;_s(a.c.b,c);Gu(a);Fu(a)}
function gn(a,b,c){Jm(a)||_p(a.v,a);yc(b,(!Hn&&(Hn=new On),c).b);Jm(a)||(a.v.__listener=null,undefined)}
function Nu(a,b){b?(a.setAttribute(xB,'display:none;'),undefined):(a.setAttribute(xB,'display:block;'),undefined)}
function ze(a,b,c){var d,e,f;d=Ce(a,b);e=d.lb(c);e&&d.hb()&&(f=Ag(ex(a.e,b),56),Ag(px(f),55),f.e==0&&nx(a.e,b),undefined)}
function Dk(a,b,c,d,e){var f;f=Qk(a,b);c&&Gk(f);if(e){a=Fk(a,b);d?(xk=Ok(a)):(xk=Ak(a.l,a.m,a.h))}return f}
function Ae(a,b){var c,d;d=Ag(ex(a.e,b),56);if(!d){d=new uA;jx(a.e,b,d)}c=Ag(d.c,55);if(!c){c=new $y;lx(d,c)}return c}
function Ce(a,b){var c,d;d=Ag(ex(a.e,b),56);if(!d){return sz(),sz(),rz}c=Ag(d.c,55);if(!c){return sz(),sz(),rz}return c}
function wx(a,b){var c,d,e;if(Cg(b,57)){c=Ag(b,57);d=c.tb();if(dx(a.b,d)){e=ex(a.b,d);return tA(c.ub(),e)}}return false}
function Sk(a,b){var c,d,e;c=a.l-b.l;d=a.m-b.m+(c>>22);e=a.h-b.h+(d>>22);return Ak(c&4194303,d&4194303,e&1048575)}
function vm(a,b){var c;switch(Zp(b.type)){case 16:case 32:c=b.relatedTarget;if(!!c&&Dc(a.v,c)){return}}Fd(b,a,a.v)}
function Zy(a,b){var c;b.length<a.c&&(b=og(b,a.c));for(c=0;c<a.c;++c){sg(b,c,a.b[c])}b.length>a.c&&sg(b,a.c,null);return b}
function Ze(a){var b,c,d;d=new Aw;d.b.b+=AB;for(c=0,b=a.b.length;c<b;++c){c>0&&(d.b.b+=BB,d);yw(d,Xe(a,c))}d.b.b+=CB;return d.b.b}
function ec(){var a,b,c,d;c=cc(hc(gc()),3);d=qg(tk,VA,51,c.length,0);for(a=0,b=d.length;a<b;++a){d[a]=new gw(c[a])}jb(d)}
function ax(h,a){var b=h.b;for(var c in b){var d=parseInt(c,10);if(c==d){var e=b[d];for(var f=0,g=e.length;f<g;++f){a.bb(e[f])}}}}
function dc(a){var b,c,d,e;d=hc(Dg(a.c)?Bg(a.c):null);e=qg(tk,VA,51,d.length,0);for(b=0,c=e.length;b<c;++b){e[b]=new gw(d[b])}jb(e)}
function gwtOnLoad(b,c,d,e){$moduleName=c;$moduleBase=d;if(b)try{pB(vk)()}catch(a){b(c)}else{pB(vk)()}}
function Ex(a){if(!a.c){throw new Jv('Must call next() before remove().')}else{ny(a.b);nx(a.d,a.c.tb());a.c=null}}
function xr(){tr();var a;a=Ag(ex(rr,null),27);if(a){return a}rr.e==0&&Mp(new Dr);a=new Gr;jx(rr,null,a);xA(sr,a);return a}
function mw(c){if(c.length==0||c[0]>wB&&c[c.length-1]>wB){return c}var a=c.replace(/^(\s*)/,rB);var b=a.replace(/\s*$/,rB);return b}
function jp(){jp=RA;hp=new kp('DISABLED');ip=new kp('ENABLED');gp=new kp('BOUND_TO_SELECTION');fp=rg(ok,VA,21,[hp,ip,gp])}
function Mu(a,b){var c;c=a.k;$p();mq(c,1);_p(c,new Su(a,b));rm(a.g,new Vu(b),(Yd(),Yd(),Xd));rm(a.b,new Yu(b),(Id(),Id(),Hd))}
function Xn(a,b){var c;c=null;b==(xp(),vp)?(c=a.f):b==up&&Co(a.o)&&(c=a.e);!!c&&Zq(a.g,vq(a.g,c));_m(a.d,!c);lm(a.g,!!c);tm(a,new pp)}
function Fd(a,b,c){var d,e,f;if(Cd){f=Ag(be(Cd,a.type),6);if(f){d=f.b.b;e=f.b.c;Dd(f.b,a);Ed(f.b,c);tm(b,f.b);Dd(f.b,d);Ed(f.b,e)}}}
function Wm(a,b,c){var d;if(c){d=b;zc(d,a.p)}else{b.tabIndex=-1;b.removeAttribute('tabIndex');b.removeAttribute('accessKey')}}
function Ck(a,b){if(a.h==524288&&a.m==0&&a.l==0){b&&(xk=Ak(0,0,0));return zk(($k(),Yk))}b&&(xk=Ak(a.l,a.m,a.h));return Ak(0,0,0)}
function Nk(a){var b,c;if(a>-129&&a<128){b=a+128;Kk==null&&(Kk=qg(mk,VA,16,256,0));c=Kk[b];!c&&(c=Kk[b]=yk(a));return c}return yk(a)}
function Zn(a){var b;b=yo(a.o);if(b>=0&&b<xo(a.o).n.c){Tn(a);Sm(a,b);zo(a.o,b);new eb(b+Bo(a.o).c,a.o);return false}return false}
function Ob(){var a;if(Jb!=0){a=(new Date).getTime();if(a-Lb>2000){Lb=a;Mb=Ub()}}if(Jb++==0){Yb((Xb(),Wb));return true}return false}
function hx(h,a,b){var c=h.b[b];if(c){for(var d=0,e=c.length;d<e;++d){var f=c[d];var g=f.tb();if(h.sb(a,g)){return true}}}return false}
function fx(h,a,b){var c=h.b[b];if(c){for(var d=0,e=c.length;d<e;++d){var f=c[d];var g=f.tb();if(h.sb(a,g)){return f.ub()}}}return null}
function tn(b,c,d){var a,e;try{e=new ql;Yn(b.b,e,c,d);return new sl(e.b.b.b)}catch(a){a=wk(a);if(Cg(a,53)){return null}else throw a}}
function $n(a,b,c,d){var e;if(!(b>=0&&b<xo(a.o).n.c)){return}e=Un(a,b);(!c||a.j||d)&&om(e,ZB,c);Wm(a,e,c);if(c&&d&&!a.c){e.focus();Wn(a)}}
function Ft(a){if(a.c<0){throw new Jv('Cannot call add/remove more than once per call to next/previous.')}ft(a.d,a.c);a.b=a.c;a.c=-1}
function Kf(f,a){var b=f.b;var c;a=String(a);b.hasOwnProperty(a)&&(c=b[a]);var d=(Wf(),Vf)[typeof c];var e=d?d(c):dg(typeof c);return e}
function Bl(){Bl=RA;new sl(rB);wl=new RegExp(MB,NB);xl=new RegExp(OB,NB);yl=new RegExp(PB,NB);Al=new RegExp(QB,NB);zl=new RegExp(vB,NB)}
function rm(a,b,c){var d;d=Zp(c.c);d==-1?mm(a,c.c):a.s==-1?lq(a.v,d|(a.v.__eventBits||0)):(a.s|=d);return pe(!a.t?(a.t=new re(a)):a.t,c,b)}
function Pu(a,b,c){var d;d=b-c;Nu(a.d,b==0);Nu(a.i,b==0);Nu(a.b.v,c==0);Ec(a.e,rB+d);Ec(a.f,d>1||d==0?'items':'item');yc(a.c,rB+c);Hc(a.k,b==c)}
function av(a){var b;b=new Fw;b.b.b+="Clear completed (<span class='number-done' id='";Ew(b,Cl(a));b.b.b+="'><\/span>)";return new kl(b.b.b)}
function cb(a){var b,c,d,e;e=null;if(a!=null&&a.length>0){e=new AA;for(c=0,d=a.length;c<d;++c){b=a[c];xA(e,b)}}!!e&&(this.d=(sz(),new gA(e)))}
function fc(b){var c=rB;try{for(var d in b){if(d!='name'&&d!='message'&&d!='toString'){try{c+='\n '+d+qB+b[d]}catch(a){}}}}catch(a){}return c}
function bp(){bp=RA;_o=new cp('CURRENT_PAGE',true);$o=new cp('CHANGE_PAGE',false);ap=new cp('INCREASE_RANGE',false);Zo=rg(nk,VA,20,[_o,$o,ap])}
function Ko(a){var b,c,d;d=(!a.f?a.j:a.f).i;b=Yv(0,Zv((!a.f?a.j:a.f).g,(!a.f?a.j:a.f).j-d));c=(!a.f?a.j:a.f).n.c-1;while(c>=b){Wy(vo(a).n,c);--c}}
function ct(a){if(a.c){a.c.j=Zv(a.j+a.n,a.c.j);a.c.i=Yv(a.i+a.n,a.c.i);a.c.k=a.k||a.c.k;ct(a.c);return}a.d=false;if(!a.f){a.f=true;$b((Xb(),Wb),a.e)}}
function Ks(a,b,c){var d,e,f,g,h,i,j,k,l;g=b+c.mb();h=a.T();f=h.c;e=h.b;d=f+e;if(b==f||f<g&&d>b){k=f<b?b:f;i=d>g?g:d;j=i-k;l=c.nb(k-b,k-b+j);a.V(k,l)}}
function bc(b,c){var a,d,e,f;for(d=0,e=b.length;d<e;++d){f=b[d];try{f[1]?f[0].yb()&&(c=ac(c,f)):f[0].x()}catch(a){a=wk(a);if(!Cg(a,52))throw a}}return c}
function ft(b,c){var a,d,e;try{e=b.g.kb(c);b.j=Zv(b.j,c);b.i=b.g.mb();b.k=true;ct(b);return e}catch(a){a=wk(a);if(Cg(a,47)){d=a;throw new Mv(d.f)}else throw a}}
function Fk(a,b){var c,d,e;if(b<=22){c=a.l&(1<<b)-1;d=e=0}else if(b<=44){c=a.l;d=a.m&(1<<b-22)-1;e=0}else{c=a.l;d=a.m;e=a.h&(1<<b-44)-1}return Ak(c,d,e)}
function Sn(a,b,c,d){var e,f;f=a.b.d;if(!!f&&Bz(f,b.type)){e=ku(a.b,Ag(d,37));mu(a.b,c,d,b);a.c=ku(a.b,Ag(d,37));e&&!a.c&&(!Hn&&(Hn=new On),Vm((new fo(a)).b))}}
function ru(a){var b;b=new Fw;b.b.b+="<div class='listItem editing'><input class='edit' value='";Ew(b,Cl(a));b.b.b+="' type='text'><\/div>";return new kl(b.b.b)}
function uv(a,b){var c;b.c=a;if(a==2){c=String.prototype}else{if(a>0){var d=sv(b);if(d){c=d.prototype}else{d=cl[a]=function(){};d.cZ=b;return}}else{return}}c.cZ=b}
function wm(a){if(!a.u){(tr(),yA(sr,a))&&vr(a)}else if(Cg(a.u,24)){Ag(a.u,24).X(a)}else if(a.u){throw new Jv("This widget's parent does not implement HasWidgets")}}
function Eu(a,b){var c,d,e;a.b=true;for(e=new Gt(a.c.b);e.b<e.d.g.mb();){d=Ag(Et(e),37);d.b=b;Cu(d.c,d)}a.b=false;c=new _y(a.c.b);bt(a.c.b);at(a.c.b,c);Gu(a);Fu(a)}
function Im(a,b){var c;if(a.q){throw new Jv('Composite.initWidget() may only be called once.')}Cg(b,25)&&Ag(b,25);wm(b);c=b.v;a.v=c;or(c)&&kr((ir(),c),a);a.q=b;xm(b,a)}
function rA(){rA=RA;pA=rg(uk,VA,1,['Sun','Mon','Tue','Wed','Thu','Fri','Sat']);qA=rg(uk,VA,1,['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'])}
function cw(){cw=RA;bw=rg(kk,VA,-1,[48,49,50,51,52,53,54,55,56,57,97,98,99,100,101,102,103,104,105,106,107,108,109,110,111,112,113,114,115,116,117,118,119,120,121,122])}
function Jk(a,b){var c,d,e;e=a.h-b.h;if(e<0){return false}c=a.l-b.l;d=a.m-b.m+(c>>22);e+=d>>22;if(e<0){return false}a.l=c&4194303;a.m=d&4194303;a.h=e&1048575;return true}
function wo(a,b,c){var d,e,f,g,h,i;if(b==null){return -1}e=-1;d=2147483647;i=a.n.c;for(h=0;h<i;++h){f=Uy(a.n,h);if(yb(b,f)){g=c-h<0?-(c-h):c-h;if(g<d){e=h;d=g}}}return e}
function Tv(a){var b,c,d;b=qg(kk,VA,-1,8,1);c=(cw(),bw);d=7;if(a>=0){while(a>15){b[d--]=c[a&15];a>>=4}}else{while(d>0){b[d--]=c[a&15];a>>=4}}b[d]=c[a&15];return nw(b,d,8)}
function Nw(a){var b,c,d,e;d=new Aw;b=null;d.b.b+=AB;c=a.Y();while(c.$()){b!=null?(mc(d.b,b),d):(b=EB);e=c._();mc(d.b,e===a?'(this Collection)':rB+e)}d.b.b+=CB;return d.b.b}
function dt(a){var b;a.f&&(a.d=true);if(a.o.b!=a){return}b=a.g.mb();if(a.b!=b){a.b=b;Is(a.o,a.b)}if(a.k){Js(a.o,a.j,a.g.nb(a.j,a.i));a.k=false}a.j=2147483647;a.i=-2147483648}
function Nn(a,b,c){var d;if(yA(a.b,c)){!Ln&&Mn();d=b.v;if(!kw($B,d.getAttribute(_B+c)||rB)){d.setAttribute(_B+c,$B);d.addEventListener(c,Ln,true)}return -1}else{return Zp(c)}}
function pg(a,b){var c=new Array(b);if(a==3){for(var d=0;d<b;++d){var e=new Object;e.l=e.m=e.h=0;c[d]=e}}else if(a>0){var e=[null,0,false][a];for(var d=0;d<b;++d){c[d]=e}}return c}
function ox(h,a,b){var c=h.b[b];if(c){for(var d=0,e=c.length;d<e;++d){var f=c[d];var g=f.tb();if(h.sb(a,g)){c.length==1?delete h.b[b]:c.splice(d,1);--h.e;return f.ub()}}}return null}
function Iq(b,c){Gq();var a,d,e,f,g;d=null;for(g=b.Y();g.$();){f=Ag(g._(),30);try{c.Z(f)}catch(a){a=wk(a);if(Cg(a,52)){e=a;!d&&(d=new AA);xA(d,e)}else throw a}}if(d){throw new Hq(d)}}
function bg(b){Wf();var a,c;if(b==null){throw new _v}if(b.length==0){throw new Gv('empty argument')}try{return ag(b,true)}catch(a){a=wk(a);if(Cg(a,2)){c=a;throw new sf(c)}else throw a}}
function xm(a,b){var c;c=a.u;if(!b){try{!!c&&c.M()&&a.P()}finally{a.u=null}}else{if(c){throw new Jv('Cannot set a new parent without first clearing the old parent')}a.u=b;b.M()&&a.N()}}
function un(a,b,c){var d,e;e=tn(a,b,Bo(a.b.o).c);a.b.j=a.b.j||c;a.c=a.b.j;a.b.k=true;Tm(a.b,e);a.b.k=false;d=Tn(a.b);if(d){Wm(a.b,d,true);a.b.j&&Wn(a.b)}tm(a.b,new Fn(uz(xo(a.b.o).n)))}
function vn(a,b,c,d){var e,f;f=tn(a,b,Bo(a.b.o).c+c);a.b.j=a.b.j||d;a.c=a.b.j;a.b.k=true;Um(a.b,c,f);a.b.k=false;e=Tn(a.b);if(e){Wm(a.b,e,true);a.b.j&&Wn(a.b)}tm(a.b,new Fn(uz(xo(a.b.o).n)))}
function we(a,b,c){if(!b){throw new aw('Cannot add a handler with a null type')}if(!c){throw new aw('Cannot add a null handler')}a.c>0?ve(a,new bu(a,b,c)):xe(a,b,c);return new _t(a,b,c)}
function fl(a){return $stats({moduleName:$moduleName,sessionId:$sessionId,subSystem:'startup',evtGroup:'moduleStartup',millis:(new Date).getTime(),type:'onModuleLoadStart',className:a})}
function Pn(a){var b,c,d,e;b=a.target;if(!Ac(b)){return}d=b;e=a.type;c=d.__listener;while(!!d&&!c){d=Cc(d);!!d&&kw($B,d.getAttribute(_B+e)||rB)&&(c=d.__listener)}!!c&&(Bp(a,d,c),undefined)}
function Gb(b){Eb();var c=b.replace(/[\xad\u0600-\u0603\u06dd\u070f\u17b4\u17b5\u200b-\u200f\u2028-\u202e\u2060-\u2064\u206a-\u206f\ufeff\ufff9-\ufffb]/g,function(a){return Fb(a)});return c}
function Xo(a){var b,c;Vo.call(this,a.g);this.d=new $y;this.e=a.e;this.f=a.f;this.g=a.g;this.i=a.i;this.j=a.j;this.k=a.k;this.p=a.p;this.q=a.q;c=a.n.c;for(b=0;b<c;++b){Ry(this.n,Uy(a.n,b))}}
function $l(a){if(!a.c){a.c=Gc($doc,a.b);if(!a.c){throw new nb('Cannot find element with id "'+a.b+'". Perhaps it is not attached to the document body.')}a.c.removeAttribute('id')}return a.c}
function Fu(a){var b,c,d,e,f,g;d=Nl();if(d){f=new $e;for(b=0;b<a.c.b.g.mb();++b){e=Ag(et(a.c.b,b),37);c=new Nf;Lf(c,GC,new fg(e.d));Lf(c,HC,(kf(),e.b?jf:hf));g=Xe(f,b);Ye(f,b,c)}Ll(d,Ze(f))}}
function qe(b,c){var a,d,e;!c.i||(c.i=false,c.j=null);e=c.j;Bd(c,b.c);try{ye(b.b,c)}catch(a){a=wk(a);if(Cg(a,36)){d=a;throw new Ne(d.b)}else throw a}finally{e==null?(c.i=true,c.j=null):(c.j=e)}}
function Jn(a,b,c){var d,e,f,g;if(!c){return}d=0;for(g=c.Y();g.$();){f=Ag(g._(),1);e=Zp(f);if(e<0){Cp(b.v,f)}else{e=Nn(a,b,f);e>0&&(d|=e)}}d>0&&(b.s==-1?Dp(b.v,d|(b.v.__eventBits||0)):(b.s|=d))}
function Qu(){this.j=new _n(new qu);Im(this,$u(new _u(this)));Zm(this.j,(jp(),hp));this.d.id='main';this.b.v.id='clear-completed';this.g.v.id='new-todo';this.i.id='footer';this.k.id='toggle-all'}
function qo(a,b,c){var d;d=new Fw;d.b.b+='<div onclick="" __idx="';Ew(d,Cl(rB+a));d.b.b+='" class="';Ew(d,Cl(b));d.b.b+='" style="outline:none;" >';Ew(d,c.b);d.b.b+='<\/div>';return new kl(d.b.b)}
function xy(a,b,c){this.d=a;this.b=b;this.c=c-b;if(b>c){throw new Gv(KC+b+' > toIndex: '+c)}if(b<0){throw new Mv(KC+b+' < 0')}if(c>a.mb()){throw new Mv('toIndex: '+c+' > wrapped.size() '+a.mb())}}
function hn(a,b,c){var d,e,f,g,h;d=a.childNodes.length;h=null;c<d&&(h=a.childNodes[c]);e=b.childNodes.length;for(f=0;f<e;++f){if(!h){oc(a,b.childNodes[0])}else{g=Bc(h);tc(a,b.childNodes[0],h);h=g}}}
function bn(a){var b;Im(this,a);this.o=new Lo(this,new zn(this));b=new AA;xA(b,VB);xA(b,WB);xA(b,XB);xA(b,zB);xA(b,yB);xA(b,YB);Jn((!Hn&&(Hn=new On),Hn),this,b);Qm(this,new Us);Ym(this,new pn(this))}
function uw(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)))|0;c+=4}while(c<d){b=b*31+jw(a,c++)}return b|0}
function sg(a,b,c){if(c!=null){if(a.qI>0&&!zg(c,a.qI)){throw new fv}else if(a.qI==-1&&(c.tM==RA||yg(c,1))){throw new fv}else if(a.qI<-1&&!(c.tM!=RA&&!yg(c,1))&&!zg(c,-a.qI)){throw new fv}}return a[b]=c}
function kx(j,a,b,c){var d=j.b[c];if(d){for(var e=0,f=d.length;e<f;++e){var g=d[e];var h=g.tb();if(j.sb(a,h)){var i=g.ub();g.vb(b);return i}}}else{d=j.b[c]=[]}var g=new KA(a,b);d.push(g);++j.e;return null}
function Pk(a,b){var c,d,e;b&=63;if(b<22){c=a.l<<b;d=a.m<<b|a.l>>22-b;e=a.h<<b|a.m>>22-b}else if(b<44){c=0;d=a.l<<b-22;e=a.m<<b-22|a.l>>44-b}else{c=0;d=0;e=a.l<<b-44}return Ak(c&4194303,d&4194303,e&1048575)}
function Rk(a,b){var c,d,e,f;b&=63;c=a.h&1048575;if(b<22){f=c>>>b;e=a.m>>b|c<<22-b;d=a.l>>b|a.m<<22-b}else if(b<44){f=0;e=c>>>b-22;d=a.m>>b-22|a.h<<44-b}else{f=0;e=0;d=c>>>b-44}return Ak(d&4194303,e&4194303,f&1048575)}
function Hb(b){Eb();var c=b.replace(/[\x00-\x1f\xad\u0600-\u0603\u06dd\u070f\u17b4\u17b5\u200b-\u200f\u2028-\u202e\u2060-\u2064\u206a-\u206f\ufeff\ufff9-\ufffb"\\]/g,function(a){return Fb(a)});return vB+c+vB}
function ts(a,b,c){var d,e;if(c<0||c>a.d){throw new Lv}if(a.d==a.b.length){e=qg(qk,VA,30,a.b.length*2,0);for(d=0;d<a.b.length;++d){sg(e,d,a.b[d])}a.b=e}++a.d;for(d=a.d-1;d>c;--d){sg(a.b,d,a.b[d-1])}sg(a.b,c,b)}
function On(){this.c=new AA;xA(this.c,'select');xA(this.c,'input');xA(this.c,'textarea');xA(this.c,'option');xA(this.c,aC);xA(this.c,'label');this.b=new AA;xA(this.b,VB);xA(this.b,WB);xA(this.b,bC);xA(this.b,cC)}
function dl(a,b,c){var d=cl[a];if(d&&!d.cZ){_=d.prototype}else{!d&&(d=cl[a]=function(){});_=d.prototype=b<0?{}:el(b);_.cM=c}for(var e=3;e<arguments.length;++e){arguments[e].prototype=_}if(d.cZ){_.cZ=d.cZ;d.cZ=null}}
function Me(a){var b,c,d,e,f;c=a.mb();if(c==0){return null}b=new Gw(c==1?'Exception caught: ':c+' exceptions caught: ');d=true;for(f=a.Y();f.$();){e=Ag(f._(),52);d?(d=false):(b.b.b+='; ',b);Ew(b,e.w())}return b.b.b}
function Zf(a){if(!a){return vf(),uf}var b=a.valueOf?a.valueOf():a;if(b!==a){var c=Vf[typeof b];return c?c(b):dg(typeof b)}else if(a instanceof Array||a instanceof $wnd.Array){return new _e(a)}else{return new Of(a)}}
function Yn(a,b,c,d){var e,f,g,h,i,j;yo(a.o)+Bo(a.o).c;i=c.mb();g=d+i;for(h=d;h<g;++h){j=c.fb(h-d);f=new Fw;mc(f.b,h%2==0?'GPBYFDEAB':'GPBYFDECB');e=new ql;new eb(h,a.o);ou(a.b,j,e);pl(b,qo(h,f.b.b,new sl(e.b.b.b)))}}
function ic(a){var b,c,d,e,f;f=a&&a.message?a.message.split('\n'):[];for(b=0,c=0,e=f.length;c<e;++b,c+=2){d=f[c].lastIndexOf('function ');d==-1?(f[b]=rB,undefined):(f[b]=mw(lw(f[c],d+9)),undefined)}f.length=b;return f}
function om(a,b,c){if(!a){throw new nb('Null widget handle. If you are creating a composite, ensure that initWidget() has been called.')}b=mw(b);if(b.length==0){throw new Gv('Style names cannot be empty')}c?vc(a,b):xc(a,b)}
function Du(b){var a,c,d,e,f,g,h,i;g=Nl();if(g){try{f=Ql(g.b,RB);i=(Wf(),bg(f)).E();for(d=0;d<i.b.length;++d){e=Xe(i,d).G();h=Jf(e,GC).H().b;c=Jf(e,HC).F().b;_s(b.c.b,new xu(h,c,b))}}catch(a){a=wk(a);if(!Cg(a,46))throw a}}}
function br(a){if(a.d){a.b.style[wC]=vC;pm(a.b,true);pm(a.c,false);a.c.style[wC]=vC}else{pm(a.b,false);a.b.style[wC]=vC;a.c.style[wC]=vC;pm(a.c,true)}a.b.style[yC]=zC;a.c.style[yC]=zC;a.b=null;a.c=null;lm(a.e,false);a.e=null}
function gr(a,b,c){var d,e,f;if(c==b.v){return}wm(b);f=null;d=new Bs(a.c);while(d.b<d.c.d-1){e=zs(d);if(Dc(c,e.v)){if(e.v==c){f=e;break}As(d)}}qs(a.c,b);if(!f){tc(c.parentNode,b.v,c)}else{rc(c.parentNode,b.v,c);wq(a,f)}xm(b,a)}
function Cl(a){Bl();a.indexOf(MB)!=-1&&(a=gl(wl,a,'&amp;'));a.indexOf(PB)!=-1&&(a=gl(yl,a,'&lt;'));a.indexOf(OB)!=-1&&(a=gl(xl,a,'&gt;'));a.indexOf(vB)!=-1&&(a=gl(zl,a,'&quot;'));a.indexOf(QB)!=-1&&(a=gl(Al,a,'&#39;'));return a}
function um(a){var b;if(a.M()){throw new Jv("Should only call onAttach when the widget is detached from the browser's document")}a.r=true;_p(a.v,a);b=a.s;a.s=-1;b>0&&(a.s==-1?lq(a.v,b|(a.v.__eventBits||0)):(a.s|=b));a.K();a.Q()}
function Rv(a){var b,c,d;if(a<0){return 0}else if(a==0){return 32}else{d=-(a>>16);b=d>>16&16;c=16-b;a=a>>b;d=a-256;b=d>>16&8;c+=b;a<<=b;d=a-4096;b=d>>16&4;c+=b;a<<=b;d=a-16384;b=d>>16&2;c+=b;a<<=b;d=a>>14;b=d&~(d>>1);return c+2-b}}
function _u(a){this.q=a;this.p=Fc($doc);this.b=Fc($doc);this.d=Fc($doc);this.e=Fc($doc);this.f=Fc($doc);this.i=Fc($doc);this.j=Fc($doc);this.k=Fc($doc);this.n=Fc($doc);this.c=new _l(this.b);this.g=new _l(this.f);this.o=new _l(this.n)}
function su(a,b,c,d){var e;e=new Fw;e.b.b+="<div class='";Ew(e,Cl(c));e.b.b+="' data-timestamp='";Ew(e,Cl(d));e.b.b+="'>";Ew(e,a.b);e.b.b+=' <label>';Ew(e,b.b);e.b.b+="<\/label><button class='destroy'><\/a><\/div>";return new kl(e.b.b)}
function Hs(a,b){var c;if(!b){throw new Gv('display cannot be null')}else if(yA(a.c,b)){throw new Jv('The specified display has already been added to this adapter.')}xA(a.c,b);c=Rm(b,new Ms(a,b));jx(a.f,b,c);a.d>=0&&$m(b,a.d,a.e);Xs(a,b)}
function vc(a,b){var c,d,e,f;b=mw(b);f=a.className;c=f.indexOf(b);while(c!=-1){if(c==0||f.charCodeAt(c-1)==32){d=c+b.length;e=f.length;if(d==e||d<e&&f.charCodeAt(d)==32){break}}c=f.indexOf(b,c+1)}if(c==-1){f.length>0&&(f+=wB);a.className=f+b}}
function cr(a,b,c){var d,e,f,g;V(a);d=Cc(c.v);e=hq(Cc(d),d);if(!b){pm(d,true);pm(c.v,true);return}a.e=b;f=Cc(b.v);g=hq(Cc(f),f);if(e>g){a.b=f;a.c=d;a.d=false}else{a.b=d;a.c=f;a.d=true}pm(a.b,a.d);pm(a.c,!a.d);a.b=null;a.c=null;lm(a.e,false);a.e=null;pm(c.v,true)}
function Ik(a){var b,c,d;c=a.l;if((c&c-1)!=0){return -1}d=a.m;if((d&d-1)!=0){return -1}b=a.h;if((b&b-1)!=0){return -1}if(b==0&&d==0&&c==0){return -1}if(b==0&&d==0&&c!=0){return Sv(c)}if(b==0&&d!=0&&c==0){return Sv(d)+22}if(b!=0&&d==0&&c==0){return Sv(b)+44}return -1}
function gd(){fd();var a,b,c;c=null;if(ed.length!=0){a=ed.join(rB);b=sd((od(),nd),a);!ed&&(c=b);ed.length=0}if(cd.length!=0){a=cd.join(rB);b=rd((od(),nd),a);!cd&&(c=b);cd.length=0}if(dd.length!=0){a=dd.join(rB);b=rd((od(),nd),a);!dd&&(c=b);dd.length=0}bd=false;return c}
function Qk(a,b){var c,d,e,f,g;b&=63;c=a.h;d=(c&524288)!=0;d&&(c|=-1048576);if(b<22){g=c>>b;f=a.m>>b|c<<22-b;e=a.l>>b|a.m<<22-b}else if(b<44){g=d?1048575:0;f=c>>b-22;e=a.m>>b-22|c<<44-b}else{g=d?1048575:0;f=d?4194303:0;e=c>>b-44}return Ak(e&4194303,f&4194303,g&1048575)}
function Av(a){var b,c,d,e;if(a==null){throw new ew(sB)}c=a.length;d=c>0&&a.charCodeAt(0)==45?1:0;for(b=d;b<c;++b){if(mv(a.charCodeAt(b))==-1){throw new ew(IC+a+vB)}}e=parseInt(a,10);if(isNaN(e)){throw new ew(IC+a+vB)}else if(e<-2147483648||e>2147483647){throw new ew(IC+a+vB)}return e}
function Yq(a,b){var c,d,e;c=(d=$doc.createElement(SB),d.style[uC]=vC,d.style[wC]=xC,d.style['padding']=xC,d.style['margin']=xC,d);Ap(a.v,c);tq(a,b,c);pm(c,false);c.style[wC]=vC;e=b.v;kw(e.style[uC],rB)&&(b.v.style[uC]=vC,undefined);kw(e.style[wC],rB)&&(b.v.style[wC]=vC,undefined);pm(b.v,false)}
function nr(){var c=function(){};c.prototype={className:rB,clientHeight:0,clientWidth:0,dir:rB,getAttribute:function(a,b){return this[a]},href:rB,id:rB,lang:rB,nodeType:1,removeAttribute:function(a,b){this[a]=undefined},setAttribute:function(a,b){this[a]=b},src:rB,style:{},title:rB};$wnd.GwtPotentialElementShim=c}
function xc(a,b){var c,d,e,f,g,h,i;b=mw(b);i=a.className;e=i.indexOf(b);while(e!=-1){if(e==0||i.charCodeAt(e-1)==32){f=e+b.length;g=i.length;if(f==g||f<g&&i.charCodeAt(f)==32){break}}e=i.indexOf(b,e+1)}if(e!=-1){c=mw(i.substr(0,e-0));d=mw(lw(i,e+b.length));c.length==0?(h=d):d.length==0?(h=c):(h=c+wB+d);a.className=h}}
function ye(b,c){var a,d,e,f,g,h;if(!c){throw new aw('Cannot fire null event')}try{++b.c;g=Be(b,c.z());d=null;h=b.d?g.jb(g.mb()):g.ib();while(b.d?h.pb():h.$()){f=b.d?h.qb():h._();try{c.y(Ag(f,10))}catch(a){a=wk(a);if(Cg(a,52)){e=a;!d&&(d=new AA);xA(d,e)}else throw a}}if(d){throw new Ke(d)}}finally{--b.c;b.c==0&&De(b)}}
function Mk(a){var b,c,d,e,f;if(isNaN(a)){return $k(),Zk}if(a<-9223372036854775808){return $k(),Xk}if(a>=9223372036854775807){return $k(),Wk}e=false;if(a<0){e=true;a=-a}d=0;if(a>=17592186044416){d=Gg(a/17592186044416);a-=d*17592186044416}c=0;if(a>=4194304){c=Gg(a/4194304);a-=c*4194304}b=Gg(a);f=Ak(b,c,d);e&&Gk(f);return f}
function mo(a){if(!a.b){a.b=true;fd();hd('.GPBYFDEAB,.GPBYFDECB{cursor:pointer;zoom:1;}.GPBYFDEBB{background:#ffc;}.GPBYFDEDB{height:'+(oo(),io.b)+'px;overflow:hidden;background:url("'+io.e.b+'") -'+io.c+'px -'+io.d+'px  repeat-x;background-color:#628cd5;color:white;height:auto;overflow:visible;}');return true}return false}
function Uk(a){var b,c,d,e,f;if(a.l==0&&a.m==0&&a.h==0){return KB}if(a.h==524288&&a.m==0&&a.l==0){return '-9223372036854775808'}if(a.h>>19!=0){return '-'+Uk(Ok(a))}c=a;d=rB;while(!(c.l==0&&c.m==0&&c.h==0)){e=Nk(1000000000);c=Bk(c,e,true);b=rB+Tk(xk);if(!(c.l==0&&c.m==0&&c.h==0)){f=9-b.length;for(;f>0;--f){b=KB+b}}d=b+d}return d}
function ag(b,c){var d;if(c&&(Eb(),Db)){try{d=JSON.parse(b)}catch(a){return cg(HB+a)}}else{if(c){if(!(Eb(),!/[^,:{}\[\]0-9.\-+Eaeflnr-u \n\r\t]/.test(b.replace(/"(\\.|[^"\\])*"/g,rB)))){return cg('Illegal character in JSON string')}}b=Gb(b);try{d=eval(uB+b+IB)}catch(a){return cg(HB+a)}}var e=Vf[typeof d];return e?e(d):dg(typeof d)}
function ao(a){var b;an.call(this,$doc.createElement(SB));Bl();new sl(rB);this.e=new Jr;this.f=new Jr;this.g=new $q;this.b=a;this.i=(po(),jo);mo(this.i);om(this.v,'GPBYFDEEB',true);this.d=$doc.createElement(SB);b=this.v;oc(b,this.d);oc(b,this.g.v);this.g.S(this);Yq(this.g,this.e);Yq(this.g,this.f);Jn((!Hn&&(Hn=new On),Hn),this,a.d)}
function Vn(a,b){var c,d,e,f,g,h,i,j,k,l,m;e=b.target;if(!Ac(e)){return}l=b.target;h=rB;c=l;while(!!c&&(h=c.getAttribute('__idx')||rB).length==0){c=Cc(c)}if(h.length>0){f=b.type;kw(yB,f);g=Av(h);i=g-Bo(a.o).c;if(!(i>=0&&i<xo(a.o).n.c)){return}j=(jp(),gp)==a.o.e;m=(Sm(a,i),zo(a.o,i));d=new eb(g,a.o);k=Rs(a,b,a,d,a.c,j);k.d||Sn(a,b,c,m)}}
function nu(a,b,c){var d,e,f;if(a.c==b){d=ru(b.d);Ew(c.b,d.b)}else{d=su(b.b?(e=new Fw,e.b.b+="<input class='toggle' type='checkbox' checked>",new kl(e.b.b)):(f=new Fw,f.b.b+="<input class='toggle' type='checkbox'>",new kl(f.b.b)),(Bl(),new sl(Cl(b.d))),b.b?'listItem view done':'listItem view',rB+Uk(Mk((new kA).b.getTime())));Ew(c.b,d.b)}}
function nq(){var d=$wnd.onbeforeunload;var e=$wnd.onunload;$wnd.onbeforeunload=function(a){var b,c;try{b=pB(Pp)()}finally{c=d&&d(a)}if(b!=null){return b}if(c!=null){return c}};$wnd.onunload=pB(function(a){try{Kp&&ie((!Lp&&(Lp=new Xp),Lp))}finally{e&&e(a);$wnd.onresize=null;$wnd.onscroll=null;$wnd.onbeforeunload=null;$wnd.onunload=null}})}
function uo(a,b,c){var d,e,f,g,h,i,j,k,l,m,n;Po(a);l=-1;h=-1;m=-1;i=-1;g=0;for(e=0;e<a.length;++e){f=a[e];if(f<b||f>=c){continue}else if(l==-1){l=f;h=f}else if(m==-1){g=f-h;m=f;i=f}else{d=f-i;if(d>g){h=i;m=f;i=f;g=d}else{i=f}}}h+=1;i+=1;if(m==h){h=i;m=-1;i=-1}n=new $y;if(l!=-1){j=h-l;Ry(n,new Ot(l,j))}if(m!=-1){k=i-m;Ry(n,new Ot(m,k))}return n}
function Io(a,b,c){var d,e,f,g,h,i,j,k,l,m,n;n=c.mb();m=b+n;j=(!a.f?a.j:a.f).i;i=(!a.f?a.j:a.f).i+(!a.f?a.j:a.f).g;e=b>j?b:j;d=m<i?m:i;if(b!=j&&e>=d){return}k=vo(a);f=Yv(0,e-j-(!a.f?a.j:a.f).n.c);for(h=0;h<f;++h){Ry(k.n,null)}for(h=e;h<d;++h){l=c.fb(h-b);g=h-j;g<(!a.f?a.j:a.f).n.c?Yy(k.n,g,l):Ry(k.n,l)}Ry(k.d,new Ot(e-f,d-(e-f)));m>(!a.f?a.j:a.f).j&&Ho(a,m,(!a.f?a.j:a.f).k)}
function Ek(a,b,c,d,e,f){var g,h,i,j,k,l,m;j=Hk(b)-Hk(a);g=Pk(b,j);i=Ak(0,0,0);while(j>=0){h=Jk(a,g);if(h){j<22?(i.l|=1<<j,undefined):j<44?(i.m|=1<<j-22,undefined):(i.h|=1<<j-44,undefined);if(a.l==0&&a.m==0&&a.h==0){break}}k=g.m;l=g.h;m=g.l;g.h=l>>>1;g.m=k>>>1|(l&1)<<21;g.l=m>>>1|(k&1)<<21;--j}c&&Gk(i);if(f){if(d){xk=Ok(a);e&&(xk=Sk(xk,($k(),Yk)))}else{xk=Ak(a.l,a.m,a.h)}}return i}
function lu(a,b,c,d){var e,f,g,h,i,j;j=d.type;if(a.c==c){if(kw(zB,j)){h=d.keyCode||0;if(h==13){ju(b,c);a.c=null;pu(a,b,c)}h==27&&(a.c=null,pu(a,b,c))}if(kw(WB,j)&&!a.b){ju(b,c);a.c=null;pu(a,b,c)}}else{if(kw(eC,j)){a.c=c;pu(a,b,c);a.b=true;g=qc(b.firstChild);g.focus();a.b=false}if(kw(yB,j)){f=d.target;e=f;i=e.tagName;if(kw(i,DC)){g=e;uu(c,!!g.checked);g.checked?vc(b.firstChild,EC):xc(b.firstChild,EC)}else kw(i,sC)&&Bu(c.c,c)}}}
function vk(){var a,b;!!$stats&&fl('com.google.gwt.useragent.client.UserAgentAsserter');a=Fs();kw(JB,a)||($wnd.alert('ERROR: Possible problem with your *.gwt.xml module file.\nThe compile time user.agent value (opera) does not match the runtime user.agent value ('+a+'). Expect more errors.\n'),undefined);!!$stats&&fl('com.google.gwt.user.client.DocumentModeAsserter');Ep();!!$stats&&fl('com.todo.client.GwtToDo');b=new Qu;new Hu(b);Aq((tr(),xr()),b)}
function kq(a,b){switch(b){case 'drag':a.ondrag=fq;break;case 'dragend':a.ondragend=fq;break;case 'dragenter':a.ondragenter=eq;break;case 'dragleave':a.ondragleave=fq;break;case 'dragover':a.ondragover=eq;break;case 'dragstart':a.ondragstart=fq;break;case 'drop':a.ondrop=fq;break;case 'canplaythrough':case 'ended':case 'progress':a.removeEventListener(b,fq,false);a.addEventListener(b,fq,false);break;default:throw 'Trying to sink unknown event type '+b;}}
function $u(a){var b,c,d,e,f,g,h,i,j,k,l;c=new hr(bv(a.b,a.d,a.e,a.f,a.i,a.j,a.k,a.n).b);b=bm(c.v);$l(a.c);d=$l(new _l(a.d));a.q.d=d;e=$l(new _l(a.e));a.q.k=e;$l(a.g);f=$l(new _l(a.i));a.q.i=f;g=$l(new _l(a.j));a.q.e=g;h=$l(new _l(a.k));a.q.f=h;$l(a.o);b.c?rc(b.c,b.b,b.d):dm(b.b);fr(c,(i=new hu,i.v.setAttribute('placeholder','What needs to be done?'),a.q.g=i,i),$l(a.c));fr(c,a.q.j,$l(a.g));fr(c,(j=new Vq,Tq(j,av(a.p).b),k=bm(j.v),l=$l(new _l(a.p)),a.q.c=l,k.c?rc(k.c,k.b,k.d):dm(k.b),a.q.b=j,j),$l(a.o));return c}
function Jo(a,b,c){var d,e,f,g,h,i,j,k,l,m;m=b.c;g=b.b;if(m<0){throw new Gv('Range start cannot be less than 0')}if(g<0){throw new Gv('Range length cannot be less than 0')}j=(!a.f?a.j:a.f).i;h=(!a.f?a.j:a.f).g;k=j!=m;if(k){l=vo(a);if(!c){if(m>j){f=m-j;if((!a.f?a.j:a.f).n.c>f){for(e=0;e<f;++e){Wy(l.n,0)}}else{Ty(l.n)}}else{d=j-m;if((!a.f?a.j:a.f).n.c>0&&d<h){for(e=0;e<d;++e){Qy(l.n,0,null)}Ry(l.d,new Ot(m,m+d-m))}else{Ty(l.n)}}}l.i=m}i=h!=g;i&&(vo(a).g=g);c&&Ty(vo(a).n);Ko(a);(k||i)&&Xt(a.b,new Ot((!a.f?a.j:a.f).i,(!a.f?a.j:a.f).g))}
function mq(a,b){a.__eventBits=b;a.onclick=b&1?fq:null;a.ondblclick=b&2?fq:null;a.onmousedown=b&4?fq:null;a.onmouseup=b&8?fq:null;a.onmouseover=b&16?fq:null;a.onmouseout=b&32?fq:null;a.onmousemove=b&64?fq:null;a.onkeydown=b&128?fq:null;a.onkeypress=b&256?fq:null;a.onkeyup=b&512?fq:null;a.onchange=b&1024?fq:null;a.onfocus=b&2048?fq:null;a.onblur=b&4096?fq:null;a.onlosecapture=b&8192?fq:null;a.onscroll=b&16384?fq:null;a.onload=b&32768?gq:null;a.onerror=b&65536?fq:null;a.onmousewheel=b&131072?fq:null;a.oncontextmenu=b&262144?fq:null;a.onpaste=b&524288?fq:null}
function Fs(){var b=navigator.userAgent.toLowerCase();var c=function(a){return parseInt(a[1])*1000+parseInt(a[2])};if(function(){return b.indexOf(JB)!=-1}())return JB;if(function(){return b.indexOf('webkit')!=-1}())return 'safari';if(function(){return b.indexOf(AC)!=-1&&$doc.documentMode>=9}())return 'ie9';if(function(){return b.indexOf(AC)!=-1&&$doc.documentMode>=8}())return 'ie8';if(function(){var a=/msie ([0-9]+)\.([0-9]+)/.exec(b);if(a&&a.length==3)return c(a)>=6000}())return 'ie6';if(function(){return b.indexOf('gecko')!=-1}())return 'gecko1_8';return 'unknown'}
function Zp(a){switch(a){case WB:return 4096;case 'change':return 1024;case yB:return 1;case eC:return 2;case VB:return 2048;case XB:return 128;case fC:return 256;case zB:return 512;case bC:return 32768;case 'losecapture':return 8192;case YB:return 4;case gC:return 64;case hC:return 32;case iC:return 16;case jC:return 8;case 'scroll':return 16384;case cC:return 65536;case 'DOMMouseScroll':case kC:return 131072;case 'contextmenu':return 262144;case 'paste':return 524288;case lC:return 1048576;case mC:return 2097152;case nC:return 4194304;case oC:return 8388608;case pC:return 16777216;case qC:return 33554432;case rC:return 67108864;default:return -1;}}
function Fo(a,b,c,d){var e,f,g,h,i,j,k,l;if((jp(),hp)==a.e){return}a.d.b&&(b=Yv(0,Zv(b,(!a.f?a.j:a.f).n.c-1)));vo(a).q=true;if(!d&&(hp==a.e?-1:(!a.f?a.j:a.f).e)==b&&(hp==a.e?null:(!a.f?a.j:a.f).f)!=null){return}i=(!a.f?a.j:a.f).i;h=(!a.f?a.j:a.f).g;k=(!a.f?a.j:a.f).j;e=i+b;e>=k&&(!a.f?a.j:a.f).k&&(e=k-1);b=(0>e?0:e)-i;a.d.b&&(b=0>(b<h-1?b:h-1)?0:b<h-1?b:h-1);g=i;f=h;j=vo(a);j.e=0;j.f=null;j.b=true;if(b>=0&&b<h){j.e=b;j.f=b<j.n.c?Uo(vo(a),b):null;j.c=c;return}else if((bp(),$o)==a.d){while(b<0){l=h<g?h:g;g-=l;b+=l}while(b>=h){g+=h;b-=h}}else if(ap==a.d){while(b<0){l=30<g?30:g;f+=l;g-=l;b+=l}while(b>=f){f+=30}if((!a.f?a.j:a.f).k){f=f<k-g?f:k-g;b>=k&&(b=k-1)}}if(g!=i||f!=h){j.e=b;Jo(a,new Ot(g,f),false)}}
function Bk(a,b,c){var d,e,f,g,h,i,j,k;if(b.l==0&&b.m==0&&b.h==0){throw new dv}if(a.l==0&&a.m==0&&a.h==0){c&&(xk=Ak(0,0,0));return Ak(0,0,0)}if(b.h==524288&&b.m==0&&b.l==0){return Ck(a,c)}i=false;if(b.h>>19!=0){b=Ok(b);i=true}g=Ik(b);f=false;e=false;d=false;if(a.h==524288&&a.m==0&&a.l==0){e=true;f=true;if(g==-1){a=zk(($k(),Wk));d=true;i=!i}else{h=Qk(a,g);i&&Gk(h);c&&(xk=Ak(0,0,0));return h}}else if(a.h>>19!=0){f=true;a=Ok(a);d=true;i=!i}if(g!=-1){return Dk(a,g,i,f,c)}if(!(j=a.h>>19,k=b.h>>19,j==0?k!=0||a.h>b.h||a.h==b.h&&a.m>b.m||a.h==b.h&&a.m==b.m&&a.l>=b.l:!(k==0||a.h<b.h||a.h==b.h&&a.m<b.m||a.h==b.h&&a.m==b.m&&a.l<b.l))){c&&(f?(xk=Ok(a)):(xk=Ak(a.l,a.m,a.h)));return Ak(0,0,0)}return Ek(d?a:Ak(a.l,a.m,a.h),b,i,f,e,c)}
function Ep(){var a,b,c;b=$doc.compatMode;a=rg(uk,VA,1,[dC]);for(c=0;c<a.length;++c){if(kw(a[c],b)){return}}a.length==1&&kw(dC,a[0])&&kw('BackCompat',b)?"GWT no longer supports Quirks Mode (document.compatMode=' BackCompat').<br>Make sure your application's host HTML page has a Standards Mode (document.compatMode=' CSS1Compat') doctype,<br>e.g. by using &lt;!doctype html&gt; at the start of your application's HTML page.<br><br>To continue using this unsupported rendering mode and risk layout problems, suppress this message by adding<br>the following line to your*.gwt.xml module file:<br>&nbsp;&nbsp;&lt;extend-configuration-property name=\"document.compatMode\" value=\""+b+'"/&gt;':"Your *.gwt.xml module configuration prohibits the use of the current doucment rendering mode (document.compatMode=' "+b+"').<br>Modify your application's host HTML page doctype, or update your custom 'document.compatMode' configuration property settings."}
function bv(a,b,c,d,e,f,g,h){var i;i=new Fw;i.b.b+="<section id='todoapp'> <header id='header'> <h1>todos<\/h1> <span id='";Ew(i,Cl(a));i.b.b+="'><\/span> <\/header> <section id='";Ew(i,Cl(b));i.b.b+="'> <input id='";Ew(i,Cl(c));i.b.b+="' type='checkbox'> <label for='toggle-all'>Mark all as complete<\/label> <div id='todo-list'> <span id='";Ew(i,Cl(d));i.b.b+="'><\/span> <\/div> <\/section> <footer id='";Ew(i,Cl(e));i.b.b+="'> <span id='todo-count'> <strong class='number' id='";Ew(i,Cl(f));i.b.b+="'><\/strong> <span class='word' id='";Ew(i,Cl(g));i.b.b+="'><\/span> left <\/span> <span id='";Ew(i,Cl(h));i.b.b+="'><\/span> <\/footer> <\/section> <footer id='info'> <p>Double-click to edit a todo<\/p> <p>Template by <a href='http://sindresorhus.com'>Sindre Sorhus<\/a><\/p> <p>Created by <a href='http://www.scottlogic.co.uk/blog/colin/'>Colin Eberhardt<\/a><\/p> <p>Part of <a href='http://todomvc.com'>TodoMVC<\/a><\/p> <\/footer>";return new kl(i.b.b)}
function iq(){cq=pB(function(a){return true});fq=pB(function(a){var b,c=this;while(c&&!(b=c.__listener)){c=c.parentNode}c&&c.nodeType!=1&&(c=null);b&&aq(b)&&Bp(a,c,b)});eq=pB(function(a){a.preventDefault();fq.call(this,a)});gq=pB(function(a){this.__gwtLastUnhandledEvent=a.type;fq.call(this,a)});dq=pB(function(a){var b=cq;if(b(a)){var c=bq;if(c&&c.__listener){if(aq(c.__listener)){Bp(a,c,c.__listener);a.stopPropagation()}}}});$wnd.addEventListener(yB,dq,true);$wnd.addEventListener(eC,dq,true);$wnd.addEventListener(YB,dq,true);$wnd.addEventListener(jC,dq,true);$wnd.addEventListener(gC,dq,true);$wnd.addEventListener(iC,dq,true);$wnd.addEventListener(hC,dq,true);$wnd.addEventListener(kC,dq,true);$wnd.addEventListener(XB,cq,true);$wnd.addEventListener(zB,cq,true);$wnd.addEventListener(fC,cq,true);$wnd.addEventListener(lC,dq,true);$wnd.addEventListener(mC,dq,true);$wnd.addEventListener(nC,dq,true);$wnd.addEventListener(oC,dq,true);$wnd.addEventListener(pC,dq,true);$wnd.addEventListener(qC,dq,true);$wnd.addEventListener(rC,dq,true)}
function Eb(){var a;Eb=RA;Cb=(a=['\\u0000','\\u0001','\\u0002','\\u0003','\\u0004','\\u0005','\\u0006','\\u0007','\\b','\\t','\\n','\\u000B','\\f','\\r','\\u000E','\\u000F','\\u0010','\\u0011','\\u0012','\\u0013','\\u0014','\\u0015','\\u0016','\\u0017','\\u0018','\\u0019','\\u001A','\\u001B','\\u001C','\\u001D','\\u001E','\\u001F'],a[34]='\\"',a[92]='\\\\',a[173]='\\u00ad',a[1536]='\\u0600',a[1537]='\\u0601',a[1538]='\\u0602',a[1539]='\\u0603',a[1757]='\\u06dd',a[1807]='\\u070f',a[6068]='\\u17b4',a[6069]='\\u17b5',a[8203]='\\u200b',a[8204]='\\u200c',a[8205]='\\u200d',a[8206]='\\u200e',a[8207]='\\u200f',a[8232]='\\u2028',a[8233]='\\u2029',a[8234]='\\u202a',a[8235]='\\u202b',a[8236]='\\u202c',a[8237]='\\u202d',a[8238]='\\u202e',a[8288]='\\u2060',a[8289]='\\u2061',a[8290]='\\u2062',a[8291]='\\u2063',a[8292]='\\u2064',a[8298]='\\u206a',a[8299]='\\u206b',a[8300]='\\u206c',a[8301]='\\u206d',a[8302]='\\u206e',a[8303]='\\u206f',a[65279]='\\ufeff',a[65529]='\\ufff9',a[65530]='\\ufffa',a[65531]='\\ufffb',a);Db=typeof JSON=='object'&&typeof JSON.parse=='function'}
function Do(b,c){var a,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O;b.g=null;if(b.c){return false}b.c=true;if(!b.f){b.c=false;b.i=0;return false}++b.i;if(b.i>10){b.c=false;b.i=0;throw new Jv('A possible infinite loop has been detected in a Cell Widget. This usually happens when your SelectionModel triggers a SelectionChangeEvent when SelectionModel.isSelection() is called, which causes the table to redraw continuously.')}t=b.j;l=b.f;b.j=b.f;b.f=null;!c&&(c=[]);y=l.i;x=l.g;w=y+x;K=l.n.c;l.e=Yv(0,Zv(l.e,K-1));if((jp(),hp)==b.e){l.e=0;l.f=null}else if(l.b){l.f=K>0?Uo(l,l.e):null}else if(l.f!=null){e=wo(l,l.f,l.e);if(e>=0){l.e=e;l.f=K>0?Uo(l,l.e):null}else{l.e=0;l.f=null}}try{if(gp==b.e&&false){u=t.p;m=K>0?Uo(l,l.e):null;if(m!=null){v=u!=null&&null.yb();n=m!=null&&null.yb();if(yb(m,u)){n||(l.p=null)}else{v&&null.yb();l.p=m;m!=null&&!n&&null.yb()}}}}catch(a){a=wk(a);if(Cg(a,50)){f=a;b.c=false;b.i=0;throw f}else throw a}h=l.b||t.e!=l.e||t.f==null&&l.f!=null;o=new AA;try{for(g=y;g<y+K;++g){Uy(l.n,g-y);M=yA(t.o,Vv(g));M&&Ab(c,g)}}catch(a){a=wk(a);if(Cg(a,50)){f=a;b.c=false;b.i=0;throw f}else throw a}H=false;for(J=new oy(l.d);J.c<J.e.mb();){I=Ag(my(J),33);L=I.c;i=I.b;i==0&&(H=true);for(g=L;g<L+i;++g){Ab(c,g)}}if(c.length>0&&h){Ab(c,t.e);Ab(c,l.e)}if(b.f){b.c=false;b.f.p=l.p;b.f.o.cb(o);h&&(b.f.b=true);l.c&&(b.f.c=true);Ab(c,t.e);Ab(c,l.e);if(Do(b,c)){return true}}j=uo(c,y,w);B=j.c>0?Ag(($x(0,j.c),j.b[0]),33):null;C=j.c>1?Ag(($x(1,j.c),j.b[1]),33):null;F=0;for(A=new oy(j);A.c<A.e.mb();){z=Ag(my(A),33);F+=z.b}q=t.i;p=t.g;r=t.n.c;D=false;y!=q?(D=true):K<r?(D=true):!C&&!!B&&B.c==y&&(F>=r||F>p)?(D=true):F>=5&&F>0.3*r?(D=true):H&&r==0&&(D=true);N=(!b.f?b.j:b.f).n.c;O=(!b.f?b.j:b.f).k?Zv((!b.f?b.j:b.f).g,(!b.f?b.j:b.f).j-(!b.f?b.j:b.f).i):(!b.f?b.j:b.f).g;N>=O?yn(b.k,(xp(),up)):N==0?yn(b.k,(xp(),vp)):yn(b.k,(xp(),wp));try{if(D){new ql;un(b.k,l.n,l.c);wn(b.k)}else if(B){d=B.c;E=d-y;new ql;G=new xy(l.n,E,E+B.b);vn(b.k,G,E,l.c);if(C){d=C.c;E=d-y;new ql;G=new xy(l.n,E,E+C.b);vn(b.k,G,E,l.c)}wn(b.k)}else if(h){s=t.e;s>=0&&s<K&&xn(b.k,s,false,false);k=l.e;k>=0&&k<K&&xn(b.k,k,true,l.c)}}catch(a){a=wk(a);if(Cg(a,45)){f=a;throw new pb(f)}else throw a}finally{b.c=false}Do(b,null);return true}
function El(){this.b='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFIAAAAaCAYAAAAkJwuaAAAHt0lEQVR42u1SWVeURxD9fiqLuOFugp5ojjsuzMBIEDXHFSOKRIHI9kNmBgYERkHEhWQcQB47XWtX94xPyaMP91RX1a1bt76ZrG961/XNBPROf3N9syEvzMZ1jDO7jZhtfAMX52fNe4bnjY5oCjetx7rfIl+pXgHfpi+a3/M9sxvdlUboRd/A9MO3+uYySPLTO764wxHyUEv7eRbIa27n4mgRa3/Tt61Zrd7v1prvEG8Bu4nP5l56k3vi+3cbZuKdYW+Wn9rGJDdFwNwjN+nzyW2G9KS2RXFqSznam5IcdO17h3Lo465t5eent7QGnLzujd8KvxdnJsW7eOZcdCd3ON+Kenn0tMX7hC+3hzzcs0Mz0zsufK/taD678deWE/S85ncStc7vHunB+/V2qL+OZ+2cziO3Hmr+DRrxjnrQg9oEoB68mF7k2XqYYE+TW9Gc3qRekv5EvcGz6Ik+cet0B+/Jro1/ddfG6+7a2Fd3dbzmro4BfG0CcgJyJoBTw3jdA7gQsT5RYx7nfv46zGOsoxZwcNZzUB+44zXdQxzag/kYY7zOs7xvvB57klmuiXfSD36CvszVlX+dta5P1I1GTW+jnaQFPb1rvK6a2ZWX/zhAN+PKq5BDvPyy5rrHoO7jq6++ZnPiIP8VzNRofizUr1iO/yG6hQtvbwj7jMvIYbykfd3pXtSuEUCHfZCn4EU0YY/W/b7ul7RHvHVHHmuhZ/Ox+I7L9nuNkW528c+/HeASQ94XRzfNO/QuvKA61GyfdDZDfTTWDJx0T8ClRM/2I51R2nVJdtr3qKlFvKAf8s34vlG6O3DiWXtjWs/OPf/izo8APjt6QxSE/PzIZoD/mOe5h32OCJmF94vPxB2hSDrw/oI6oK/cEbtzE2vnrDZrnROvii+860vQey75Z90pPNl3AfojPDMSe470Rqzm58B9Hr4LxOzs8Ib79dlHd/YpwL+HP3lw7t9Qk/rZpwTo//qMefCG3jDNgx7MYp915Q2RND+aHfQ+gzs+sk7wgH6esY9kBv2g30/sgeIZ2Tn8KdyA7w2e4ZuHrR/pi3/7DT6qBt3CO58xz89lv/zxwUV4AnGDcxOfbHBu37Zn+Jp/CPnQh+/MmRrsHvrQqIWwPesN6nZ/sju9I+pvNJ95Ym568r25eEd2+vG663q05iCe8vHUo/fu1OP3PodoahAfvw/QmXXiD9GMBXKGZIbnI33hroca6q0HP6LNOKX8ddXA95B49L0h63eNdsgs6qyrjvod4nutrvX/iHDafgP0SLzs5werruvBmoNI8O+HnD9cDW/be8i9ByF2ab4WuDrXRCvdYfUeyvya0VnDHxz2dKlHyJtoPmjij+fphtRP7FVvifyYHU362Yl779xJhr7vx2/bOyHv+6s6d/LeqrM6kFtu1MM54Nv5dw3z0v/p/qrRWdW9J4y3Ru3GnannhrsjzmoTT83uDsiO//7WHUOsYDyuWHHUq5pawDGN0K/ifGN8m2iI5kqkGzSqTfYEvWMY35pceFXjZ8XMV6P+MVOLb61GIB8riZ9q5DXdmR25u+KO3Fl2RyF6HGUcubvsUcUevEO9yvwq5XeYyzziVpFHMxKXmVtVrbDTzi4bP5QrF3esqJ76kf3sK3jmaG6wUd/Jjek+ywt3xPzs0O0ld/j2sseSOzS4RBGxrPnhO1SLOIPEOaxYatDAOdFgPYFy73CPIfvCrPEBGIz3HG7iy9ZTNOvbWoO/iLNsbo/7WefAkjs48MbDx1tv8N3pYydE7S26zkGOt0IfZjpvEUf6pLFI87eoTjNmtgFL+qb9S6zdfDbsXWRPcBTvh96g+It9H5R52WfvEx8DokteSPeN8lQD30v6zg70LzrEbws+VtyBAckJ+/sXqOb78MYcepY3wLM+3w86zIX8YKS3EGsjt8KaMAMaC2RSdjP29y+qjwP9wQvpV0iLtaGGWrITovhGVPQGuU/84g2gx98ixAXaIVzR5Vq272bF7bu54Ch6wADEgtTn/Zujx94CcahWCX2o3ZS6iczBOdlxM5n12FuY93tlXyXe15AzV/b2Bz2sS834JlR4hjzs1zl7Z/I9NLee502P3tnevorr6Jtzez06+sAovQnzoe7RwYCj4SCcK8xznMMYtLhWEP689mhHhXXNnNeUumgjZKYwr57En3juKMzpXOSrr2JusHeae4xv2iP3JP1C4GjO3yHb01t2e3rn3J48oQPeHu15rktPOfNab5e65Zh6u9eWt+jG3HLzmDdIZtqtT9vvDXvakxrw2u18bznqx3eU49t7E/9NdgKytlwJhdryJRRoYyGKvp7jCDXmtkvPz1C9zLVy1Fee7MiBru0DShrbolo54ZWNz7moT/vjOu0qNfHEu5Jbgl56j62V1FuqncGHaPWk1p6SRxEXUIR6CQdac0X+YEWqCfiDIz9f5FjmXhF1IdIHL9EO0OgpkT7zW3NsLldkfpk5MiMeJC/r7jbxxse28gfEOnsUDZzP0w1yI91S1D9FvK+sd6AfuU3vK+l9mRzWeqOoH1MPjmpF1yJ5rqQf1H4c5OeKmhNfNIJB1WQd4bXYfTnObxgt2cdaLT3F2K/Z0ZJ4aeX5lh6pWz/El5nYR7JLZsUb9zM19gP/CT8+5P+EfwFEPZjKzXkk0QAAAABJRU5ErkJggg=='}
var rB='',wB=' ',vB='"',MB='&',QB="'",uB='(',IB=')',BB=',',EB=', ',CC=', Size: ',KB='0',xC='0px',vC='100%',FB=':',qB=': ',PB='<',JC='=',OB='>',sC='BUTTON',dC='CSS1Compat',HB='Error parsing JSON: ',IC='For input string: "',ZB='GPBYFDEBB',DC='INPUT',BC='Index: ',tB='String',SC='UmbrellaException',AB='[',XC='[Lcom.google.gwt.user.cellview.client.',ZC='[Lcom.google.gwt.user.client.ui.',NC='[Ljava.lang.',CB=']',_B='__gwtCellBasedWidgetImplDispatching',WB='blur',aC='button',tC='className',yB='click',eD='com.google.gwt.animation.client.',_C='com.google.gwt.cell.client.',MC='com.google.gwt.core.client.',UC='com.google.gwt.core.client.impl.',hD='com.google.gwt.dom.client.',cD='com.google.gwt.event.dom.client.',WC='com.google.gwt.event.logical.shared.',TC='com.google.gwt.event.shared.',bD='com.google.gwt.json.client.',OC='com.google.gwt.lang.',fD='com.google.gwt.safehtml.shared.',aD='com.google.gwt.storage.client.',iD='com.google.gwt.text.shared.testing.',gD='com.google.gwt.uibinder.client.',VC='com.google.gwt.user.cellview.client.',dD='com.google.gwt.user.client.',PC='com.google.gwt.user.client.ui.',YC='com.google.gwt.view.client.',RC='com.google.web.bindery.event.shared.',QC='com.todo.client.',HC='complete',eC='dblclick',UB='display',SB='div',EC='done',cC='error',VB='focus',KC='fromIndex: ',NB='g',qC='gesturechange',rC='gestureend',pC='gesturestart',wC='height',LB='html is null',LC='java.lang.',$C='java.util.',XB='keydown',fC='keypress',zB='keyup',bC='load',YB='mousedown',gC='mousemove',hC='mouseout',iC='mouseover',jC='mouseup',kC='mousewheel',AC='msie',TB='none',sB='null',JB='opera',yC='overflow',xB='style',GC='task',RB='todo-gwt',oC='touchcancel',nC='touchend',mC='touchmove',lC='touchstart',$B='true',FC='value',zC='visible',uC='width',DB='{',GB='}';var _,cl={},bB={9:1,11:1,22:1,23:1,25:1,26:1,28:1,30:1},kB={41:1},jB={35:1},aB={9:1,11:1,22:1,23:1,26:1,28:1,30:1},lB={56:1},hB={29:1,39:1,42:1,44:1},UA={},$A={7:1,10:1},iB={55:1},cB={9:1,11:1,22:1,23:1,25:1,26:1,28:1,30:1,32:1},YA={11:1},oB={39:1,55:1},gB={9:1,11:1,22:1,23:1,24:1,26:1,27:1,28:1,30:1},mB={58:1},fB={9:1,11:1,22:1,23:1,24:1,26:1,28:1,30:1},_A={17:1,39:1},dB={10:1,31:1},eB={8:1,10:1},WA={39:1,46:1,50:1,52:1},nB={57:1},VA={39:1},XA={3:1,4:1,39:1,42:1,44:1},ZA={36:1,39:1,46:1,50:1,52:1};dl(1,-1,UA);_.eQ=function R(a){return this===a};_.gC=function S(){return this.cZ};_.hC=function T(){return Sb(this)};_.tS=function U(){return this.cZ.d+'@'+Tv(this.hC())};_.toString=function(){return this.tS()};_.tM=RA;dl(3,1,{});_.f=false;_.g=false;_.i=false;dl(4,1,{});dl(5,4,{});dl(6,5,{},ab);dl(7,1,{});_.d=null;dl(8,1,{},eb);_.b=0;dl(14,1,{39:1,52:1});_.w=function lb(){return this.f};_.tS=function mb(){return kb(this)};_.f=null;dl(13,14,{39:1,46:1,52:1});dl(12,13,WA,nb,pb);dl(11,12,{2:1,39:1,46:1,50:1,52:1},qb);_.w=function wb(){this.d==null&&(this.e=tb(this.c),this.b=this.b+qB+rb(this.c),this.d=uB+this.e+') '+vb(this.c)+this.b,undefined);return this.d};_.b=rB;_.c=null;_.d=null;_.e=null;var Cb,Db;dl(21,1,{});var Jb=0,Kb=0,Lb=0,Mb=-1;dl(23,21,{},_b);_.b=null;_.c=null;var Wb;dl(29,1,{});dl(30,29,{},nc);_.b=rB;dl(43,1,{39:1,42:1,44:1});_.eQ=function Kc(a){return this===a};_.hC=function Lc(){return Sb(this)};_.tS=function Mc(){return this.c};_.c=null;dl(42,43,XA);var Nc,Oc,Pc,Qc,Rc;dl(44,42,XA,Vc);dl(45,42,XA,Xc);dl(46,42,XA,Zc);dl(47,42,XA,_c);var ad,bd=false,cd,dd,ed;dl(49,1,{},kd);_.x=function ld(){(fd(),bd)&&gd()};dl(50,1,{},td);_.b=null;var nd;dl(56,1,{});_.tS=function Ad(){return 'An event type'};_.j=null;dl(55,56,{});_.i=false;dl(54,55,{});_.z=function Gd(){return this.A()};_.b=null;_.c=null;var Cd=null;dl(53,54,{});dl(52,53,{});dl(51,52,{},Jd);_.y=function Kd(a){Au(Ag(Ag(a,5),38).b.b)};_.A=function Ld(){return Hd};var Hd;dl(59,1,{});_.hC=function Qd(){return this.d};_.tS=function Rd(){return 'Event type'};_.d=0;var Pd=0;dl(58,59,{},Sd);dl(57,58,{6:1},Td);_.b=null;_.c=null;dl(61,54,{});dl(60,61,{});dl(62,60,{},Zd);_.y=function $d(a){Ag(a,7).B(this)};_.A=function _d(){return Xd};var Xd;dl(63,1,{},de);_.b=null;dl(65,55,{},ge);_.y=function he(a){Ag(a,8).C(this)};_.z=function je(){return fe};var fe=null;dl(66,55,{});_.y=function me(a){Hg(a);null.yb()};_.z=function ne(){return le};var le=null;dl(67,1,YA,re);_.b=null;_.c=null;dl(70,1,{});dl(69,70,{});_.b=null;_.c=0;_.d=false;dl(68,69,{},Fe);dl(71,1,{},He);_.b=null;dl(73,12,ZA,Ke);_.b=null;dl(72,73,ZA,Ne);dl(74,1,$A,Pe);_.B=function Qe(a){};dl(76,1,{});_.E=function Te(){return null};_.F=function Ue(){return null};_.G=function Ve(){return null};_.H=function We(){return null};dl(75,76,{12:1},$e,_e);_.eQ=function af(a){if(!Cg(a,12)){return false}return this.b==Ag(a,12).b};_.D=function bf(){return ff};_.hC=function cf(){return Sb(this.b)};_.E=function df(){return this};_.tS=function ef(){return Ze(this)};_.b=null;dl(77,76,{},lf);_.D=function mf(){return pf};_.F=function nf(){return this};_.tS=function of(){return hv(),rB+this.b};_.b=false;var hf,jf;dl(78,12,WA,rf,sf);dl(79,76,{},wf);_.D=function xf(){return zf};_.tS=function yf(){return sB};var uf;dl(80,76,{13:1},Bf);_.eQ=function Cf(a){if(!Cg(a,13)){return false}return this.b==Ag(a,13).b};_.D=function Df(){return Gf};_.hC=function Ef(){return Gg((new Bv(this.b)).b)};_.tS=function Ff(){return this.b+rB};_.b=0;dl(81,76,{14:1},Nf,Of);_.eQ=function Pf(a){if(!Cg(a,14)){return false}return this.b==Ag(a,14).b};_.D=function Qf(){return Uf};_.hC=function Rf(){return Sb(this.b)};_.G=function Sf(){return this};_.tS=function Tf(){var a,b,c,d,e,f;f=new Aw;f.b.b+=DB;a=true;e=If(this,qg(uk,VA,1,0,0));for(c=0,d=e.length;c<d;++c){b=e[c];a?(a=false):(f.b.b+=EB,f);zw(f,Hb(b));f.b.b+=FB;yw(f,Jf(this,b))}f.b.b+=GB;return f.b.b};_.b=null;var Vf;dl(83,76,{15:1},fg);_.eQ=function gg(a){if(!Cg(a,15)){return false}return kw(this.b,Ag(a,15).b)};_.D=function hg(){return lg};_.hC=function ig(){return vw(this.b)};_.H=function jg(){return this};_.tS=function kg(){return Hb(this.b)};_.b=null;dl(84,1,{},mg);_.qI=0;var tg,ug;var xk=null;var Kk=null;var Wk,Xk,Yk,Zk;dl(93,1,{16:1},al);dl(98,1,{},il);_.b=0;_.c=0;_.d=0;_.e=null;dl(99,1,_A,kl);_.I=function ll(){return this.b};_.eQ=function ml(a){if(!Cg(a,17)){return false}return kw(this.b,Ag(a,17).I())};_.hC=function nl(){return vw(this.b)};_.b=null;dl(100,1,{},ql);dl(101,1,_A,sl);_.I=function tl(){return this.b};_.eQ=function ul(a){if(!Cg(a,17)){return false}return kw(this.b,Ag(a,17).I())};_.hC=function vl(){return vw(this.b)};_.b=null;var wl,xl,yl,zl,Al;dl(103,1,{18:1,19:1},El);_.eQ=function Fl(a){if(!Cg(a,18)){return false}return kw(this.b,Ag(Ag(a,18),19).b)};_.hC=function Gl(){return vw(this.b)};_.b=null;dl(105,1,{},Ml);_.b=null;var Jl=null,Kl=null;dl(106,1,{},Pl);dl(108,1,{});dl(109,1,{},Vl);var Ul=null;dl(110,108,{},Yl);var Xl=null;dl(111,1,{},_l);_.b=null;_.c=null;var am=null;dl(113,1,{},fm);_.b=null;_.c=null;_.d=null;dl(117,1,{23:1,28:1});_.J=function nm(){throw new Jw};_.tS=function qm(){if(!this.v){return '(null handle)'}return this.v.outerHTML};_.v=null;dl(116,117,aB);_.K=function zm(){};_.L=function Am(){};_.M=function Bm(){return this.r};_.N=function Cm(){um(this)};_.O=function Dm(a){vm(this,a)};_.P=function Em(){if(!this.M()){throw new Jv("Should only call onDetach when the widget is attached to the browser's document")}try{this.R()}finally{try{this.L()}finally{this.v.__listener=null;this.r=false}}};_.Q=function Fm(){};_.R=function Gm(){};_.S=function Hm(a){xm(this,a)};_.r=false;_.s=0;_.t=null;_.u=null;dl(115,116,bB);_.M=function Km(){return Jm(this)};_.N=function Lm(){if(this.s!=-1){ym(this.q,this.s);this.s=-1}this.q.N();this.v.__listener=this};_.O=function Mm(a){vm(this,a);this.q.O(a)};_.P=function Nm(){try{this.R()}finally{this.q.P()}};_.J=function Om(){km(this,this.q.J());return this.v};_.q=null;dl(114,115,cB);_.T=function dn(){return Bo(this.o)};_.O=function en(a){var b,c,d,e;!Hn&&(Hn=new On);if(this.k){return}b=a.target;if(!Ac(b)){return}d=b;if(!Dc(this.v,b)){return}vm(this,a);this.q.O(a);c=a.type;if(kw(VB,c)){this.j=true;Wn(this)}else if(kw(WB,c)){this.j=false;e=Tn(this);!!e&&xc(e,ZB)}else kw(XB,c)?(this.j=true):kw(YB,c)&&(!Hn&&(Hn=new On),In(Hn,d))&&(this.j=true);Vn(this,a)};_.R=function fn(){this.j=false};_.U=function jn(a,b){Ho(this.o,a,b)};_.V=function kn(a,b){Io(this.o,a,b)};_.j=false;_.k=false;_.n=null;_.o=null;_.p=0;var Pm=null;dl(118,116,aB,mn);_.b=null;dl(119,1,dB,pn);_.W=function qn(a){var b,c,d,e,f,g,h;d=a.g;b=a.g.type;if(kw(XB,b)&&!a.e){switch(d.keyCode||0){case 40:on(this,yo(this.b.o)+1);a.d=true;a.g.preventDefault();return;case 38:on(this,yo(this.b.o)-1);a.d=true;a.g.preventDefault();return;case 34:g=this.b.o.d;(bp(),$o)==g?on(this,Bo(this.b.o).b):ap==g&&on(this,yo(this.b.o)+30);a.d=true;a.g.preventDefault();return;case 33:h=this.b.o.d;(bp(),$o)==h?on(this,-Bo(this.b.o).b):ap==h&&on(this,yo(this.b.o)-30);a.d=true;a.g.preventDefault();return;case 36:on(this,-Bo(this.b.o).c);a.d=true;a.g.preventDefault();return;case 35:on(this,xo(this.b.o).j-1);a.d=true;a.g.preventDefault();return;case 32:a.d=true;a.g.preventDefault();return;}}else if(kw(yB,b)){e=a.b.b-Bo(this.b.o).c;f=a.g.target;c=(!Hn&&(Hn=new On),In(Hn,f));Xm(this.b,e,!c)}else if(kw(VB,b)){e=a.b.b-Bo(this.b.o).c;if(yo(this.b.o)!=e){Xm(this.b,a.b.b,false);return}}};_.b=null;dl(120,1,{},zn);_.b=null;_.c=false;dl(121,1,{},Cn);_.x=function Dn(){Bn(this)};_.b=null;dl(122,66,{},Fn);dl(123,1,{});_.c=null;var Hn=null;dl(124,123,{},On);_.b=null;var Ln=null;dl(125,114,cB,_n);_.K=function bo(){var a,b;try{this.g.N()}catch(a){a=wk(a);if(Cg(a,52)){b=a;throw new Hq(tz(b))}else throw a}};_.L=function co(){var a,b;try{this.g.P()}catch(a){a=wk(a);if(Cg(a,52)){b=a;throw new Hq(tz(b))}else throw a}};_.b=null;_.c=false;_.d=null;_.i=null;var Rn=null;dl(126,1,{},fo);_.x=function go(){Vm(this.b)};_.b=null;dl(127,1,{},ko);var io=null,jo=null;dl(128,1,{},no);_.b=false;dl(132,1,{11:1,32:1},Lo);_.T=function Mo(){return Bo(this)};_.U=function No(a,b){Ho(this,a,b)};_.V=function Oo(a,b){Io(this,a,b)};_.b=null;_.c=false;_.f=null;_.g=null;_.i=0;_.j=null;_.k=null;dl(133,1,{},Ro);_.x=function So(){this.b.g==this&&Do(this.b,null)};_.b=null;dl(134,1,{},Vo);_.e=0;_.f=null;_.g=0;_.i=0;_.j=0;_.k=false;_.p=null;_.q=false;dl(135,134,{},Xo);_.b=false;_.c=false;dl(136,43,{20:1,39:1,42:1,44:1},cp);_.b=false;var Zo,$o,_o,ap;dl(137,43,{21:1,39:1,42:1,44:1},kp);var fp,gp,hp,ip;dl(138,55,{},pp);_.y=function qp(a){Hg(a);null.yb()};_.z=function rp(){return np};var np;dl(139,1,{},tp);var up,vp,wp;var yp=null,zp=null;var Fp;dl(145,1,eB,Ip);_.C=function Jp(a){while((Gp(),Fp).c>0){Hg(Uy(Fp,0)).yb()}};var Kp=false,Lp=null;dl(147,55,{},Tp);_.y=function Up(a){Hg(a);null.yb()};_.z=function Vp(){return Rp};var Rp;dl(148,67,YA,Xp);var Yp=false;var bq=null,cq=null,dq=null,eq=null,fq=null,gq=null;dl(155,116,fB);_.K=function rq(){Iq(this,(Gq(),Eq))};_.L=function sq(){Iq(this,(Gq(),Fq))};dl(154,155,fB);_.Y=function yq(){return new Bs(this.c)};_.X=function zq(a){return wq(this,a)};dl(153,154,fB);_.X=function Cq(a){var b;b=wq(this,a);b&&Bq(a.v);return b};dl(156,72,ZA,Hq);var Eq,Fq;dl(157,1,{},Kq);_.Z=function Lq(a){a.N()};dl(158,1,{},Nq);_.Z=function Oq(a){a.P()};dl(161,116,aB);_.N=function Sq(){var a;um(this);a=this.v.tabIndex;-1==a&&(this.v.tabIndex=0,undefined)};dl(160,161,aB);dl(159,160,aB,Vq);dl(162,154,fB,$q);_.X=function _q(a){var b,c;b=Cc(a.v);c=wq(this,a);if(c){a.v.style[uC]=rB;a.v.style[wC]=rB;pm(a.v,true);sc(this.v,b);this.b==a&&(this.b=null)}return c};_.b=null;var Xq=null;dl(163,3,{},dr);_.b=null;_.c=null;_.d=false;_.e=null;dl(164,154,fB,hr);dl(166,153,gB);var qr,rr,sr;dl(167,1,{},Ar);_.Z=function Br(a){a.M()&&a.P()};dl(168,1,eB,Dr);_.C=function Er(a){wr()};dl(169,166,gB,Gr);dl(170,155,fB,Jr);_.Y=function Lr(){return new Pr};_.X=function Mr(a){return Ir(this,a)};_.b=null;dl(171,1,{},Pr);_.$=function Qr(){return false};_._=function Rr(){return Or()};_.ab=function Sr(){};dl(174,161,aB);_.O=function Xr(a){var b;b=Zp(a.type);(b&896)!=0?vm(this,a):vm(this,a)};_.Q=function Yr(){};dl(173,174,aB);dl(172,173,aB);dl(175,43,hB);var as,bs,cs,ds,es;dl(176,175,hB,is);dl(177,175,hB,ks);dl(178,175,hB,ms);dl(179,175,hB,os);dl(180,1,{},ws);_.Y=function xs(){return new Bs(this)};_.b=null;_.c=null;_.d=0;dl(181,1,{},Bs);_.$=function Cs(){return this.b<this.c.d-1};_._=function Ds(){return zs(this)};_.ab=function Es(){As(this)};_.b=-1;_.c=null;dl(184,1,{});_.d=-1;_.e=false;dl(185,1,{10:1,34:1},Ms);_.b=null;_.c=null;dl(186,55,{},Ps);_.y=function Qs(a){Ag(a,31).W(this)};_.z=function Ss(){return Os};_.b=null;_.c=null;_.d=false;_.e=false;_.f=false;_.g=null;var Os=null;dl(187,1,dB,Us);_.W=function Vs(a){var b;if(a.e||a.f){return}b=a.c;b.o;return};dl(188,184,{},Ys);_.b=null;dl(189,1,iB,ht,it);_.bb=function jt(a){return _s(this,a)};_.cb=function kt(a){return at(this,a)};_.db=function lt(){bt(this)};_.eb=function mt(a){return this.g.eb(a)};_.eQ=function nt(a){return this.g.eQ(a)};_.fb=function ot(a){return this.g.fb(a)};_.hC=function pt(){return this.g.hC()};_.gb=function qt(a){return this.g.gb(a)};_.hb=function rt(){return this.g.hb()};_.Y=function st(){return new Gt(this)};_.ib=function tt(){return new Gt(this)};_.jb=function ut(a){return new Ht(this,a)};_.kb=function vt(a){return ft(this,a)};_.lb=function wt(a){return gt(this,a)};_.mb=function xt(){return this.g.mb()};_.nb=function yt(a,b){return new it(this.o,this.g.nb(a,b),this,a)};_.ob=function zt(){return this.g.ob()};_.b=0;_.c=null;_.d=false;_.f=false;_.g=null;_.i=-2147483648;_.j=2147483647;_.k=false;_.n=0;_.o=null;dl(190,1,{},Bt);_.x=function Ct(){this.b.f=false;if(this.b.d){this.b.d=false;return}dt(this.b)};_.b=null;dl(191,1,{},Gt,Ht);_.$=function It(){return this.b<this.d.g.mb()};_.pb=function Jt(){return this.b>0};_._=function Kt(){return Et(this)};_.qb=function Lt(){if(this.b<=0){throw new PA}return et(this.d,this.c=--this.b)};_.ab=function Mt(){Ft(this)};_.b=0;_.c=-1;_.d=null;dl(192,1,{33:1,39:1},Ot);_.eQ=function Pt(a){var b;if(!Cg(a,33)){return false}b=Ag(a,33);return this.c==b.c&&this.b==b.b};_.hC=function Qt(){return this.b*31^this.c};_.tS=function Rt(){return 'Range('+this.c+BB+this.b+IB};_.b=0;_.c=0;dl(193,55,{},Vt);_.y=function Wt(a){Ut(Ag(a,34))};_.z=function Yt(){return Tt};var Tt=null;dl(194,1,{},_t);_.b=null;_.c=null;_.d=null;dl(195,1,jB,bu);_.x=function cu(){xe(this.b,this.d,this.c)};_.b=null;_.c=null;_.d=null;dl(196,1,jB,eu);_.x=function fu(){ze(this.b,this.d,this.c)};_.b=null;_.c=null;_.d=null;dl(198,172,aB,hu);dl(199,7,{},qu);_.b=false;_.c=null;dl(201,1,{37:1},wu,xu);_.b=false;_.c=null;_.d=null;dl(202,1,{},Hu);_.b=false;_.d=null;dl(203,1,{},Ku);_.b=null;dl(204,115,bB,Qu);_.b=null;_.c=null;_.d=null;_.e=null;_.f=null;_.g=null;_.i=null;_.k=null;dl(205,1,{22:1},Su);_.O=function Tu(a){Ju(this.c,!!this.b.k.checked)};_.b=null;_.c=null;dl(206,1,$A,Vu);_.B=function Wu(a){(a.b.keyCode||0)==13&&zu(this.b.b)};_.b=null;dl(207,1,{5:1,10:1,38:1},Yu);_.b=null;dl(208,1,{},_u);_.b=null;_.c=null;_.d=null;_.e=null;_.f=null;_.g=null;_.i=null;_.j=null;_.k=null;_.n=null;_.o=null;_.p=null;_.q=null;dl(210,12,WA,dv);dl(211,12,WA,fv);dl(212,1,{39:1,40:1,42:1},iv);_.eQ=function jv(a){return Cg(a,40)&&Ag(a,40).b==this.b};_.hC=function kv(){return this.b?1231:1237};_.tS=function lv(){return this.b?$B:'false'};_.b=false;dl(214,1,{},ov);_.tS=function vv(){return ((this.b&2)!=0?'interface ':(this.b&1)!=0?rB:'class ')+this.d};_.b=0;_.c=0;_.d=null;dl(215,12,WA,xv);dl(217,1,{39:1,49:1});dl(216,217,{39:1,42:1,43:1,49:1},Bv);_.eQ=function Cv(a){return Cg(a,43)&&Ag(a,43).b==this.b};_.hC=function Dv(){return Gg(this.b)};_.tS=function Ev(){return rB+this.b};_.b=0;dl(218,12,WA,Gv);dl(219,12,WA,Iv,Jv);dl(220,12,{39:1,46:1,47:1,50:1,52:1},Lv,Mv);dl(221,217,{39:1,42:1,48:1,49:1},Ov);_.eQ=function Pv(a){return Cg(a,48)&&Ag(a,48).b==this.b};_.hC=function Qv(){return this.b};_.tS=function Uv(){return rB+this.b};_.b=0;var Wv;dl(224,12,WA,_v,aw);var bw;dl(226,218,WA,ew);dl(227,1,{39:1,51:1},gw);_.tS=function hw(){return this.b+'.'+this.d+'(Unknown Source'+(this.c>=0?FB+this.c:rB)+IB};_.b=null;_.c=0;_.d=null;_=String.prototype;_.cM={1:1,39:1,41:1,42:1};_.eQ=function ow(a){return kw(this,a)};_.hC=function pw(){return vw(this)};_.tS=_.toString;var qw,rw=0,sw;dl(229,1,kB,Aw);_.tS=function Bw(){return this.b.b};dl(230,1,kB,Fw,Gw);_.tS=function Hw(){return this.b.b};dl(231,12,{39:1,46:1,50:1,52:1,53:1},Jw,Kw);dl(232,1,{});_.bb=function Ow(a){throw new Kw('Add not supported on this collection')};_.cb=function Pw(a){var b,c;c=a.Y();b=false;while(c.$()){this.bb(c._())&&(b=true)}return b};_.eb=function Qw(a){var b;b=Mw(this.Y(),a);return !!b};_.hb=function Rw(){return this.mb()==0};_.lb=function Sw(a){var b;b=Mw(this.Y(),a);if(b){b.ab();return true}else{return false}};_.ob=function Tw(){return this.rb(qg(sk,VA,0,this.mb(),0))};_.rb=function Uw(a){var b,c,d;d=this.mb();a.length<d&&(a=og(a,d));c=this.Y();for(b=0;b<d;++b){sg(a,b,c._())}a.length>d&&sg(a,d,null);return a};_.tS=function Vw(){return Nw(this)};dl(234,1,lB);_.eQ=function Zw(a){var b,c,d,e,f;if(a===this){return true}if(!Cg(a,56)){return false}e=Ag(a,56);if(this.e!=e.e){return false}for(c=new Fx((new xx(e)).b);ly(c.b);){b=c.c=Ag(my(c.b),57);d=b.tb();f=b.ub();if(!(d==null?this.d:Cg(d,1)?FB+Ag(d,1) in this.f:hx(this,d,~~zb(d)))){return false}if(!QA(f,d==null?this.c:Cg(d,1)?gx(this,Ag(d,1)):fx(this,d,~~zb(d)))){return false}}return true};_.hC=function $w(){var a,b,c;c=0;for(b=new Fx((new xx(this)).b);ly(b.b);){a=b.c=Ag(my(b.b),57);c+=a.hC();c=~~c}return c};_.tS=function _w(){var a,b,c,d;d=DB;a=false;for(c=new Fx((new xx(this)).b);ly(c.b);){b=c.c=Ag(my(c.b),57);a?(d+=EB):(a=true);d+=rB+b.tb();d+=JC;d+=rB+b.ub()}return d+GB};dl(233,234,lB);_.sb=function rx(a,b){return Fg(a)===Fg(b)||a!=null&&yb(a,b)};_.b=null;_.c=null;_.d=false;_.e=0;_.f=null;dl(236,232,mB);_.eQ=function ux(a){var b,c,d;if(a===this){return true}if(!Cg(a,58)){return false}c=Ag(a,58);if(c.mb()!=this.mb()){return false}for(b=c.Y();b.$();){d=b._();if(!this.eb(d)){return false}}return true};_.hC=function vx(){var a,b,c;a=0;for(b=this.Y();b.$();){c=b._();if(c!=null){a+=zb(c);a=~~a}}return a};dl(235,236,mB,xx);_.eb=function yx(a){return wx(this,a)};_.Y=function zx(){return new Fx(this.b)};_.lb=function Ax(a){var b;if(wx(this,a)){b=Ag(a,57).tb();nx(this.b,b);return true}return false};_.mb=function Bx(){return this.b.e};_.b=null;dl(237,1,{},Fx);_.$=function Gx(){return ly(this.b)};_._=function Hx(){return Dx(this)};_.ab=function Ix(){Ex(this)};_.b=null;_.c=null;_.d=null;dl(239,1,nB);_.eQ=function Lx(a){var b;if(Cg(a,57)){b=Ag(a,57);if(QA(this.tb(),b.tb())&&QA(this.ub(),b.ub())){return true}}return false};_.hC=function Mx(){var a,b;a=0;b=0;this.tb()!=null&&(a=zb(this.tb()));this.ub()!=null&&(b=zb(this.ub()));return a^b};_.tS=function Nx(){return this.tb()+JC+this.ub()};dl(238,239,nB,Ox);_.tb=function Px(){return null};_.ub=function Qx(){return this.b.c};_.vb=function Rx(a){return lx(this.b,a)};_.b=null;dl(240,239,nB,Tx);_.tb=function Ux(){return this.b};_.ub=function Vx(){return gx(this.c,this.b)};_.vb=function Wx(a){return mx(this.c,this.b,a)};_.b=null;_.c=null;dl(241,232,iB);_.wb=function Yx(a,b){throw new Kw('Add not supported on this list')};_.bb=function Zx(a){this.wb(this.mb(),a);return true};_.db=function _x(){this.xb(0,this.mb())};_.eQ=function ay(a){var b,c,d,e,f;if(a===this){return true}if(!Cg(a,55)){return false}f=Ag(a,55);if(this.mb()!=f.mb()){return false}d=new oy(this);e=f.Y();while(d.c<d.e.mb()){b=my(d);c=e._();if(!(b==null?c==null:yb(b,c))){return false}}return true};_.hC=function by(){var a,b,c;b=1;a=new oy(this);while(a.c<a.e.mb()){c=my(a);b=31*b+(c==null?0:zb(c));b=~~b}return b};_.gb=function cy(a){var b,c;for(b=0,c=this.mb();b<c;++b){if(a==null?this.fb(b)==null:yb(a,this.fb(b))){return b}}return -1};_.Y=function ey(){return new oy(this)};_.ib=function fy(){return new ty(this,0)};_.jb=function gy(a){return new ty(this,a)};_.kb=function hy(a){throw new Kw('Remove not supported on this list')};_.xb=function iy(a,b){var c,d;d=new ty(this,a);for(c=a;c<b;++c){my(d);ny(d)}};_.nb=function jy(a,b){return new xy(this,a,b)};dl(242,1,{},oy);_.$=function py(){return ly(this)};_._=function qy(){return my(this)};_.ab=function ry(){ny(this)};_.c=0;_.d=-1;_.e=null;dl(243,242,{},ty);_.pb=function uy(){return this.c>0};_.qb=function vy(){if(this.c<=0){throw new PA}return this.b.fb(this.d=--this.c)};_.b=null;dl(244,241,iB,xy);_.wb=function yy(a,b){$x(a,this.c+1);++this.c;this.d.wb(this.b+a,b)};_.fb=function zy(a){$x(a,this.c);return this.d.fb(this.b+a)};_.kb=function Ay(a){var b;$x(a,this.c);b=this.d.kb(this.b+a);--this.c;return b};_.mb=function By(){return this.c};_.b=0;_.c=0;_.d=null;dl(245,236,mB,Ey);_.eb=function Fy(a){return dx(this.b,a)};_.Y=function Gy(){return Dy(this)};_.mb=function Hy(){return this.c.b.e};_.b=null;_.c=null;dl(246,1,{},Ky);_.$=function Ly(){return ly(this.b.b)};_._=function My(){return Jy(this)};_.ab=function Ny(){Ex(this.b)};_.b=null;dl(247,241,oB,$y,_y);_.wb=function az(a,b){Qy(this,a,b)};_.bb=function bz(a){return Ry(this,a)};_.cb=function cz(a){return Sy(this,a)};_.db=function dz(){Ty(this)};_.eb=function ez(a){return Vy(this,a,0)!=-1};_.fb=function fz(a){return Uy(this,a)};_.gb=function gz(a){return Vy(this,a,0)};_.hb=function hz(){return this.c==0};_.kb=function iz(a){return Wy(this,a)};_.lb=function jz(a){return Xy(this,a)};_.xb=function kz(a,b){var c;$x(a,this.c);(b<a||b>this.c)&&dy(b,this.c);c=b-a;mz(this.b,a,c);this.c-=c};_.mb=function lz(){return this.c};_.ob=function pz(){return ng(this.b,this.c)};_.rb=function qz(a){return Zy(this,a)};_.c=0;var rz;dl(249,241,oB,wz);_.eb=function xz(a){return false};_.fb=function yz(a){throw new Lv};_.mb=function zz(){return 0};dl(250,1,{});_.bb=function Cz(a){throw new Jw};_.cb=function Dz(a){throw new Jw};_.db=function Ez(){throw new Jw};_.eb=function Fz(a){return this.c.eb(a)};_.Y=function Gz(){return new Mz(this.c.Y())};_.lb=function Hz(a){throw new Jw};_.mb=function Iz(){return this.c.mb()};_.ob=function Jz(){return this.c.ob()};_.tS=function Kz(){return this.c.tS()};_.c=null;dl(251,1,{},Mz);_.$=function Nz(){return this.c.$()};_._=function Oz(){return this.c._()};_.ab=function Pz(){throw new Jw};_.c=null;dl(252,250,iB,Rz);_.eQ=function Sz(a){return this.b.eQ(a)};_.fb=function Tz(a){return this.b.fb(a)};_.hC=function Uz(){return this.b.hC()};_.gb=function Vz(a){return this.b.gb(a)};_.hb=function Wz(){return this.b.hb()};_.ib=function Xz(){return new aA(this.b.jb(0))};_.jb=function Yz(a){return new aA(this.b.jb(a))};_.kb=function Zz(a){throw new Jw};_.nb=function $z(a,b){return new Rz(this.b.nb(a,b))};_.b=null;dl(253,251,{},aA);_.pb=function bA(){return this.b.pb()};_.qb=function cA(){return this.b.qb()};_.b=null;dl(254,252,iB,eA);dl(255,250,mB,gA);_.eQ=function hA(a){return this.c.eQ(a)};_.hC=function iA(){return this.c.hC()};dl(256,1,{39:1,42:1,54:1},kA);_.eQ=function lA(a){return Cg(a,54)&&Lk(Mk(this.b.getTime()),Mk(Ag(a,54).b.getTime()))};_.hC=function mA(){var a;a=Mk(this.b.getTime());return Tk(Vk(a,Rk(a,32)))};_.tS=function oA(){var a,b,c;c=-this.b.getTimezoneOffset();a=(c>=0?'+':rB)+~~(c/60);b=(c<0?-c:c)%60<10?KB+(c<0?-c:c)%60:rB+(c<0?-c:c)%60;return (rA(),pA)[this.b.getDay()]+wB+qA[this.b.getMonth()]+wB+nA(this.b.getDate())+wB+nA(this.b.getHours())+FB+nA(this.b.getMinutes())+FB+nA(this.b.getSeconds())+' GMT'+a+b+wB+this.b.getFullYear()};_.b=null;var pA,qA;dl(258,233,{39:1,56:1},uA,vA);dl(259,236,{39:1,58:1},AA,BA);_.bb=function CA(a){return xA(this,a)};_.eb=function DA(a){return dx(this.b,a)};_.hb=function EA(){return this.b.e==0};_.Y=function FA(){return Dy(Yw(this.b))};_.lb=function GA(a){return zA(this,a)};_.mb=function HA(){return this.b.e};_.tS=function IA(){return Nw(Yw(this.b))};_.b=null;dl(260,239,nB,KA);_.tb=function LA(){return this.b};_.ub=function MA(){return this.c};_.vb=function NA(a){var b;b=this.c;this.c=a;return b};_.b=null;_.c=null;dl(261,12,WA,PA);var pB=Pb;
var Cj=qv(LC,'Object',1),Pg=qv(MC,'JavaScriptObject$',15),sk=pv(NC,'Object;',266),Ij=qv(LC,'Throwable',14),uj=qv(LC,'Exception',13),Dj=qv(LC,'RuntimeException',12),Ej=qv(LC,'StackTraceElement',227),tk=pv(NC,'StackTraceElement;',268),zh=qv(OC,'LongLibBase$LongEmul',93),mk=pv('[Lcom.google.gwt.lang.','LongLibBase$LongEmul;',269),Ah=qv(OC,'SeedUtil',94),tj=qv(LC,'Enum',43),pj=qv(LC,'Boolean',212),Bj=qv(LC,'Number',217),kk=pv(rB,'[C',270),rj=qv(LC,'Class',214),sj=qv(LC,'Double',216),yj=qv(LC,'Integer',221),rk=pv(NC,'Integer;',271),Hj=qv(LC,tB,2),uk=pv(NC,'String;',267),qj=qv(LC,'ClassCastException',215),Gj=qv(LC,'StringBuilder',230),oj=qv(LC,'ArrayStoreException',211),Og=qv(MC,'JavaScriptException',11),Di=qv(PC,'UIObject',117),Mi=qv(PC,'Widget',116),pi=qv(PC,'Composite',115),mj=qv(QC,'ToDoView',204),ij=qv(QC,'ToDoView$1',205),jj=qv(QC,'ToDoView$2',206),kj=qv(QC,'ToDoView$3',207),hj=qv(QC,'ToDoPresenter',202),gj=qv(QC,'ToDoPresenter$1',203),ui=qv(PC,'Panel',155),oi=qv(PC,'ComplexPanel',154),ii=qv(PC,'AbsolutePanel',153),cj=qv(RC,SC,73),ph=qv(TC,SC,72),li=qv(PC,'AttachDetachException',156),ji=qv(PC,'AttachDetachException$1',157),ki=qv(PC,'AttachDetachException$2',158),yi=qv(PC,'RootPanel',166),xi=qv(PC,'RootPanel$DefaultRootPanel',169),vi=qv(PC,'RootPanel$1',167),wi=qv(PC,'RootPanel$2',168),nj=qv(LC,'ArithmeticException',210),Tg=qv(UC,'StringBufferImpl',29),Sh=qv(VC,'AbstractHasData',114),Oh=qv(VC,'AbstractHasData$DefaultKeyboardSelectionHandler',119),Rh=qv(VC,'AbstractHasData$View',120),Ph=qv(VC,'AbstractHasData$View$1',121),Zi=qv(RC,'Event',56),lh=qv(TC,'GwtEvent',55),jh=qv(WC,'ValueChangeEvent',66),Qh=qv(VC,'AbstractHasData$View$2',122),Nh=qv(VC,'AbstractHasData$1',118),bi=rv(VC,'HasKeyboardPagingPolicy$KeyboardPagingPolicy',136,dp),nk=pv(XC,'HasKeyboardPagingPolicy$KeyboardPagingPolicy;',272),ci=rv(VC,'HasKeyboardSelectionPolicy$KeyboardSelectionPolicy',137,lp),ok=pv(XC,'HasKeyboardSelectionPolicy$KeyboardSelectionPolicy;',273),Pi=qv(YC,'CellPreviewEvent',186),Xi=qv(RC,'Event$Type',59),kh=qv(TC,'GwtEvent$Type',58),ai=qv(VC,'HasDataPresenter',132),$h=qv(VC,'HasDataPresenter$DefaultState',134),_h=qv(VC,'HasDataPresenter$PendingState',135),Zh=qv(VC,'HasDataPresenter$2',133),Qg=qv(MC,'Scheduler',21),Yh=qv(VC,'CellList',125),Vh=qv(VC,'CellList$1',126),si=qv(PC,'FocusWidget',161),mi=qv(PC,'ButtonBase',160),ni=qv(PC,'Button',159),Ji=qv(PC,'ValueBoxBase',174),Bi=qv(PC,'TextBoxBase',173),Ci=qv(PC,'TextBox',172),dj=qv(QC,'TextBoxWithPlaceholder',198),Ii=rv(PC,'ValueBoxBase$TextAlignment',175,gs),pk=pv(ZC,'ValueBoxBase$TextAlignment;',274),Ei=rv(PC,'ValueBoxBase$TextAlignment$1',176,null),Fi=rv(PC,'ValueBoxBase$TextAlignment$2',177,null),Gi=rv(PC,'ValueBoxBase$TextAlignment$3',178,null),Hi=rv(PC,'ValueBoxBase$TextAlignment$4',179,null),qh=qv('com.google.gwt.i18n.client.','AutoDirectionHandler',74),Oi=qv(YC,'AbstractDataProvider',184),Ui=qv(YC,'ListDataProvider',188),Ti=qv(YC,'ListDataProvider$ListWrapper',189),Si=qv(YC,'ListDataProvider$ListWrapper$WrappedListIterator',191),Ri=qv(YC,'ListDataProvider$ListWrapper$1',190),Ni=qv(YC,'AbstractDataProvider$1',185),Vi=qv(YC,'RangeChangeEvent',193),Xj=qv($C,'AbstractMap',234),Pj=qv($C,'AbstractHashMap',233),gk=qv($C,'HashMap',258),Kj=qv($C,'AbstractCollection',232),Yj=qv($C,'AbstractSet',236),Mj=qv($C,'AbstractHashMap$EntrySet',235),Lj=qv($C,'AbstractHashMap$EntrySetIterator',237),Wj=qv($C,'AbstractMapEntry',239),Nj=qv($C,'AbstractHashMap$MapEntryNull',238),Oj=qv($C,'AbstractHashMap$MapEntryString',240),Vj=qv($C,'AbstractMap$1',245),Uj=qv($C,'AbstractMap$1$1',246),hk=qv($C,'HashSet',259),Sg=qv(UC,'StringBufferImplAppend',30),Rg=qv(UC,'SchedulerImpl',23),Mg=qv(_C,'AbstractCell',7),ej=qv(QC,'ToDoCell',199),Ng=qv(_C,'Cell$Context',8),lj=qv(QC,'ToDoView_ToDoViewUiBinderImpl$Widgets',208),wj=qv(LC,'IllegalStateException',219),Hh=qv(aD,'Storage',105),Gh=qv(aD,'Storage$StorageSupportDetector',106),yh=qv(bD,'JSONValue',76),rh=qv(bD,'JSONArray',75),wh=qv(bD,'JSONObject',81),xh=qv(bD,'JSONString',83),sh=qv(bD,'JSONBoolean',77),fj=qv(QC,'ToDoItem',201),Li=qv(PC,'WidgetCollection',180),qk=pv(ZC,'Widget;',275),Ki=qv(PC,'WidgetCollection$WidgetIterator',181),zj=qv(LC,'NullPointerException',224),vj=qv(LC,'IllegalArgumentException',218),Tj=qv($C,'AbstractList',241),Zj=qv($C,'ArrayList',247),Qj=qv($C,'AbstractList$IteratorImpl',242),Rj=qv($C,'AbstractList$ListIteratorImpl',243),Sj=qv($C,'AbstractList$SubList',244),bh=qv(cD,'DomEvent',54),eh=qv(cD,'KeyEvent',61),dh=qv(cD,'KeyCodeEvent',60),fh=qv(cD,'KeyUpEvent',62),ah=qv(cD,'DomEvent$Type',57),ch=qv(cD,'HumanInputEvent',53),gh=qv(cD,'MouseEvent',52),_g=qv(cD,'ClickEvent',51),Jj=qv(LC,'UnsupportedOperationException',231),Fj=qv(LC,'StringBuffer',229),gi=qv(dD,'Window$ClosingEvent',147),nh=qv(TC,'HandlerManager',67),hi=qv(dD,'Window$WindowHandlers',148),Yi=qv(RC,'EventBus',70),bj=qv(RC,'SimpleEventBus',69),mh=qv(TC,'HandlerManager$Bus',68),$i=qv(RC,'SimpleEventBus$1',194),_i=qv(RC,'SimpleEventBus$2',195),aj=qv(RC,'SimpleEventBus$3',196),Xh=qv(VC,'CellList_Resources_default_InlineClientBundleGenerator',127),Wh=qv(VC,'CellList_Resources_default_InlineClientBundleGenerator$1',128),ri=qv(PC,'DeckPanel',162),Lg=qv(eD,'Animation',3),qi=qv(PC,'DeckPanel$SlideAnimation',163),Kg=qv(eD,'AnimationScheduler',4),Ai=qv(PC,'SimplePanel',170),zi=qv(PC,'SimplePanel$1',171),Uh=qv(VC,'CellBasedWidgetImpl',123),th=qv(bD,'JSONException',78),ih=qv(WC,'CloseEvent',65),ik=qv($C,'MapEntryImpl',260),xj=qv(LC,'IndexOutOfBoundsException',220),$j=qv($C,'Collections$EmptyList',249),ak=qv($C,'Collections$UnmodifiableCollection',250),ck=qv($C,'Collections$UnmodifiableList',252),dk=qv($C,'Collections$UnmodifiableRandomAccessList',254),ek=qv($C,'Collections$UnmodifiableSet',255),_j=qv($C,'Collections$UnmodifiableCollectionIterator',251),bk=qv($C,'Collections$UnmodifiableListIterator',253),Th=qv(VC,'CellBasedWidgetImplStandard',124),ti=qv(PC,'HTMLPanel',164),vh=qv(bD,'JSONNumber',80),uh=qv(bD,'JSONNull',79),hh=qv(cD,'PrivateMap',63),oh=qv(TC,'LegacyHandlerWrapper',71),Wi=qv(YC,'Range',192),jk=qv($C,'NoSuchElementException',261),Qi=qv(YC,'DefaultSelectionEventManager',187),Eh=qv(fD,'SafeHtmlString',101),Lh=qv(gD,'LazyDomElement',111),Yg=rv(hD,'Style$Display',42,Tc),lk=pv('[Lcom.google.gwt.dom.client.','Style$Display;',276),Ug=rv(hD,'Style$Display$1',44,null),Vg=rv(hD,'Style$Display$2',45,null),Wg=rv(hD,'Style$Display$3',46,null),Xg=rv(hD,'Style$Display$4',47,null),Mh=qv(gD,'UiBinderUtil$TempAttachment',113),Ch=qv(fD,'OnlyToBeUsedInGeneratedCodeStringBlessedAsSafeHtml',99),Dh=qv(fD,'SafeHtmlBuilder',100),$g=qv(hD,'StyleInjector$StyleInjectorImpl',50),Zg=qv(hD,'StyleInjector$1',49),ei=qv(VC,'LoadingStateChangeEvent',138),di=qv(VC,'LoadingStateChangeEvent$DefaultLoadingState',139),Aj=qv(LC,'NumberFormatException',226),Bh=qv('com.google.gwt.resources.client.impl.','ImageResourcePrototype',98),Ih=qv('com.google.gwt.text.shared.','AbstractRenderer',108),Kh=qv(iD,'PassthroughRenderer',110),Jh=qv(iD,'PassthroughParser',109),Fh=qv(fD,'SafeUriString',103),fk=qv($C,'Date',256),Jg=qv(eD,'AnimationSchedulerImpl',5),Ig=qv(eD,'AnimationSchedulerImplTimer',6),fi=qv(dD,'Timer$1',145);$stats && $stats({moduleName:'gwttodo',sessionId:$sessionId,subSystem:'startup',evtGroup:'moduleStartup',millis:(new Date()).getTime(),type:'moduleEvalEnd'});if (gwttodo && gwttodo.onScriptLoad)gwttodo.onScriptLoad(gwtOnLoad);})();