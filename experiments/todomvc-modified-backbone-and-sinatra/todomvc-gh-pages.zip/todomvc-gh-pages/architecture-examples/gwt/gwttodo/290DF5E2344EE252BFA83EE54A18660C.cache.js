(function(){var $gwt_version = "2.5.0";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $strongName = '290DF5E2344EE252BFA83EE54A18660C';var $stats = $wnd.__gwtStatsEvent ? function(a) {return $wnd.__gwtStatsEvent(a);} : null;var $sessionId = $wnd.__gwtStatsSessionId ? $wnd.__gwtStatsSessionId : null;$stats && $stats({moduleName:'gwttodo',sessionId:$sessionId,subSystem:'startup',evtGroup:'moduleStartup',millis:(new Date()).getTime(),type:'moduleEvalStart'});function W(){}
function TB(){}
function cb(){}
function hc(){}
function Ac(){}
function $c(){}
function Zd(){}
function ge(){}
function we(){}
function Me(){}
function Ve(){}
function Df(){}
function jg(){}
function _g(){}
function Xl(){}
function Qm(){}
function Tm(){}
function Ao(){}
function gp(){}
function jp(){}
function pq(){}
function Eq(){}
function Gr(){}
function Jr(){}
function ws(){}
function zs(){}
function Ls(){}
function Qt(){}
function Ru(){}
function kw(){}
function yA(){}
function Vc(){Kc()}
function lq(){kq()}
function Pq(){Oq()}
function qb(){Nc(Kc())}
function Hx(){Fx(this)}
function aA(){Rz(this)}
function wB(){ey(this)}
function xB(){ey(this)}
function gb(a){this.b=a}
function oc(a){this.b=a}
function rc(a){this.b=a}
function vf(a){this.b=a}
function Pf(a){this.b=a}
function $f(a){this.b=a}
function og(a){this.b=a}
function Bg(a){this.b=a}
function Wm(a){this.b=a}
function lo(a){this.b=a}
function vo(a){this.b=a}
function xo(a){this.b=a}
function bp(a){this.b=a}
function Np(a){this.b=a}
function gq(a){this.c=a}
function Qr(a){this.v=a}
function Gs(a){this.v=a}
function xt(a){this.c=a}
function xu(a){this.b=a}
function Cu(a){this.d=a}
function Gv(a){this.b=a}
function Rv(a){this.b=a}
function Uv(a){this.b=a}
function ew(a){this.b=a}
function xw(a){this.b=a}
function Kw(a){this.b=a}
function zy(a){this.b=a}
function Qy(a){this.b=a}
function Mz(a){this.b=a}
function qz(a){this.e=a}
function OA(a){this.c=a}
function iB(a){this.c=a}
function Se(){this.b={}}
function Of(){this.b=[]}
function Fe(){this.d=++Ce}
function oe(a,b){a.j=b}
function qe(a,b){a.b=b}
function re(a,b){a.c=b}
function fn(a,b){a.v=b}
function Yc(a,b){a.b+=b}
function Zc(a,b){a.b+=b}
function Vs(){Vs=TB;bt()}
function es(){es=TB;js()}
function ab(){new aA;Cq()}
function mg(){return null}
function Og(){return null}
function cg(a){return a.b}
function tg(a){return a.b}
function Hg(a){return a.b}
function $g(a){return a.b}
function Vf(a){return a.b}
function Qu(a){Tt(a.b,a.c)}
function Kv(a,b){Dt(b,a.j)}
function Fv(a,b){Av(a.b,b)}
function Gm(a,b){Mm(a.b,b)}
function gn(a,b){ln(a.v,b)}
function hn(a,b){fr(a.v,b)}
function Vn(a,b){Cp(a.o,b)}
function Pr(a,b){jd(a.v,b)}
function Re(a,b,c){a.b[b]=c}
function Fx(a){a.b=new $c}
function lm(){this.b=new Hx}
function Cx(){this.b=new $c}
function Ks(){throw new RB}
function CB(){this.b=new wB}
function DB(){this.b=new xB}
function Id(){this.c='NONE'}
function it(){this.c='LEFT'}
function ic(a){return a.x()}
function Gd(){Fd();return Ad}
function Kd(){this.c='BLOCK'}
function bw(){qb.call(this)}
function tw(){qb.call(this)}
function Ew(){qb.call(this)}
function Hw(){qb.call(this)}
function Xw(){qb.call(this)}
function Lx(){qb.call(this)}
function RB(){qb.call(this)}
function ud(b,a){b.checked=a}
function kd(b,a){b.tabIndex=a}
function Pn(a,b){co(a,a.d,b)}
function mt(a,b){pt(a,b,a.d)}
function wr(a,b){pr(a,b,a.v)}
function ct(){bt();return Ys}
function _p(){Zp();return Vp}
function hq(){fq();return bq}
function kq(){kq=TB;jq=new Fe}
function Oq(){Oq=TB;Nq=new Fe}
function be(){be=TB;ae=new ge}
function _b(){_b=TB;$b=new hc}
function ig(){ig=TB;hg=new jg}
function lp(){lp=TB;fp=new jp}
function uA(){uA=TB;tA=new yA}
function mB(){this.b=new Date}
function kt(){this.c='RIGHT'}
function et(){this.c='CENTER'}
function Md(){this.c='INLINE'}
function fg(a){tb.call(this,a)}
function eg(a){rb.call(this,a)}
function Bf(a){yf.call(this,a)}
function Ag(){Bg.call(this,{})}
function Rg(a){throw new eg(a)}
function Lo(a){fc((_b(),$b),a)}
function Ap(a){gc((_b(),$b),a)}
function yq(a,b){Wq();gr(a,b)}
function zq(a,b){Wq();ir(a,b)}
function hr(a,b){Wq();ir(a,b)}
function fr(a,b){Wq();gr(a,b)}
function Wn(a,b,c){Dp(a.o,b,c)}
function Wu(a){sf(a.b,a.d,a.c)}
function Ss(a){this.v=a;new Df}
function gt(){this.c='JUSTIFY'}
function _r(){W.call(this,Z())}
function Cw(a){rb.call(this,a)}
function Fw(a){rb.call(this,a)}
function Iw(a){rb.call(this,a)}
function Yw(a){rb.call(this,a)}
function Mx(a){rb.call(this,a)}
function ax(a){Cw.call(this,a)}
function gB(a){TA.call(this,a)}
function Eb(b,a){b[b.length]=a}
function Fb(b,a){b[b.length]=a}
function gv(a,b){return a.c==b}
function Qe(a,b){return a.b[b]}
function Uw(a,b){return a>b?a:b}
function Vw(a,b){return a<b?a:b}
function _l(a){return new Zl[a]}
function Lg(a){return new og(a)}
function Ng(a){return new Ug(a)}
function qv(a,b){a.b=b;yv(a.c,a)}
function rv(a,b){a.d=b;yv(a.c,a)}
function oA(a,b,c){a.splice(b,c)}
function Xq(a,b){a.__listener=b}
function ko(a,b){Tn(a.b,b,true)}
function $m(a){dd(a.parentNode,a)}
function Wd(a){Ud();Fb(Rd,a);Xd()}
function rb(a){Nc(Kc());this.f=a}
function sb(a){Nc(Kc());this.f=a}
function TA(a){this.c=a;this.b=a}
function cB(a){this.c=a;this.b=a}
function tr(){this.c=new st(this)}
function Cs(){qs.call(this,us())}
function Tq(){ef.call(this,null)}
function vx(){vx=TB;sx={};ux={}}
function Ol(a){return a.l|a.m<<22}
function au(a,b){return a.g.kb(b)}
function DA(a,b){return a.c.jb(b)}
function AB(a,b){return fy(a.b,b)}
function Mn(a,b){return op(a.o,b)}
function Nn(a,b){return pp(a.o,b)}
function Qp(a,b){return Wz(a.n,b)}
function rr(a,b){return ot(a.c,b)}
function pn(a,b){!!a.t&&df(a.t,b)}
function $p(a,b){this.c=a;this.b=b}
function Ku(a,b){this.c=a;this.b=b}
function It(a,b){this.b=a;this.c=b}
function Ov(a,b){this.b=a;this.c=b}
function Vy(a,b){this.c=a;this.b=b}
function Gz(a,b){this.b=a;this.c=b}
function jd(b,a){b.innerHTML=a||uC}
function iy(b,a){return b.f[BC+a]}
function bd(a){return a.firstChild}
function tp(a){return !a.f?a.j:a.f}
function dc(a){return !!a.b||!!a.g}
function uc(a){return yc((Kc(),a))}
function Kg(a){return Zf(),a?Yf:Xf}
function nz(a){return a.c<a.e.rb()}
function Rz(a){a.b=dh(nl,XB,0,0,0)}
function Ut(){Vt.call(this,new aA)}
function Dr(a){Cr();Bf.call(this,a)}
function MB(a,b){this.b=a;this.c=b}
function Ax(a,b){Yc(a.b,b);return a}
function Bx(a,b){Zc(a.b,b);return a}
function Gx(a,b){Zc(a.b,b);return a}
function Tn(a,b,c){Bp(a.o,b,c,true)}
function kv(a,b,c){jv(a,nh(b,37),c)}
function wq(a,b){_c(a,(es(),fs(b)))}
function pd(a,b){a.textContent=b||uC}
function ky(b,a){return BC+a in b.f}
function hx(b,a){return b.indexOf(a)}
function sh(a){return a==null?null:a}
function pB(a){return a<10?RC+a:uC+a}
function vc(a){return parseInt(a)||-1}
function od(a,b){return a.contains(b)}
function mh(a,b){return a.cM&&a.cM[b]}
function ul(a){return vl(a.l,a.m,a.h)}
function Ix(a){Fx(this);Zc(this.b,a)}
function ef(a){this.b=new tf;this.c=a}
function Hm(){this.b='localStorage'}
function Od(){this.c='INLINE_BLOCK'}
function Xb(a){$wnd.clearTimeout(a)}
function pA(a,b,c,d){a.splice(b,c,d)}
function oo(a,b,c){return on(a.b,b,c)}
function us(){ps();return $doc.body}
function Kq(){if(!Gq){jr();Gq=true}}
function Wq(){if(!Uq){er();Uq=true}}
function km(a,b){Gx(a.b,b.b);return a}
function az(a,b){(a<0||a>=b)&&fz(a,b)}
function bs(a,b,c){var d;d=c;cs(a,b,d)}
function gc(a,b){a.d=jc(a.d,[b,false])}
function gs(b,a){b.__gwt_resolve=hs(a)}
function Yn(a){Zn.call(this,new io(a))}
function io(a){this.b=a;fn(this,this.b)}
function Wb(a){return a.$H||(a.$H=++Ob)}
function rh(a){return a.tM==TB||lh(a,1)}
function nx(a){return dh(pl,XB,1,a,0)}
function Yq(a){return !qh(a)&&ph(a,22)}
function zb(a){return qh(a)?uc(oh(a)):uC}
function fx(b,a){return b.charCodeAt(a)}
function _c(b,a){return b.appendChild(a)}
function dd(b,a){return b.removeChild(a)}
function ad(a,b){return a.childNodes[b]}
function lh(a,b){return a.cM&&!!a.cM[b]}
function ph(a,b){return a!=null&&lh(a,b)}
function bm(c,a,b){return a.replace(c,b)}
function BB(a,b){return py(a.b,b)!=null}
function wp(a){return (!a.f?a.j:a.f).n.c}
function ix(b,a){return b.lastIndexOf(a)}
function Fy(a){return a.c=nh(oz(a.b),57)}
function Nc(){var a;a=Lc(new Vc);Pc(a)}
function Ho(){Go=rC(function(a){Jo(a)})}
function ve(){ve=TB;ue=new Ge(JC,new we)}
function Le(){Le=TB;Ke=new Ge(KC,new Me)}
function Cr(){Cr=TB;Ar=new Gr;Br=new Jr}
function Cq(){Cq=TB;Bq=new aA;Iq(new Eq)}
function Tw(){Tw=TB;Sw=dh(ml,XB,48,256,0)}
function Vz(a){a.b=dh(nl,XB,0,0,0);a.c=0}
function xv(a,b){cu(a.c.b,b);Cv(a);Bv(a)}
function iv(a,b,c,d){hv(a,b,nh(c,37),d)}
function lf(a,b,c){var d;d=of(a,b);d.gb(c)}
function pf(a,b){var c;c=qf(a,b);return c}
function Wz(a,b){az(b,a.c);return a.b[b]}
function fz(a,b){throw new Iw(JD+a+KD+b)}
function Lm(a,b){return $wnd[a].getItem(b)}
function vp(a,b){return Qp(!a.f?a.j:a.f,b)}
function yb(a){return a==null?null:a.name}
function wb(a){return a==null?null:a.message}
function hb(){return (new Date).getTime()}
function vb(a){return qh(a)?wb(oh(a)):a+uC}
function Rb(a,b,c){return a.apply(b,c);var d}
function jx(c,a,b){return c.lastIndexOf(a,b)}
function td(b,a){return b.getElementById(a)}
function fc(a,b){a.b=jc(a.b,[b,false]);ec(a)}
function Lz(a){var b;b=Fy(a.b);return b.yb()}
function To(a){var b;b=Qo(a);!!b&&gd(b,eD)}
function ow(a){var b=Zl[a.c];a=null;return b}
function zc(){try{null.a()}catch(a){return a}}
function Tz(a,b){fh(a.b,a.c++,b);return true}
function jf(a,b){!a.b&&(a.b=new aA);Tz(a.b,b)}
function Xe(a){var b;if(Ue){b=new Ve;df(a,b)}}
function cf(a,b,c){return new vf(kf(a.b,b,c))}
function cd(c,a,b){return c.insertBefore(a,b)}
function ed(c,a,b){return c.replaceChild(a,b)}
function tf(){this.e=new wB;this.d=false}
function an(a,b,c){this.c=a;this.d=b;this.b=c}
function av(a,b,c){this.b=a;this.d=b;this.c=c}
function Xu(a,b,c){this.b=a;this.d=b;this.c=c}
function Zu(a,b,c){this.b=a;this.d=b;this.c=c}
function tv(a,b,c){this.d=a;this.b=b;this.c=c}
function qs(a){tr.call(this);this.v=a;qn(this)}
function _v(){rb.call(this,'divide by zero')}
function Yo(a){Zo.call(this,a,!Oo&&(Oo=new gp))}
function tb(a){Nc(Kc());this.f=!a?null:nb(a)}
function st(a){this.c=a;this.b=dh(ll,XB,30,4,0)}
function sv(a,b){this.d=a;this.b=false;this.c=b}
function Ug(a){if(a==null){throw new Xw}this.b=a}
function yx(){if(tx==256){sx=ux;ux={};tx=0}++tx}
function Ud(){Ud=TB;Rd=[];Sd=[];Td=[];Pd=new Zd}
function ih(){ih=TB;gh=[];hh=[];jh(new _g,gh,hh)}
function kp(){kp=TB;ep=new dm((Cm(),new zm))}
function dw(){dw=TB;new ew(false);new ew(true)}
function Kc(){Kc=TB;Error.stackTraceLimit=128}
function lx(b,a){return b.substr(a,b.length-a)}
function pw(a){return typeof a=='number'&&a>0}
function qh(a){return a!=null&&a.tM!=TB&&!lh(a,1)}
function Zt(a){a.g.ib();a.j=a.i=0;a.k=true;$t(a)}
function rs(a){ps();try{a.U()}finally{BB(os,a)}}
function Xd(){if(!Qd){Qd=true;gc((_b(),$b),Pd)}}
function uo(a,b){a.b.k=true;Uo(a.b,b);a.b.k=false}
function to(a,b,c,d){a.b.j=a.b.j||d;Xo(a.b,b,c,d)}
function qr(a,b){if(b<0||b>=a.c.d){throw new Hw}}
function jc(a,b){!a&&(a=[]);a[a.length]=b;return a}
function ee(a,b){var c;c=ce(b);_c(de(a),c);return c}
function Lp(c){c.sort(function(a,b){return a-b})}
function Fn(a){if(a.q){return a.q.R()}return false}
function uh(a){if(a!=null){throw new tw}return null}
function Rp(a){this.n=new aA;this.o=new CB;this.g=a}
function dm(a){this.c=0;this.d=0;this.b=26;this.e=a}
function yf(a){sb.call(this,Af(a),zf(a));this.b=a}
function du(a,b){eu.call(this,a,b,null,0);Et(a,b.c)}
function Fs(){Gs.call(this,$doc.createElement(ZC))}
function ps(){ps=TB;ms=new ws;ns=new wB;os=new CB}
function tq(){tq=TB;rq=new pq;sq=new pq;qq=new pq}
function Zf(){Zf=TB;Xf=new $f(false);Yf=new $f(true)}
function $x(a){var b;b=new zy(a);return new Gz(a,b)}
function zB(a,b){var c;c=ly(a.b,b,a);return c==null}
function wc(a,b){a.length>=b&&a.splice(0,b);return a}
function Gl(a,b){return a.l==b.l&&a.m==b.m&&a.h==b.h}
function Ql(a,b){return vl(a.l^b.l,a.m^b.m,a.h^b.h)}
function hd(b,a){return b[a]==null?null:String(b[a])}
function Jq(a,b){return cf((!Hq&&(Hq=new Tq),Hq),a,b)}
function Iq(a){Kq();return Jq(Ue?Ue:(Ue=new Fe),a)}
function wA(a){uA();return a?new gB(a):new TA(null)}
function Db(a){var b;return b=a,rh(b)?b.hC():Wb(b)}
function Cb(a,b){var c;return c=a,rh(c)?c.eQ(b):c===b}
function Tt(a,b){var c;c=a.b.g.rb();c>0&&Gt(b,0,a.b)}
function Fz(a){var b;b=new Hy(a.c.b);return new Mz(b)}
function rl(a){if(ph(a,52)){return a}return new ub(a)}
function fm(a){if(a==null){throw new Yw(SC)}this.b=a}
function nm(a){if(a==null){throw new Yw(SC)}this.b=a}
function cx(a,b){this.b=DC;this.e=a;this.c=b;this.d=-1}
function ey(a){a.b=[];a.f={};a.d=false;a.c=null;a.e=0}
function so(a){a.c&&(!Co&&(Co=new Mo),Lo(new xo(a)))}
function sf(a,b,c){a.c>0?jf(a,new av(a,b,c)):nf(a,b,c)}
function vl(a,b,c){return _=new Xl,_.l=a,_.m=b,_.h=c,_}
function op(a,b){return oo(a.k,b,(!Kt&&(Kt=new Fe),Kt))}
function pp(a,b){return oo(a.k,b,(!Pu&&(Pu=new Fe),Pu))}
function vB(a,b){return sh(a)===sh(b)||a!=null&&Cb(a,b)}
function SB(a,b){return sh(a)===sh(b)||a!=null&&Cb(a,b)}
function up(a){return (fq(),dq)==a.e?-1:(!a.f?a.j:a.f).e}
function on(a,b,c){return cf(!a.t?(a.t=new ef(a)):a.t,c,b)}
function fv(a,b){var c;c=bd(a.firstChild);rv(b,c.value)}
function Mc(a,b){var c;c=Oc(a,qh(b.c)?oh(b.c):null);Pc(c)}
function Rn(a){var b;b=Qo(a);!!b&&(b.focus(),undefined)}
function Tu(a){var b;if(Pu){b=new Ru;!!a.t&&df(a.t,b)}}
function wg(a,b){if(b==null){throw new Xw}return xg(a,b)}
function nt(a,b){if(b<0||b>=a.d){throw new Hw}return a.b[b]}
function nh(a,b){if(a!=null&&!mh(a,b)){throw new tw}return a}
function dh(a,b,c,d,e){var f;f=ch(e,d);eh(a,b,c,f);return f}
function vA(a){uA();var b;b=new DB;zB(b,a);return new iB(b)}
function Jb(a){var b=Gb[a.charCodeAt(0)];return b==null?a:b}
function vt(a){if(a.b>=a.c.d){throw new RB}return a.c.b[++a.b]}
function gx(a,b){if(!ph(b,1)){return false}return String(a)==b}
function fs(a){return a.__gwt_resolve?a.__gwt_resolve():a}
function yp(a){return (!a.f?a.j:a.f).k&&(!a.f?a.j:a.f).j==0}
function xp(a){return new Ku((!a.f?a.j:a.f).i,(!a.f?a.j:a.f).g)}
function mv(){eb.call(this,eh(pl,XB,1,[JC,KC,bD,lD]))}
function Wr(){tr.call(this);fn(this,$doc.createElement(ZC))}
function ub(a){qb.call(this);this.c=a;this.b=uC;Mc(new Vc,this)}
function rt(a,b){var c;c=ot(a,b);if(c==-1){throw new RB}qt(a,c)}
function pr(a,b,c){sn(b);mt(a.c,b);_c(c,(es(),fs(b.v)));tn(b,a)}
function Sz(a,b,c){(b<0||b>a.c)&&fz(b,a.c);pA(a.b,b,0,c);++a.c}
function pz(a){if(a.d<0){throw new Ew}a.e.pb(a.d);a.c=a.d;a.d=-1}
function Un(a,b){if(a.n){Wu(a.n.b);a.n=null}!!b&&(a.n=op(a.o,b))}
function un(a,b){a.s==-1?hr(a.v,b|(a.v.__eventBits||0)):(a.s|=b)}
function Do(a,b){return AB(a.c,b.tagName.toLowerCase())||qd(b)>=0}
function Mm(a,b){$wnd[a].getItem(YC);$wnd[a].setItem(YC,b)}
function Cm(){Cm=TB;new RegExp('%5B',UC);new RegExp('%5D',UC)}
function ss(){ps();try{Er(os,ms)}finally{ey(os.b);ey(ns)}}
function Ub(a,b,c){var d;d=Sb();try{return Rb(a,b,c)}finally{Vb(d)}}
function $z(a,b,c){var d;d=(az(b,a.c),a.b[b]);fh(a.b,b,c);return d}
function mw(a,b,c){var d;d=new kw;d.d=a+b;pw(c)&&qw(c,d);return d}
function fe(a,b){var c;c=ce(b);cd(de(a),c,a.b.firstChild);return c}
function ny(a,b){var c;c=a.c;a.c=b;if(!a.d){a.d=true;++a.e}return c}
function nb(a){var b,c;b=a.cZ.d;c=a.w();return c!=null?b+tC+c:b}
function Vt(a){this.c=new CB;this.f=new wB;this.b=new du(this,a)}
function Lt(a,b,c,d,e){this.g=a;this.c=b;this.b=c;this.e=d;this.f=e}
function eh(a,b,c,d){ih();kh(d,gh,hh);d.cZ=a;d.cM=b;d.qI=c;return d}
function bh(a,b){var c,d;c=a;d=ch(0,b);eh(c.cZ,c.cM,c.qI,d);return d}
function ry(a){var b;b=a.c;a.c=null;if(a.d){a.d=false;--a.e}return b}
function V(a){if(!a.f){return}a.i=a.g;a.f=false;a.g=false;a.i&&Zr(a)}
function ld(a){if(fd(a)){return !!a&&a.nodeType==1}return false}
function fd(b){try{return !!b&&!!b.nodeType}catch(a){return false}}
function hs(a){return function(){this.__gwt_resolve=is;return a.O()}}
function qd(a){return typeof a.tabIndex!='undefined'?a.tabIndex:-1}
function th(a){return ~~Math.max(Math.min(a,2147483647),-2147483648)}
function bA(a){Rz(this);qA(this.b,0,0,a.g.tb());this.c=this.b.length}
function oh(a){if(a!=null&&(a.tM==TB||lh(a,1))){throw new tw}return a}
function sd(a){!a.gwt_uid&&(a.gwt_uid=1);return 'gwt-uid-'+a.gwt_uid++}
function oz(a){if(a.c>=a.e.rb()){throw new RB}return a.e.kb(a.d=a.c++)}
function zg(d,a,b){if(b){var c=b.I();d.b[a]=c(b)}else{delete d.b[a]}}
function Mf(d,a,b){if(b){var c=b.I();b=c(b)}else{b=undefined}d.b[a]=b}
function kh(a,b,c){ih();for(var d=0,e=b.length;d<e;++d){a[b[d]]=c[d]}}
function qA(a,b,c,d){Array.prototype.splice.apply(a,[b,c].concat(d))}
function lv(a,b,c){var d;d=new lm;jv(a,c,d);jd(b,(new nm(d.b.b.b)).b)}
function $n(a,b,c){b.__listener=a;jd(b,c.b);b.__listener=null;return b}
function Xz(a,b,c){for(;c<a.c;++c){if(SB(b,a.b[c])){return c}}return -1}
function Yz(a,b){var c;c=(az(b,a.c),a.b[b]);oA(a.b,b,1);--a.c;return c}
function nd(a){var b=a.parentNode;(!b||b.nodeType!=1)&&(b=null);return b}
function rd(a){var b=a.target;b&&b.nodeType==3&&(b=b.parentNode);return b}
function rp(a){!a.f&&(a.f=new Tp(a.j));a.g=new Np(a);Ap(a.g);return a.f}
function Ym(a){var b,c;Zm();b=nd(a);c=md(a);_c(Xm,a);return new an(b,c,a)}
function Oc(a,b){var c;c=Gc(a,b);return c.length==0?(new Ac).B(b):wc(c,1)}
function yv(a,b){if(a.b){return}gx(mx(b.d),uC)&&cu(a.c.b,b);Cv(a);Bv(a)}
function wt(a){if(a.b<0||a.b>=a.c.d){throw new Ew}a.c.c.ab(a.c.b[a.b--])}
function Au(a){if(a.b>=a.d.g.rb()){throw new RB}return au(a.d,a.c=a.b++)}
function zf(a){var b;b=a.bb();if(!b.db()){return null}return nh(b.eb(),52)}
function Lq(){var a;if(Gq){a=new Pq;!!Hq&&df(Hq,a);return null}return null}
function ah(a,b){var c,d;c=a;d=c.slice(0,b);eh(c.cZ,c.cM,c.qI,d);return d}
function fy(a,b){return b==null?a.d:ph(b,1)?ky(a,nh(b,1)):jy(a,b,~~Db(b))}
function gy(a,b){return b==null?a.c:ph(b,1)?iy(a,nh(b,1)):hy(a,b,~~Db(b))}
function Yb(){return $wnd.setTimeout(function(){Nb!=0&&(Nb=0);Qb=-1},10)}
function Vb(a){a&&bc((_b(),$b));--Nb;if(a){if(Qb!=-1){Xb(Qb);Qb=-1}}}
function jh(a,b,c){var d=0,e;for(var f in a){if(e=a[f]){b[d]=f;c[d]=e;++d}}}
function oy(e,a,b){var c,d=e.f;a=BC+a;a in d?(c=d[a]):++e.e;d[a]=b;return c}
function ot(a,b){var c;for(c=0;c<a.d;++c){if(a.b[c]==b){return c}}return -1}
function cu(a,b){var c;c=a.g.lb(b);if(c==-1){return false}bu(a,c);return true}
function nw(a,b,c,d){var e;e=new kw;e.d=a+b;pw(c)&&qw(c,e);e.b=d?8:0;return e}
function Zz(a,b){var c;c=Xz(a,b,0);if(c==-1){return false}Yz(a,c);return true}
function yg(a,b,c){var d;if(b==null){throw new Xw}d=wg(a,b);zg(a,b,c);return d}
function py(a,b){return b==null?ry(a):ph(b,1)?sy(a,nh(b,1)):qy(a,b,~~Db(b))}
function vz(a,b){var c;this.b=a;this.e=a;c=a.rb();(b<0||b>c)&&fz(b,c);this.c=b}
function eu(a,b,c,d){this.o=a;this.e=new xu(this);this.g=b;this.c=c;this.n=d}
function Ge(a,b){Fe.call(this);this.b=b;!pe&&(pe=new Se);Re(pe,a,this);this.c=a}
function ds(a){tr.call(this);fn(this,$doc.createElement(ZC));jd(this.v,a)}
function Zm(){if(!Xm){Xm=$doc.createElement(ZC);ln(Xm,false);_c(us(),Xm)}}
function is(){throw 'A PotentialElement cannot be resolved twice.'}
function Km(){this.b=$wnd.localStorage!=null;$wnd.sessionStorage!=null}
function ox(a,b,c){a=a.slice(b,c);return String.fromCharCode.apply(null,a)}
function ln(a,b){a.style.display=b?uC:$C;a.setAttribute('aria-hidden',String(!b))}
function xr(a){a.style['left']=uC;a.style['top']=uC;a.style['position']=uC}
function ks(b){es();try{return !!b&&!!b.__gwt_resolve}catch(a){return false}}
function Tb(b){return function(){try{return Ub(b,this,arguments)}catch(a){throw a}}}
function ly(a,b,c){return b==null?ny(a,c):ph(b,1)?oy(a,nh(b,1),c):my(a,b,c,~~Db(b))}
function Nt(a,b,c,d,e,f){var g;g=new Lt(b,c,d,e,f);!!Kt&&!!a.t&&df(a.t,g);return g}
function Lc(a){var b;b=wc(Oc(a,zc()),3);b.length==0&&(b=wc((new Ac).z(),1));return b}
function md(a){var b=a.nextSibling;while(b&&b.nodeType!=1)b=b.nextSibling;return b}
function sy(d,a){var b,c=d.f;a=BC+a;if(a in c){b=c[a];--d.e;delete c[a]}return b}
function Lf(d,a){var b=d.b[a];var c=(Jg(),Ig)[typeof b];return c?c(b):Sg(typeof b)}
function xq(a,b,c){var d;d=uq;uq=a;b==vq&&Vq(a.type)==8192&&(vq=null);c.T(a);uq=d}
function Qn(a,b,c){var d;d=$n(a,(!Ln&&(Ln=$doc.createElement(ZC)),Ln),c);eo(a.d,d,b)}
function dv(){var a;Vs();Ws.call(this,(a=$doc.createElement(LD),a.type='text',a))}
function ce(a){var b;b=$doc.createElement(IC);b['language']='text/css';pd(b,a);return b}
function de(a){var b;if(!a.b){b=$doc.getElementsByTagName('head')[0];a.b=b}return a.b}
function ac(a){var b,c;if(a.c){c=null;do{b=a.c;a.c=null;c=lc(b,c)}while(a.c);a.c=c}}
function bc(a){var b,c;if(a.d){c=null;do{b=a.d;a.d=null;c=lc(b,c)}while(a.d);a.d=c}}
function Ow(a){var b,c;if(a==0){return 32}else{c=0;for(b=1;(b&a)==0;b<<=1){++c}return c}}
function tl(a){var b,c,d;b=a&4194303;c=~~a>>22&4194303;d=a<0?1048575:0;return vl(b,c,d)}
function Ft(a,b,c){var d,e;for(e=Fz($x(a.c.b));nz(e.b.b);){d=nh(Lz(e),32);Gt(d,b,c)}}
function Du(a,b){var c;this.d=a;c=a.g.rb();if(b<0||b>c){throw new Iw(JD+b+KD+c)}this.b=b}
function xb(a){var b;return a==null?vC:qh(a)?yb(oh(a)):ph(a,1)?wC:(b=a,rh(b)?b.cZ:Dh).d}
function cc(a){var b;if(a.b){b=a.b;a.b=null;!a.g&&(a.g=[]);lc(b,a.g)}!!a.g&&(a.g=kc(a.g))}
function Vr(a,b){var c;qr(a,b);c=a.b;a.b=nt(a.c,b);if(a.b!=c){!Tr&&(Tr=new _r);$r(Tr,c,a.b)}}
function Yt(a,b){var c;a.j=Vw(a.j,a.g.rb());c=a.g.hb(b);a.i=a.g.rb();a.k=true;$t(a);return c}
function lw(a,b,c){var d;d=new kw;d.d=a+b;pw(c!=0?-c:0)&&qw(c!=0?-c:0,d);d.b=4;return d}
function Im(){!Fm&&(Fm=new Km);if(Fm.b){!Em&&(Em=new Hm);return Em}return null}
function Qo(a){var b;b=up(a.o);if(b>=0&&a.d.childNodes.length>b){return ad(a.d,b)}return null}
function vg(e,a){var b=e.b;var c=0;for(var d in b){b.hasOwnProperty(d)&&(a[c++]=d)}return a}
function Ro(a,b){zp(a.o,null);On(a,b);if(a.d.childNodes.length>b){return ad(a.d,b)}return null}
function Xt(a,b){var c;c=a.g.gb(b);a.j=Vw(a.j,a.g.rb()-1);a.i=a.g.rb();a.k=true;$t(a);return c}
function Hp(a,b){this.d=(Zp(),Wp);this.e=(fq(),eq);this.b=a;this.k=b;this.j=new Rp(25)}
function Hy(a){var b;this.d=a;b=new aA;a.d&&Tz(b,new Qy(a));dy(a,b);cy(a,b);this.b=new qz(b)}
function Ws(a){Ss.call(this,a,(!Sm&&(Sm=new Tm),!Pm&&(Pm=new Qm)));this.v[AD]='gwt-TextBox'}
function Fd(){Fd=TB;Ed=new Id;Bd=new Kd;Cd=new Md;Dd=new Od;Ad=eh(gl,XB,3,[Ed,Bd,Cd,Dd])}
function bt(){bt=TB;Zs=new et;$s=new gt;_s=new it;at=new kt;Ys=eh(kl,XB,29,[Zs,$s,_s,at])}
function Vl(){Vl=TB;Rl=vl(4194303,4194303,524287);Sl=vl(0,0,524288);Tl=Il(1);Il(2);Ul=Il(0)}
function Jg(){Jg=TB;Ig={'boolean':Kg,number:Lg,string:Ng,object:Mg,'function':Mg,undefined:Og}}
function Xn(a,b){if(!a){return}b?(a.style[_C]=uC,undefined):(a.style[_C]=(Fd(),$C),undefined)}
function Es(a,b){if(a.b!=b){return false}try{tn(b,null)}finally{dd(a.v,b.v);a.b=null}return true}
function Uz(a,b){var c,d;c=b.tb();d=c.length;if(d==0){return false}qA(a.b,a.c,0,c);a.c+=d;return true}
function Ox(a,b){var c;while(a.db()){c=a.eb();if(b==null?c==null:Cb(b,c)){return a}}return null}
function Cl(a){var b,c;c=Nw(a.h);if(c==32){b=Nw(a.m);return b==32?Nw(a.l)+32:b+20-10}else{return c-12}}
function wv(a){var b,c;c=new Cu(a.c.b);while(c.b<c.d.g.rb()){b=nh(Au(c),37);b.b&&Bu(c)}Cv(a);Bv(a)}
function Et(a,b){var c,d;a.d=b;a.e=true;for(d=Fz($x(a.c.b));nz(d.b.b);){c=nh(Lz(d),32);c.Z(b,true)}}
function ec(a){if(!a.j){a.j=true;!a.f&&(a.f=new oc(a));mc(a.f,1);!a.i&&(a.i=new rc(a));mc(a.i,50)}}
function Dp(a,b,c){if(b==(!a.f?a.j:a.f).j&&c==(!a.f?a.j:a.f).k){return}rp(a).j=b;rp(a).k=c;Gp(a)}
function Cp(a,b){if(!b){throw new Yw('KeyboardSelectionPolicy cannot be null')}a.e=b}
function On(a,b){if(!(b>=0&&b<wp(a.o))){throw new Iw('Row index: '+b+', Row size: '+tp(a.o).j)}}
function Dv(a){this.e=new Gv(this);this.c=new Ut;this.d=a;zv(this);Iv(a,this.e);Kv(a,this.c);Cv(this)}
function Sg(a){Jg();throw new eg("Unexpected typeof result '"+a+"'; please report this bug to the GWT team")}
function mc(b,c){_b();$wnd.setTimeout(function(){var a=rC(ic)(b);a&&$wnd.setTimeout(arguments.callee,c)},c)}
function co(a,b,c){Fn(a)||Xq(a.v,a);jd(b,(!Co&&(Co=new Mo),c).b);Fn(a)||(a.v.__listener=null,undefined)}
function yl(a,b,c,d,e){var f;f=Ll(a,b);c&&Bl(f);if(e){a=Al(a,b);d?(sl=Jl(a)):(sl=vl(a.l,a.m,a.h))}return f}
function sr(a,b){var c;if(b.u!=a){return false}try{tn(b,null)}finally{c=b.v;dd(nd(c),c);rt(a.c,b)}return true}
function dr(a,b){var c=0,d=a.firstChild;while(d){if(d===b){return c}d.nodeType==1&&++c;d=d.nextSibling}return -1}
function xx(a){vx();var b=BC+a;var c=ux[b];if(c!=null){return c}c=sx[b];c==null&&(c=wx(a));yx();return ux[b]=c}
function Rw(a){var b,c;if(a>-129&&a<128){b=a+128;c=(Tw(),Sw)[b];!c&&(c=Sw[b]=new Kw(a));return c}return new Kw(a)}
function rf(a){var b,c;if(a.b){try{for(c=new qz(a.b);c.c<c.e.rb();){b=nh(oz(c),35);b.y()}}finally{a.b=null}}}
function qt(a,b){var c;if(b<0||b>=a.d){throw new Hw}--a.d;for(c=b;c<a.d;++c){fh(a.b,c,a.b[c+1])}fh(a.b,a.d,null)}
function rn(a,b){var c;switch(Vq(b.type)){case 16:case 32:c=b.relatedTarget;if(!!c&&od(a.v,c)){return}}se(b,a,a.v)}
function Gc(a,b){var c,d,e;e=b&&b.stack?b.stack.split('\n'):[];for(c=0,d=e.length;c<d;++c){e[c]=a.A(e[c])}return e}
function mb(a){var b,c,d;c=dh(ol,XB,51,a.length,0);for(d=0,b=a.length;d<b;++d){if(!a[d]){throw new Xw}c[d]=a[d]}}
function of(a,b){var c,d;d=nh(gy(a.e,b),56);if(!d){d=new wB;ly(a.e,b,d)}c=nh(d.c,55);if(!c){c=new aA;ny(d,c)}return c}
function vv(a){var b,c;b=mx(hd(a.d.g.v,ND));if(gx(b,uC))return;c=new sv(b,a);a.d.g.v[ND]=uC;Xt(a.c.b,c);Cv(a);Bv(a)}
function dy(e,a){var b=e.f;for(var c in b){if(c.charCodeAt(0)==58){var d=new Vy(e,c.substring(1));a.gb(d)}}}
function Rr(){var a;Qr.call(this,(a=$doc.createElement(zD),a.setAttribute('type',hD),a));this.v[AD]='gwt-Button'}
function Jv(a,b){b?(a.setAttribute(IC,'display:none;'),undefined):(a.setAttribute(IC,'display:block;'),undefined)}
function Gy(a){if(!a.c){throw new Fw('Must call next() before remove().')}else{pz(a.b);py(a.d,a.c.yb());a.c=null}}
function gwtOnLoad(b,c,d,e){$moduleName=c;$moduleBase=d;if(b)try{rC(ql)()}catch(a){b(c)}else{rC(ql)()}}
function Cv(a){var b,c,d,e;e=a.c.b.g.rb();b=0;for(d=new Cu(a.c.b);d.b<d.d.g.rb();){c=nh(Au(d),37);c.b&&++b}Lv(a.d,e,b)}
function Jl(a){var b,c,d;b=~a.l+1&4194303;c=~a.m+(b==0?1:0)&4194303;d=~a.h+(b==0&&c==0?1:0)&1048575;return vl(b,c,d)}
function Bl(a){var b,c,d;b=~a.l+1&4194303;c=~a.m+(b==0?1:0)&4194303;d=~a.h+(b==0&&c==0?1:0)&1048575;a.l=b;a.m=c;a.h=d}
function Nl(a,b){var c,d,e;c=a.l-b.l;d=a.m-b.m+(~~c>>22);e=a.h-b.h+(~~d>>22);return vl(c&4194303,d&4194303,e&1048575)}
function yy(a,b){var c,d,e;if(ph(b,57)){c=nh(b,57);d=c.yb();if(fy(a.b,d)){e=gy(a.b,d);return vB(c.zb(),e)}}return false}
function qf(a,b){var c,d;d=nh(gy(a.e,b),56);if(!d){return uA(),uA(),tA}c=nh(d.c,55);if(!c){return uA(),uA(),tA}return c}
function ts(){ps();var a;a=nh(gy(ns,null),27);if(a){return a}ns.e==0&&Iq(new zs);a=new Cs;ly(ns,null,a);zB(os,a);return a}
function Sb(){var a;if(Nb!=0){a=hb();if(a-Pb>2000){Pb=a;Qb=Yb()}}if(Nb++==0){ac((_b(),$b));return true}return false}
function Wo(a){var b;b=up(a.o);if(b>=0&&b<tp(a.o).n.c){Qo(a);On(a,b);vp(a.o,b);new gb(b+xp(a.o).c,a.o);return false}return false}
function Iv(a,b){var c;c=a.k;Wq();ir(c,1);Xq(c,new Ov(a,b));nn(a.g,new Rv(b),(Le(),Le(),Ke));nn(a.b,new Uv(b),(ve(),ve(),ue))}
function nf(a,b,c){var d,e,f;d=qf(a,b);e=d.qb(c);e&&d.mb()&&(f=nh(gy(a.e,b),56),nh(ry(f),55),f.e==0&&py(a.e,b),undefined)}
function se(a,b,c){var d,e,f;if(pe){f=nh(Qe(pe,a.type),6);if(f){d=f.b.b;e=f.b.c;qe(f.b,a);re(f.b,c);pn(b,f.b);qe(f.b,d);re(f.b,e)}}}
function Sn(a,b,c){var d;if(c){d=b;kd(d,a.p)}else{b.tabIndex=-1;b.removeAttribute('tabIndex');b.removeAttribute('accessKey')}}
function iw(a){if(a>=48&&a<58){return a-48}if(a>=97&&a<97){return a-97+10}if(a>=65&&a<65){return a-65+10}return -1}
function xl(a,b){if(a.h==524288&&a.m==0&&a.l==0){b&&(sl=vl(0,0,0));return ul((Vl(),Tl))}b&&(sl=vl(a.l,a.m,a.h));return vl(0,0,0)}
function Il(a){var b,c;if(a>-129&&a<128){b=a+128;Fl==null&&(Fl=dh(hl,XB,16,256,0));c=Fl[b];!c&&(c=Fl[b]=tl(a));return c}return tl(a)}
function Nf(a){var b,c,d;d=new Cx;d.b.b+=EC;for(c=0,b=a.b.length;c<b;++c){c>0&&(d.b.b+=LC,d);Ax(d,Lf(a,c))}d.b.b+=FC;return d.b.b}
function jy(h,a,b){var c=h.b[b];if(c){for(var d=0,e=c.length;d<e;++d){var f=c[d];var g=f.yb();if(h.xb(a,g)){return true}}}return false}
function cy(h,a){var b=h.b;for(var c in b){var d=parseInt(c,10);if(c==d){var e=b[d];for(var f=0,g=e.length;f<g;++f){a.gb(e[f])}}}}
function hy(h,a,b){var c=h.b[b];if(c){for(var d=0,e=c.length;d<e;++d){var f=c[d];var g=f.yb();if(h.xb(a,g)){return f.zb()}}}return null}
function po(b,c,d){var a,e;try{e=new lm;Vo(b.b,e,c,d);return new nm(e.b.b.b)}catch(a){a=rl(a);if(ph(a,53)){return null}else throw a}}
function _z(a,b){var c;b.length<a.c&&(b=bh(b,a.c));for(c=0;c<a.c;++c){fh(b,c,a.b[c])}b.length>a.c&&fh(b,a.c,null);return b}
function Uo(a,b){var c;c=null;b==(tq(),rq)?(c=a.f):b==qq&&yp(a.o)&&(c=a.e);!!c&&Vr(a.g,rr(a.g,c));Xn(a.d,!c);gn(a.g,!!c);pn(a,new lq)}
function Xo(a,b,c,d){var e;if(!(b>=0&&b<tp(a.o).n.c)){return}e=Ro(a,b);(!c||a.j||d)&&kn(e,eD,c);Sn(a,e,c);if(c&&d&&!a.c){e.focus();To(a)}}
function fq(){fq=TB;dq=new gq('DISABLED');eq=new gq('ENABLED');cq=new gq('BOUND_TO_SELECTION');bq=eh(jl,XB,21,[dq,eq,cq])}
function Zp(){Zp=TB;Xp=new $p('CURRENT_PAGE',true);Wp=new $p('CHANGE_PAGE',false);Yp=new $p('INCREASE_RANGE',false);Vp=eh(il,XB,20,[Xp,Wp,Yp])}
function Z(){Z=TB;var a;a=new cb;!!a&&(!!($wnd.webkitRequestAnimationFrame&&$wnd.webkitCancelRequestAnimationFrame)||new ab)}
function mx(c){if(c.length==0||c[0]>HC&&c[c.length-1]>HC){return c}var a=c.replace(/^(\s*)/,uC);var b=a.replace(/\s*$/,uC);return b}
function Bu(a){if(a.c<0){throw new Fw('Cannot call add/remove more than once per call to next/previous.')}bu(a.d,a.c);a.b=a.c;a.c=-1}
function xg(f,a){var b=f.b;var c;a=String(a);b.hasOwnProperty(a)&&(c=b[a]);var d=(Jg(),Ig)[typeof c];var e=d?d(c):Sg(typeof c);return e}
function wm(){wm=TB;new nm(uC);rm=new RegExp(TC,UC);sm=new RegExp(VC,UC);tm=new RegExp(WC,UC);vm=new RegExp(XC,UC);um=new RegExp(zC,UC)}
function nn(a,b,c){var d;d=Vq(c.c);d==-1?hn(a,c.c):a.s==-1?hr(a.v,d|(a.v.__eventBits||0)):(a.s|=d);return cf(!a.t?(a.t=new ef(a)):a.t,c,b)}
function Yv(a){var b;b=new Hx;b.b.b+="Clear completed (<span class='number-done' id='";Gx(b,xm(a));b.b.b+="'><\/span>)";return new fm(b.b.b)}
function eb(a){var b,c,d,e;e=null;if(a!=null&&a.length>0){e=new CB;for(c=0,d=a.length;c<d;++c){b=a[c];zB(e,b)}}!!e&&(this.d=(uA(),new iB(e)))}
function yc(b){var c=uC;try{for(var d in b){if(d!='name'&&d!='message'&&d!='toString'){try{c+='\n '+d+tC+b[d]}catch(a){}}}}catch(a){}return c}
function Lv(a,b,c){var d;d=b-c;Jv(a.d,b==0);Jv(a.i,b==0);Jv(a.b.v,c==0);pd(a.e,uC+d);pd(a.f,d>1||d==0?'items':'item');jd(a.c,uC+c);ud(a.k,b==c)}
function Gp(a){var b,c,d;d=(!a.f?a.j:a.f).i;b=Uw(0,Vw((!a.f?a.j:a.f).g,(!a.f?a.j:a.f).j-d));c=(!a.f?a.j:a.f).n.c-1;while(c>=b){Yz(rp(a).n,c);--c}}
function $t(a){if(a.c){a.c.j=Vw(a.j+a.n,a.c.j);a.c.i=Uw(a.i+a.n,a.c.i);a.c.k=a.k||a.c.k;$t(a.c);return}a.d=false;if(!a.f){a.f=true;gc((_b(),$b),a.e)}}
function Gt(a,b,c){var d,e,f,g,h,i,j,k,l;g=b+c.rb();h=a.Y();f=h.c;e=h.b;d=f+e;if(b==f||f<g&&d>b){k=f<b?b:f;i=d>g?g:d;j=i-k;l=c.sb(k-b,k-b+j);a.$(k,l)}}
function lc(b,c){var a,d,e,f;for(d=0,e=b.length;d<e;++d){f=b[d];try{f[1]?f[0].x()&&(c=jc(c,f)):f[0].y()}catch(a){a=rl(a);if(!ph(a,52))throw a}}return c}
function bu(b,c){var a,d,e;try{e=b.g.pb(c);b.j=Vw(b.j,c);b.i=b.g.rb();b.k=true;$t(b);return e}catch(a){a=rl(a);if(ph(a,47)){d=a;throw new Iw(d.f)}else throw a}}
function Al(a,b){var c,d,e;if(b<=22){c=a.l&(1<<b)-1;d=e=0}else if(b<=44){c=a.l;d=a.m&(1<<b-22)-1;e=0}else{c=a.l;d=a.m;e=a.h&(1<<b-44)-1}return vl(c,d,e)}
function Po(a,b,c,d){var e,f;f=a.b.d;if(!!f&&DA(f,b.type)){e=gv(a.b,nh(d,37));iv(a.b,c,d,b);a.c=gv(a.b,nh(d,37));e&&!a.c&&(!Co&&(Co=new Mo),Lo(new bp(a)))}}
function nv(a){var b;b=new Hx;b.b.b+="<div class='listItem editing'><input class='edit' value='";Gx(b,xm(a));b.b.b+="' type='text'><\/div>";return new fm(b.b.b)}
function qw(a,b){var c;b.c=a;if(a==2){c=String.prototype}else{if(a>0){var d=ow(b);if(d){c=d.prototype}else{d=Zl[a]=function(){};d.cZ=b;return}}else{return}}c.cZ=b}
function Av(a,b){var c,d,e;a.b=true;for(e=new Cu(a.c.b);e.b<e.d.g.rb();){d=nh(Au(e),37);d.b=b;yv(d.c,d)}a.b=false;c=new bA(a.c.b);Zt(a.c.b);Yt(a.c.b,c);Cv(a);Bv(a)}
function sn(a){if(!a.u){(ps(),AB(os,a))&&rs(a)}else if(ph(a.u,24)){nh(a.u,24).ab(a)}else if(a.u){throw new Fw("This widget's parent does not implement HasWidgets")}}
function En(a,b){var c;if(a.q){throw new Fw('Composite.initWidget() may only be called once.')}ph(b,25)&&nh(b,25);sn(b);c=b.v;a.v=c;ks(c)&&gs((es(),c),a);a.q=b;tn(b,a)}
function tB(){tB=TB;rB=eh(pl,XB,1,['Sun','Mon','Tue','Wed','Thu','Fri','Sat']);sB=eh(pl,XB,1,['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'])}
function $w(){$w=TB;Zw=eh(fl,XB,-1,[48,49,50,51,52,53,54,55,56,57,97,98,99,100,101,102,103,104,105,106,107,108,109,110,111,112,113,114,115,116,117,118,119,120,121,122])}
function sp(a,b,c){var d,e,f,g,h,i;if(b==null){return -1}e=-1;d=2147483647;i=a.n.c;for(h=0;h<i;++h){f=Wz(a.n,h);if(Cb(b,f)){g=c-h<0?-(c-h):c-h;if(g<d){e=h;d=g}}}return e}
function Pw(a){var b,c,d;b=dh(fl,XB,-1,8,1);c=($w(),Zw);d=7;if(a>=0){while(a>15){b[d--]=c[a&15];a>>=4}}else{while(d>0){b[d--]=c[a&15];a>>=4}}b[d]=c[a&15];return ox(b,d,8)}
function El(a,b){var c,d,e;e=a.h-b.h;if(e<0){return false}c=a.l-b.l;d=a.m-b.m+(~~c>>22);e+=~~d>>22;if(e<0){return false}a.l=c&4194303;a.m=d&4194303;a.h=e&1048575;return true}
function _t(a){var b;a.f&&(a.d=true);if(a.o.b!=a){return}b=a.g.rb();if(a.b!=b){a.b=b;Et(a.o,a.b)}if(a.k){Ft(a.o,a.j,a.g.sb(a.j,a.i));a.k=false}a.j=2147483647;a.i=-2147483648}
function Io(a,b,c){var d;if(AB(a.b,c)){!Go&&Ho();d=b.v;if(!gx(fD,d.getAttribute(gD+c)||uC)){d.setAttribute(gD+c,fD);d.addEventListener(c,Go,true)}return -1}else{return Vq(c)}}
function Px(a){var b,c,d,e;d=new Cx;b=null;d.b.b+=EC;c=a.bb();while(c.db()){b!=null?(Zc(d.b,b),d):(b=NC);e=c.eb();Zc(d.b,e===a?'(this Collection)':uC+e)}d.b.b+=FC;return d.b.b}
function ch(a,b){var c=new Array(b);if(a==3){for(var d=0;d<b;++d){var e=new Object;e.l=e.m=e.h=0;c[d]=e}}else if(a>0){var e=[null,0,false][a];for(var d=0;d<b;++d){c[d]=e}}return c}
function qy(h,a,b){var c=h.b[b];if(c){for(var d=0,e=c.length;d<e;++d){var f=c[d];var g=f.yb();if(h.xb(a,g)){c.length==1?delete h.b[b]:c.splice(d,1);--h.e;return f.zb()}}}return null}
function Qg(b){Jg();var a,c;if(b==null){throw new Xw}if(b.length==0){throw new Cw('empty argument')}try{return Pg(b,true)}catch(a){a=rl(a);if(ph(a,2)){c=a;throw new fg(c)}else throw a}}
function tn(a,b){var c;c=a.u;if(!b){try{!!c&&c.R()&&a.U()}finally{a.u=null}}else{if(c){throw new Fw('Cannot set a new parent without first clearing the old parent')}a.u=b;b.R()&&a.S()}}
function qo(a,b,c){var d,e;e=po(a,b,xp(a.b.o).c);a.b.j=a.b.j||c;a.c=a.b.j;a.b.k=true;Pn(a.b,e);a.b.k=false;d=Qo(a.b);if(d){Sn(a.b,d,true);a.b.j&&To(a.b)}pn(a.b,new Ao(wA(tp(a.b.o).n)))}
function ro(a,b,c,d){var e,f;f=po(a,b,xp(a.b.o).c+c);a.b.j=a.b.j||d;a.c=a.b.j;a.b.k=true;Qn(a.b,c,f);a.b.k=false;e=Qo(a.b);if(e){Sn(a.b,e,true);a.b.j&&To(a.b)}pn(a.b,new Ao(wA(tp(a.b.o).n)))}
function kf(a,b,c){if(!b){throw new Yw('Cannot add a handler with a null type')}if(!c){throw new Yw('Cannot add a null handler')}a.c>0?jf(a,new Zu(a,b,c)):lf(a,b,c);return new Xu(a,b,c)}
function am(a){return $stats({moduleName:$moduleName,sessionId:$sessionId,subSystem:'startup',evtGroup:'moduleStartup',millis:(new Date).getTime(),type:'onModuleLoadStart',className:a})}
function Jo(a){var b,c,d,e;b=rd(a);if(!ld(b)){return}d=b;e=a.type;c=d.__listener;while(!!d&&!c){d=nd(d);!!d&&gx(fD,d.getAttribute(gD+e)||uC)&&(c=d.__listener)}!!c&&(xq(a,d,c),undefined)}
function Er(b,c){Cr();var a,d,e,f,g;d=null;for(g=b.bb();g.db();){f=nh(g.eb(),30);try{c.cb(f)}catch(a){a=rl(a);if(ph(a,52)){e=a;!d&&(d=new CB);zB(d,e)}else throw a}}if(d){throw new Dr(d)}}
function tc(a){var b,c,d;d=uC;a=mx(a);b=a.indexOf(xC);c=a.indexOf(yC)==0?8:0;if(b==-1){b=hx(a,qx(64));c=a.indexOf('function ')==0?9:0}b!=-1&&(d=mx(a.substr(c,b-c)));return d.length>0?d:AC}
function Kb(b){Ib();var c=b.replace(/[\xad\u0600-\u0603\u06dd\u070f\u17b4\u17b5\u200b-\u200f\u2028-\u202e\u2060-\u2064\u206a-\u206f\ufeff\ufff9-\ufffb]/g,function(a){return Jb(a)});return c}
function Tp(a){var b,c;Rp.call(this,a.g);this.d=new aA;this.e=a.e;this.f=a.f;this.g=a.g;this.i=a.i;this.j=a.j;this.k=a.k;this.p=a.p;this.q=a.q;c=a.n.c;for(b=0;b<c;++b){Tz(this.n,Wz(a.n,b))}}
function Vm(a){if(!a.c){a.c=td($doc,a.b);if(!a.c){throw new rb('Cannot find element with id "'+a.b+'". Perhaps it is not attached to the document body.')}a.c.removeAttribute('id')}return a.c}
function Bv(a){var b,c,d,e,f,g;d=Im();if(d){f=new Of;for(b=0;b<a.c.b.g.rb();++b){e=nh(au(a.c.b,b),37);c=new Ag;yg(c,OD,new Ug(e.d));yg(c,PD,(Zf(),e.b?Yf:Xf));g=Lf(f,b);Mf(f,b,c)}Gm(d,Nf(f))}}
function df(b,c){var a,d,e;!c.i||(c.i=false,c.j=null);e=c.j;oe(c,b.c);try{mf(b.b,c)}catch(a){a=rl(a);if(ph(a,36)){d=a;throw new Bf(d.b)}else throw a}finally{e==null?(c.i=true,c.j=null):(c.j=e)}}
function Mv(){this.j=new Yo(new mv);En(this,Wv(new Xv(this)));Vn(this.j,(fq(),dq));this.d.id='main';this.b.v.id='clear-completed';this.g.v.id='new-todo';this.i.id='footer';this.k.id='toggle-all'}
function mp(a,b,c){var d;d=new Hx;d.b.b+='<div onclick="" __idx="';Gx(d,xm(uC+a));d.b.b+='" class="';Gx(d,xm(b));d.b.b+='" style="outline:none;" >';Gx(d,c.b);d.b.b+='<\/div>';return new fm(d.b.b)}
function zz(a,b,c){this.d=a;this.b=b;this.c=c-b;if(b>c){throw new Cw(SD+b+' > toIndex: '+c)}if(b<0){throw new Iw(SD+b+' < 0')}if(c>a.rb()){throw new Iw('toIndex: '+c+' > wrapped.size() '+a.rb())}}
function Eo(a,b,c){var d,e,f,g;if(!c){return}d=0;for(g=c.bb();g.db();){f=nh(g.eb(),1);e=Vq(f);if(e<0){yq(b.v,f)}else{e=Io(a,b,f);e>0&&(d|=e)}}d>0&&(b.s==-1?zq(b.v,d|(b.v.__eventBits||0)):(b.s|=d))}
function qx(a){var b,c;if(a>=65536){b=55296+(~~(a-65536)>>10&1023)&65535;c=56320+(a-65536&1023)&65535;return String.fromCharCode(b)+String.fromCharCode(c)}else{return String.fromCharCode(a&65535)}}
function eo(a,b,c){var d,e,f,g,h;d=a.childNodes.length;h=null;c<d&&(h=a.childNodes[c]);e=b.childNodes.length;for(f=0;f<e;++f){if(!h){_c(a,b.childNodes[0])}else{g=md(h);ed(a,b.childNodes[0],h);h=g}}}
function Zn(a){var b;En(this,a);this.o=new Hp(this,new vo(this));b=new CB;zB(b,aD);zB(b,bD);zB(b,cD);zB(b,KC);zB(b,JC);zB(b,dD);Eo((!Co&&(Co=new Mo),Co),this,b);Mn(this,new Qt);Un(this,new lo(this))}
function wx(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)))|0;c+=4}while(c<d){b=b*31+fx(a,c++)}return b|0}
function fh(a,b,c){if(c!=null){if(a.qI>0&&!mh(c,a.qI)){throw new bw}else if(a.qI==-1&&(c.tM==TB||lh(c,1))){throw new bw}else if(a.qI<-1&&!(c.tM!=TB&&!lh(c,1))&&!mh(c,-a.qI)){throw new bw}}return a[b]=c}
function my(j,a,b,c){var d=j.b[c];if(d){for(var e=0,f=d.length;e<f;++e){var g=d[e];var h=g.yb();if(j.xb(a,h)){var i=g.zb();g.Ab(b);return i}}}else{d=j.b[c]=[]}var g=new MB(a,b);d.push(g);++j.e;return null}
function Lb(b){Ib();var c=b.replace(/[\x00-\x1f\xad\u0600-\u0603\u06dd\u070f\u17b4\u17b5\u200b-\u200f\u2028-\u202e\u2060-\u2064\u206a-\u206f\ufeff\ufff9-\ufffb"\\]/g,function(a){return Jb(a)});return zC+c+zC}
function pt(a,b,c){var d,e;if(c<0||c>a.d){throw new Hw}if(a.d==a.b.length){e=dh(ll,XB,30,a.b.length*2,0);for(d=0;d<a.b.length;++d){fh(e,d,a.b[d])}a.b=e}++a.d;for(d=a.d-1;d>c;--d){fh(a.b,d,a.b[d-1])}fh(a.b,c,b)}
function Mo(){this.c=new CB;zB(this.c,'select');zB(this.c,'input');zB(this.c,'textarea');zB(this.c,'option');zB(this.c,hD);zB(this.c,'label');this.b=new CB;zB(this.b,aD);zB(this.b,bD);zB(this.b,iD);zB(this.b,jD)}
function Kl(a,b){var c,d,e;b&=63;if(b<22){c=a.l<<b;d=a.m<<b|~~a.l>>22-b;e=a.h<<b|~~a.m>>22-b}else if(b<44){c=0;d=a.l<<b-22;e=a.m<<b-22|~~a.l>>44-b}else{c=0;d=0;e=a.l<<b-44}return vl(c&4194303,d&4194303,e&1048575)}
function $l(a,b,c){var d=Zl[a];if(d&&!d.cZ){_=d.prototype}else{!d&&(d=Zl[a]=function(){});_=d.prototype=b<0?{}:_l(b);_.cM=c}for(var e=3;e<arguments.length;++e){arguments[e].prototype=_}if(d.cZ){_.cZ=d.cZ;d.cZ=null}}
function Mg(a){if(!a){return ig(),hg}var b=a.valueOf?a.valueOf():a;if(b!==a){var c=Ig[typeof b];return c?c(b):Sg(typeof b)}else if(a instanceof Array||a instanceof $wnd.Array){return new Pf(a)}else{return new Bg(a)}}
function Vo(a,b,c,d){var e,f,g,h,i,j;up(a.o)+xp(a.o).c;i=c.rb();g=d+i;for(h=d;h<g;++h){j=c.kb(h-d);f=new Hx;Zc(f.b,h%2==0?'GPBYFDEAB':'GPBYFDECB');e=new lm;new gb(h,a.o);kv(a.b,j,e);km(b,mp(h,f.b.b,new nm(e.b.b.b)))}}
function Af(a){var b,c,d,e,f;c=a.rb();if(c==0){return null}b=new Ix(c==1?'Exception caught: ':c+' exceptions caught: ');d=true;for(f=a.bb();f.db();){e=nh(f.eb(),52);d?(d=false):(b.b.b+='; ',b);Gx(b,e.w())}return b.b.b}
function kn(a,b,c){if(!a){throw new rb('Null widget handle. If you are creating a composite, ensure that initWidget() has been called.')}b=mx(b);if(b.length==0){throw new Cw('Style names cannot be empty')}c?gd(a,b):id(a,b)}
function zv(b){var a,c,d,e,f,g,h,i;g=Im();if(g){try{f=Lm(g.b,YC);i=(Jg(),Qg(f)).J();for(d=0;d<i.b.length;++d){e=Lf(i,d).L();h=wg(e,OD).M().b;c=wg(e,PD).K().b;Xt(b.c.b,new tv(h,c,b))}}catch(a){a=rl(a);if(!ph(a,46))throw a}}}
function Zr(a){if(a.d){a.b.style[DD]=CD;ln(a.b,true);ln(a.c,false);a.c.style[DD]=CD}else{ln(a.b,false);a.b.style[DD]=CD;a.c.style[DD]=CD;ln(a.c,true)}a.b.style[FD]=GD;a.c.style[FD]=GD;a.b=null;a.c=null;gn(a.e,false);a.e=null}
function cs(a,b,c){var d,e,f;if(c==b.v){return}sn(b);f=null;d=new xt(a.c);while(d.b<d.c.d-1){e=vt(d);if(od(c,e.v)){if(e.v==c){f=e;break}wt(d)}}mt(a.c,b);if(!f){ed(c.parentNode,b.v,c)}else{cd(c.parentNode,b.v,c);sr(a,f)}tn(b,a)}
function xm(a){wm();a.indexOf(TC)!=-1&&(a=bm(rm,a,'&amp;'));a.indexOf(WC)!=-1&&(a=bm(tm,a,'&lt;'));a.indexOf(VC)!=-1&&(a=bm(sm,a,'&gt;'));a.indexOf(zC)!=-1&&(a=bm(um,a,'&quot;'));a.indexOf(XC)!=-1&&(a=bm(vm,a,'&#39;'));return a}
function qn(a){var b;if(a.R()){throw new Fw("Should only call onAttach when the widget is detached from the browser's document")}a.r=true;Xq(a.v,a);b=a.s;a.s=-1;b>0&&(a.s==-1?hr(a.v,b|(a.v.__eventBits||0)):(a.s|=b));a.P();a.V()}
function Ml(a,b){var c,d,e,f;b&=63;c=a.h&1048575;if(b<22){f=~~c>>>b;e=~~a.m>>b|c<<22-b;d=~~a.l>>b|a.m<<22-b}else if(b<44){f=0;e=~~c>>>b-22;d=~~a.m>>b-22|a.h<<44-b}else{f=0;e=0;d=~~c>>>b-44}return vl(d&4194303,e&4194303,f&1048575)}
function Ll(a,b){var c,d,e,f,g;b&=63;c=a.h;d=(c&524288)!=0;d&&(c|=-1048576);if(b<22){g=~~c>>b;f=~~a.m>>b|c<<22-b;e=~~a.l>>b|a.m<<22-b}else if(b<44){g=d?1048575:0;f=~~c>>b-22;e=~~a.m>>b-22|c<<44-b}else{g=d?1048575:0;f=d?4194303:0;e=~~c>>b-44}return vl(e&4194303,f&4194303,g&1048575)}
function Xv(a){this.q=a;this.p=sd($doc);this.b=sd($doc);this.d=sd($doc);this.e=sd($doc);this.f=sd($doc);this.i=sd($doc);this.j=sd($doc);this.k=sd($doc);this.n=sd($doc);this.c=new Wm(this.b);this.g=new Wm(this.f);this.o=new Wm(this.n)}
function ov(a,b,c,d){var e;e=new Hx;e.b.b+="<div class='";Gx(e,xm(c));e.b.b+="' data-timestamp='";Gx(e,xm(d));e.b.b+="'>";Gx(e,a.b);e.b.b+=' <label>';Gx(e,b.b);e.b.b+="<\/label><button class='destroy'><\/a><\/div>";return new fm(e.b.b)}
function Dt(a,b){var c;if(!b){throw new Cw('display cannot be null')}else if(AB(a.c,b)){throw new Fw('The specified display has already been added to this adapter.')}zB(a.c,b);c=Nn(b,new It(a,b));ly(a.f,b,c);a.d>=0&&Wn(b,a.d,a.e);Tt(a,b)}
function gd(a,b){var c,d,e,f;b=mx(b);f=a.className;c=f.indexOf(b);while(c!=-1){if(c==0||f.charCodeAt(c-1)==32){d=c+b.length;e=f.length;if(d==e||d<e&&f.charCodeAt(d)==32){break}}c=f.indexOf(b,c+1)}if(c==-1){f.length>0&&(f+=HC);a.className=f+b}}
function Nw(a){var b,c,d;if(a<0){return 0}else if(a==0){return 32}else{d=-(~~a>>16);b=~~d>>16&16;c=16-b;a=~~a>>b;d=a-256;b=~~d>>16&8;c+=b;a<<=b;d=a-4096;b=~~d>>16&4;c+=b;a<<=b;d=a-16384;b=~~d>>16&2;c+=b;a<<=b;d=~~a>>14;b=d&~(~~d>>1);return c+2-b}}
function $r(a,b,c){var d,e,f,g;V(a);d=nd(c.v);e=dr(nd(d),d);if(!b){ln(d,true);ln(c.v,true);return}a.e=b;f=nd(b.v);g=dr(nd(f),f);if(e>g){a.b=f;a.c=d;a.d=false}else{a.b=d;a.c=f;a.d=true}ln(a.b,a.d);ln(a.c,!a.d);a.b=null;a.c=null;gn(a.e,false);a.e=null;ln(c.v,true)}
function Dl(a){var b,c,d;c=a.l;if((c&c-1)!=0){return -1}d=a.m;if((d&d-1)!=0){return -1}b=a.h;if((b&b-1)!=0){return -1}if(b==0&&d==0&&c==0){return -1}if(b==0&&d==0&&c!=0){return Ow(c)}if(b==0&&d!=0&&c==0){return Ow(d)+22}if(b!=0&&d==0&&c==0){return Ow(b)+44}return -1}
function Vd(){Ud();var a,b,c;c=null;if(Td.length!=0){a=Td.join(uC);b=fe((be(),ae),a);!Td&&(c=b);Td.length=0}if(Rd.length!=0){a=Rd.join(uC);b=ee((be(),ae),a);!Rd&&(c=b);Rd.length=0}if(Sd.length!=0){a=Sd.join(uC);b=ee((be(),ae),a);!Sd&&(c=b);Sd.length=0}Qd=false;return c}
function kc(a){var b,c,d,e,f,g;d=a.length;if(d==0){return null}b=false;f=hb();while(hb()-f<100){for(c=0;c<d;++c){g=a[c];if(!g){continue}if(!g[0].x()){a[c]=null;b=true}}}if(b){e=[];for(c=0;c<d;++c){!!a[c]&&(e[e.length]=a[c],undefined)}return e.length==0?null:e}else{return a}}
function ww(a){var b,c,d,e;if(a==null){throw new ax(vC)}c=a.length;d=c>0&&a.charCodeAt(0)==45?1:0;for(b=d;b<c;++b){if(iw(a.charCodeAt(b))==-1){throw new ax(QD+a+zC)}}e=parseInt(a,10);if(isNaN(e)){throw new ax(QD+a+zC)}else if(e<-2147483648||e>2147483647){throw new ax(QD+a+zC)}return e}
function Pc(a){var b,c,d,e,f,g,h,i,j;j=dh(ol,XB,51,a.length,0);for(e=0,f=j.length;e<f;++e){i=kx(a[e],CC,0);b=-1;d=DC;if(i.length==2&&i[1]!=null){h=i[1];g=ix(h,qx(58));c=jx(h,qx(58),g-1);d=h.substr(0,c-0);if(g!=-1&&c!=-1){vc(h.substr(c+1,g-(c+1)));b=vc(lx(h,g+1))}}j[e]=new cx(i[0],d+sC+b)}mb(j)}
function Ur(a,b){var c,d,e;c=(d=$doc.createElement(ZC),d.style[BD]=CD,d.style[DD]=ED,d.style['padding']=ED,d.style['margin']=ED,d);wq(a.v,c);pr(a,b,c);ln(c,false);c.style[DD]=CD;e=b.v;gx(e.style[BD],uC)&&(b.v.style[BD]=CD,undefined);gx(e.style[DD],uC)&&(b.v.style[DD]=CD,undefined);ln(b.v,false)}
function js(){var c=function(){};c.prototype={className:uC,clientHeight:0,clientWidth:0,dir:uC,getAttribute:function(a,b){return this[a]},href:uC,id:uC,lang:uC,nodeType:1,removeAttribute:function(a,b){this[a]=undefined},setAttribute:function(a,b){this[a]=b},src:uC,style:{},title:uC};$wnd.GwtPotentialElementShim=c}
function id(a,b){var c,d,e,f,g,h,i;b=mx(b);i=a.className;e=i.indexOf(b);while(e!=-1){if(e==0||i.charCodeAt(e-1)==32){f=e+b.length;g=i.length;if(f==g||f<g&&i.charCodeAt(f)==32){break}}e=i.indexOf(b,e+1)}if(e!=-1){c=mx(i.substr(0,e-0));d=mx(lx(i,e+b.length));c.length==0?(h=d):d.length==0?(h=c):(h=c+HC+d);a.className=h}}
function mf(b,c){var a,d,e,f,g,h;if(!c){throw new Yw('Cannot fire null event')}try{++b.c;g=pf(b,c.E());d=null;h=b.d?g.ob(g.rb()):g.nb();while(b.d?h.ub():h.db()){f=b.d?h.vb():h.eb();try{c.D(nh(f,10))}catch(a){a=rl(a);if(ph(a,52)){e=a;!d&&(d=new CB);zB(d,e)}else throw a}}if(d){throw new yf(d)}}finally{--b.c;b.c==0&&rf(b)}}
function Hl(a){var b,c,d,e,f;if(isNaN(a)){return Vl(),Ul}if(a<-9223372036854775808){return Vl(),Sl}if(a>=9223372036854775807){return Vl(),Rl}e=false;if(a<0){e=true;a=-a}d=0;if(a>=17592186044416){d=th(a/17592186044416);a-=d*17592186044416}c=0;if(a>=4194304){c=th(a/4194304);a-=c*4194304}b=th(a);f=vl(b,c,d);e&&Bl(f);return f}
function ip(a){if(!a.b){a.b=true;Ud();Wd('.GPBYFDEAB,.GPBYFDECB{cursor:pointer;zoom:1;}.GPBYFDEBB{background:#ffc;}.GPBYFDEDB{height:'+(kp(),ep.b)+'px;overflow:hidden;background:url("'+ep.e.b+'") -'+ep.c+'px -'+ep.d+'px  repeat-x;background-color:#628cd5;color:white;height:auto;overflow:visible;}');return true}return false}
function Pl(a){var b,c,d,e,f;if(a.l==0&&a.m==0&&a.h==0){return RC}if(a.h==524288&&a.m==0&&a.l==0){return '-9223372036854775808'}if(~~a.h>>19!=0){return '-'+Pl(Jl(a))}c=a;d=uC;while(!(c.l==0&&c.m==0&&c.h==0)){e=Il(1000000000);c=wl(c,e,true);b=uC+Ol(sl);if(!(c.l==0&&c.m==0&&c.h==0)){f=9-b.length;for(;f>0;--f){b=RC+b}}d=b+d}return d}
function So(a,b){var c,d,e,f,g,h,i,j,k,l,m;e=rd(b);if(!ld(e)){return}l=rd(b);h=uC;c=l;while(!!c&&(h=c.getAttribute('__idx')||uC).length==0){c=nd(c)}if(h.length>0){f=b.type;gx(JC,f);g=ww(h);i=g-xp(a.o).c;if(!(i>=0&&i<tp(a.o).n.c)){return}j=(fq(),cq)==a.o.e;m=(On(a,i),vp(a.o,i));d=new gb(g,a.o);k=Nt(a,b,a,d,a.c,j);k.d||Po(a,b,c,m)}}
function Pg(b,c){var d;if(c&&(Ib(),Hb)){try{d=JSON.parse(b)}catch(a){return Rg(PC+a)}}else{if(c){if(!(Ib(),!/[^,:{}\[\]0-9.\-+Eaeflnr-u \n\r\t]/.test(b.replace(/"(\\.|[^"\\])*"/g,uC)))){return Rg('Illegal character in JSON string')}}b=Kb(b);try{d=eval(xC+b+GC)}catch(a){return Rg(PC+a)}}var e=Ig[typeof d];return e?e(d):Sg(typeof d)}
function Zo(a){var b;Yn.call(this,$doc.createElement(ZC));wm();new nm(uC);this.e=new Fs;this.f=new Fs;this.g=new Wr;this.b=a;this.i=(lp(),fp);ip(this.i);kn(this.v,'GPBYFDEEB',true);this.d=$doc.createElement(ZC);b=this.v;_c(b,this.d);_c(b,this.g.v);this.g.X(this);Ur(this.g,this.e);Ur(this.g,this.f);Eo((!Co&&(Co=new Mo),Co),this,a.d)}
function jv(a,b,c){var d,e,f;if(a.c==b){d=nv(b.d);Gx(c.b,d.b)}else{d=ov(b.b?(e=new Hx,e.b.b+="<input class='toggle' type='checkbox' checked>",new fm(e.b.b)):(f=new Hx,f.b.b+="<input class='toggle' type='checkbox'>",new fm(f.b.b)),(wm(),new nm(xm(b.d))),b.b?'listItem view done':'listItem view',uC+Pl(Hl((new mB).b.getTime())));Gx(c.b,d.b)}}
function jr(){var d=$wnd.onbeforeunload;var e=$wnd.onunload;$wnd.onbeforeunload=function(a){var b,c;try{b=rC(Lq)()}finally{c=d&&d(a)}if(b!=null){return b}if(c!=null){return c}};$wnd.onunload=rC(function(a){try{Gq&&Xe((!Hq&&(Hq=new Tq),Hq))}finally{e&&e(a);$wnd.onresize=null;$wnd.onscroll=null;$wnd.onbeforeunload=null;$wnd.onunload=null}})}
function qp(a,b,c){var d,e,f,g,h,i,j,k,l,m,n;Lp(a);l=-1;h=-1;m=-1;i=-1;g=0;for(e=0;e<a.length;++e){f=a[e];if(f<b||f>=c){continue}else if(l==-1){l=f;h=f}else if(m==-1){g=f-h;m=f;i=f}else{d=f-i;if(d>g){h=i;m=f;i=f;g=d}else{i=f}}}h+=1;i+=1;if(m==h){h=i;m=-1;i=-1}n=new aA;if(l!=-1){j=h-l;Tz(n,new Ku(l,j))}if(m!=-1){k=i-m;Tz(n,new Ku(m,k))}return n}
function Ep(a,b,c){var d,e,f,g,h,i,j,k,l,m,n;n=c.rb();m=b+n;j=(!a.f?a.j:a.f).i;i=(!a.f?a.j:a.f).i+(!a.f?a.j:a.f).g;e=b>j?b:j;d=m<i?m:i;if(b!=j&&e>=d){return}k=rp(a);f=Uw(0,e-j-(!a.f?a.j:a.f).n.c);for(h=0;h<f;++h){Tz(k.n,null)}for(h=e;h<d;++h){l=c.kb(h-b);g=h-j;g<(!a.f?a.j:a.f).n.c?$z(k.n,g,l):Tz(k.n,l)}Tz(k.d,new Ku(e-f,d-(e-f)));m>(!a.f?a.j:a.f).j&&Dp(a,m,(!a.f?a.j:a.f).k)}
function zl(a,b,c,d,e,f){var g,h,i,j,k,l,m;j=Cl(b)-Cl(a);g=Kl(b,j);i=vl(0,0,0);while(j>=0){h=El(a,g);if(h){j<22?(i.l|=1<<j,undefined):j<44?(i.m|=1<<j-22,undefined):(i.h|=1<<j-44,undefined);if(a.l==0&&a.m==0&&a.h==0){break}}k=g.m;l=g.h;m=g.l;g.h=~~l>>>1;g.m=~~k>>>1|(l&1)<<21;g.l=~~m>>>1|(k&1)<<21;--j}c&&Bl(i);if(f){if(d){sl=Jl(a);e&&(sl=Nl(sl,(Vl(),Tl)))}else{sl=vl(a.l,a.m,a.h)}}return i}
function hv(a,b,c,d){var e,f,g,h,i,j;j=d.type;if(a.c==c){if(gx(KC,j)){h=d.keyCode||0;if(h==13){fv(b,c);a.c=null;lv(a,b,c)}h==27&&(a.c=null,lv(a,b,c))}if(gx(bD,j)&&!a.b){fv(b,c);a.c=null;lv(a,b,c)}}else{if(gx(lD,j)){a.c=c;lv(a,b,c);a.b=true;g=bd(b.firstChild);g.focus();a.b=false}if(gx(JC,j)){f=rd(d);e=f;i=e.tagName;if(gx(i,LD)){g=e;qv(c,!!g.checked);g.checked?gd(b.firstChild,MD):id(b.firstChild,MD)}else gx(i,zD)&&xv(c.c,c)}}}
function ql(){var a,b;!!$stats&&am('com.google.gwt.useragent.client.UserAgentAsserter');a=Bt();gx(QC,a)||($wnd.alert('ERROR: Possible problem with your *.gwt.xml module file.\nThe compile time user.agent value (safari) does not match the runtime user.agent value ('+a+'). Expect more errors.\n'),undefined);!!$stats&&am('com.google.gwt.user.client.DocumentModeAsserter');Aq();!!$stats&&am('com.todo.client.GwtToDo');b=new Mv;new Dv(b);wr((ps(),ts()),b)}
function gr(a,b){switch(b){case 'drag':a.ondrag=br;break;case 'dragend':a.ondragend=br;break;case 'dragenter':a.ondragenter=ar;break;case 'dragleave':a.ondragleave=br;break;case 'dragover':a.ondragover=ar;break;case 'dragstart':a.ondragstart=br;break;case 'drop':a.ondrop=br;break;case 'canplaythrough':case 'ended':case 'progress':a.removeEventListener(b,br,false);a.addEventListener(b,br,false);break;default:throw 'Trying to sink unknown event type '+b;}}
function kx(l,a,b){var c=new RegExp(a,UC);var d=[];var e=0;var f=l;var g=null;while(true){var h=c.exec(f);if(h==null||f==uC||e==b-1&&b>0){d[e]=f;break}else{d[e]=f.substring(0,h.index);f=f.substring(h.index+h[0].length,f.length);c.lastIndex=0;if(g==f){d[e]=f.substring(0,1);f=f.substring(1)}g=f;e++}}if(b==0&&l.length>0){var i=d.length;while(i>0&&d[i-1]==uC){--i}i<d.length&&d.splice(i,d.length-i)}var j=nx(d.length);for(var k=0;k<d.length;++k){j[k]=d[k]}return j}
function Wv(a){var b,c,d,e,f,g,h,i,j,k,l;c=new ds(Zv(a.b,a.d,a.e,a.f,a.i,a.j,a.k,a.n).b);b=Ym(c.v);Vm(a.c);d=Vm(new Wm(a.d));a.q.d=d;e=Vm(new Wm(a.e));a.q.k=e;Vm(a.g);f=Vm(new Wm(a.i));a.q.i=f;g=Vm(new Wm(a.j));a.q.e=g;h=Vm(new Wm(a.k));a.q.f=h;Vm(a.o);b.c?cd(b.c,b.b,b.d):$m(b.b);bs(c,(i=new dv,i.v.setAttribute('placeholder','What needs to be done?'),a.q.g=i,i),Vm(a.c));bs(c,a.q.j,Vm(a.g));bs(c,(j=new Rr,Pr(j,Yv(a.p).b),k=Ym(j.v),l=Vm(new Wm(a.p)),a.q.c=l,k.c?cd(k.c,k.b,k.d):$m(k.b),a.q.b=j,j),Vm(a.o));return c}
function Fp(a,b,c){var d,e,f,g,h,i,j,k,l,m;m=b.c;g=b.b;if(m<0){throw new Cw('Range start cannot be less than 0')}if(g<0){throw new Cw('Range length cannot be less than 0')}j=(!a.f?a.j:a.f).i;h=(!a.f?a.j:a.f).g;k=j!=m;if(k){l=rp(a);if(!c){if(m>j){f=m-j;if((!a.f?a.j:a.f).n.c>f){for(e=0;e<f;++e){Yz(l.n,0)}}else{Vz(l.n)}}else{d=j-m;if((!a.f?a.j:a.f).n.c>0&&d<h){for(e=0;e<d;++e){Sz(l.n,0,null)}Tz(l.d,new Ku(m,m+d-m))}else{Vz(l.n)}}}l.i=m}i=h!=g;i&&(rp(a).g=g);c&&Vz(rp(a).n);Gp(a);(k||i)&&Tu(a.b,new Ku((!a.f?a.j:a.f).i,(!a.f?a.j:a.f).g))}
function Bt(){var b=navigator.userAgent.toLowerCase();var c=function(a){return parseInt(a[1])*1000+parseInt(a[2])};if(function(){return b.indexOf(HD)!=-1}())return HD;if(function(){return b.indexOf('webkit')!=-1}())return QC;if(function(){return b.indexOf(ID)!=-1&&$doc.documentMode>=9}())return 'ie9';if(function(){return b.indexOf(ID)!=-1&&$doc.documentMode>=8}())return 'ie8';if(function(){var a=/msie ([0-9]+)\.([0-9]+)/.exec(b);if(a&&a.length==3)return c(a)>=6000}())return 'ie6';if(function(){return b.indexOf('gecko')!=-1}())return 'gecko1_8';return 'unknown'}
function Vq(a){switch(a){case bD:return 4096;case 'change':return 1024;case JC:return 1;case lD:return 2;case aD:return 2048;case cD:return 128;case mD:return 256;case KC:return 512;case iD:return 32768;case 'losecapture':return 8192;case dD:return 4;case nD:return 64;case oD:return 32;case pD:return 16;case qD:return 8;case 'scroll':return 16384;case jD:return 65536;case 'DOMMouseScroll':case rD:return 131072;case 'contextmenu':return 262144;case 'paste':return 524288;case sD:return 1048576;case tD:return 2097152;case uD:return 4194304;case vD:return 8388608;case wD:return 16777216;case xD:return 33554432;case yD:return 67108864;default:return -1;}}
function Bp(a,b,c,d){var e,f,g,h,i,j,k,l;if((fq(),dq)==a.e){return}a.d.b&&(b=Uw(0,Vw(b,(!a.f?a.j:a.f).n.c-1)));rp(a).q=true;if(!d&&(dq==a.e?-1:(!a.f?a.j:a.f).e)==b&&(dq==a.e?null:(!a.f?a.j:a.f).f)!=null){return}i=(!a.f?a.j:a.f).i;h=(!a.f?a.j:a.f).g;k=(!a.f?a.j:a.f).j;e=i+b;e>=k&&(!a.f?a.j:a.f).k&&(e=k-1);b=(0>e?0:e)-i;a.d.b&&(b=0>(b<h-1?b:h-1)?0:b<h-1?b:h-1);g=i;f=h;j=rp(a);j.e=0;j.f=null;j.b=true;if(b>=0&&b<h){j.e=b;j.f=b<j.n.c?Qp(rp(a),b):null;j.c=c;return}else if((Zp(),Wp)==a.d){while(b<0){l=h<g?h:g;g-=l;b+=l}while(b>=h){g+=h;b-=h}}else if(Yp==a.d){while(b<0){l=30<g?30:g;f+=l;g-=l;b+=l}while(b>=f){f+=30}if((!a.f?a.j:a.f).k){f=f<k-g?f:k-g;b>=k&&(b=k-1)}}if(g!=i||f!=h){j.e=b;Fp(a,new Ku(g,f),false)}}
function wl(a,b,c){var d,e,f,g,h,i,j,k;if(b.l==0&&b.m==0&&b.h==0){throw new _v}if(a.l==0&&a.m==0&&a.h==0){c&&(sl=vl(0,0,0));return vl(0,0,0)}if(b.h==524288&&b.m==0&&b.l==0){return xl(a,c)}i=false;if(~~b.h>>19!=0){b=Jl(b);i=true}g=Dl(b);f=false;e=false;d=false;if(a.h==524288&&a.m==0&&a.l==0){e=true;f=true;if(g==-1){a=ul((Vl(),Rl));d=true;i=!i}else{h=Ll(a,g);i&&Bl(h);c&&(sl=vl(0,0,0));return h}}else if(~~a.h>>19!=0){f=true;a=Jl(a);d=true;i=!i}if(g!=-1){return yl(a,g,i,f,c)}if(!(j=~~a.h>>19,k=~~b.h>>19,j==0?k!=0||a.h>b.h||a.h==b.h&&a.m>b.m||a.h==b.h&&a.m==b.m&&a.l>=b.l:!(k==0||a.h<b.h||a.h==b.h&&a.m<b.m||a.h==b.h&&a.m==b.m&&a.l<b.l))){c&&(f?(sl=Jl(a)):(sl=vl(a.l,a.m,a.h)));return vl(0,0,0)}return zl(d?a:vl(a.l,a.m,a.h),b,i,f,e,c)}
function Aq(){var a,b,c;b=$doc.compatMode;a=eh(pl,XB,1,[kD]);for(c=0;c<a.length;++c){if(gx(a[c],b)){return}}a.length==1&&gx(kD,a[0])&&gx('BackCompat',b)?"GWT no longer supports Quirks Mode (document.compatMode=' BackCompat').<br>Make sure your application's host HTML page has a Standards Mode (document.compatMode=' CSS1Compat') doctype,<br>e.g. by using &lt;!doctype html&gt; at the start of your application's HTML page.<br><br>To continue using this unsupported rendering mode and risk layout problems, suppress this message by adding<br>the following line to your*.gwt.xml module file:<br>&nbsp;&nbsp;&lt;extend-configuration-property name=\"document.compatMode\" value=\""+b+'"/&gt;':"Your *.gwt.xml module configuration prohibits the use of the current doucment rendering mode (document.compatMode=' "+b+"').<br>Modify your application's host HTML page doctype, or update your custom 'document.compatMode' configuration property settings."}
function Zv(a,b,c,d,e,f,g,h){var i;i=new Hx;i.b.b+="<section id='todoapp'> <header id='header'> <h1>todos<\/h1> <span id='";Gx(i,xm(a));i.b.b+="'><\/span> <\/header> <section id='";Gx(i,xm(b));i.b.b+="'> <input id='";Gx(i,xm(c));i.b.b+="' type='checkbox'> <label for='toggle-all'>Mark all as complete<\/label> <div id='todo-list'> <span id='";Gx(i,xm(d));i.b.b+="'><\/span> <\/div> <\/section> <footer id='";Gx(i,xm(e));i.b.b+="'> <span id='todo-count'> <strong class='number' id='";Gx(i,xm(f));i.b.b+="'><\/strong> <span class='word' id='";Gx(i,xm(g));i.b.b+="'><\/span> left <\/span> <span id='";Gx(i,xm(h));i.b.b+="'><\/span> <\/footer> <\/section> <footer id='info'> <p>Double-click to edit a todo<\/p> <p>Template by <a href='http://sindresorhus.com'>Sindre Sorhus<\/a><\/p> <p>Created by <a href='http://www.scottlogic.co.uk/blog/colin/'>Colin Eberhardt<\/a><\/p> <p>Part of <a href='http://todomvc.com'>TodoMVC<\/a><\/p> <\/footer>";return new fm(i.b.b)}
function er(){$q=rC(function(a){return true});br=rC(function(a){var b,c=this;while(c&&!(b=c.__listener)){c=c.parentNode}c&&c.nodeType!=1&&(c=null);b&&Yq(b)&&xq(a,c,b)});ar=rC(function(a){a.preventDefault();br.call(this,a)});cr=rC(function(a){this.__gwtLastUnhandledEvent=a.type;br.call(this,a)});_q=rC(function(a){var b=$q;if(b(a)){var c=Zq;if(c&&c.__listener){if(Yq(c.__listener)){xq(a,c,c.__listener);a.stopPropagation()}}}});$wnd.addEventListener(JC,_q,true);$wnd.addEventListener(lD,_q,true);$wnd.addEventListener(dD,_q,true);$wnd.addEventListener(qD,_q,true);$wnd.addEventListener(nD,_q,true);$wnd.addEventListener(pD,_q,true);$wnd.addEventListener(oD,_q,true);$wnd.addEventListener(rD,_q,true);$wnd.addEventListener(cD,$q,true);$wnd.addEventListener(KC,$q,true);$wnd.addEventListener(mD,$q,true);$wnd.addEventListener(sD,_q,true);$wnd.addEventListener(tD,_q,true);$wnd.addEventListener(uD,_q,true);$wnd.addEventListener(vD,_q,true);$wnd.addEventListener(wD,_q,true);$wnd.addEventListener(xD,_q,true);$wnd.addEventListener(yD,_q,true)}
function Ib(){var a;Ib=TB;Gb=(a=['\\u0000','\\u0001','\\u0002','\\u0003','\\u0004','\\u0005','\\u0006','\\u0007','\\b','\\t','\\n','\\u000B','\\f','\\r','\\u000E','\\u000F','\\u0010','\\u0011','\\u0012','\\u0013','\\u0014','\\u0015','\\u0016','\\u0017','\\u0018','\\u0019','\\u001A','\\u001B','\\u001C','\\u001D','\\u001E','\\u001F'],a[34]='\\"',a[92]='\\\\',a[173]='\\u00ad',a[1536]='\\u0600',a[1537]='\\u0601',a[1538]='\\u0602',a[1539]='\\u0603',a[1757]='\\u06dd',a[1807]='\\u070f',a[6068]='\\u17b4',a[6069]='\\u17b5',a[8203]='\\u200b',a[8204]='\\u200c',a[8205]='\\u200d',a[8206]='\\u200e',a[8207]='\\u200f',a[8232]='\\u2028',a[8233]='\\u2029',a[8234]='\\u202a',a[8235]='\\u202b',a[8236]='\\u202c',a[8237]='\\u202d',a[8238]='\\u202e',a[8288]='\\u2060',a[8289]='\\u2061',a[8290]='\\u2062',a[8291]='\\u2063',a[8292]='\\u2064',a[8298]='\\u206a',a[8299]='\\u206b',a[8300]='\\u206c',a[8301]='\\u206d',a[8302]='\\u206e',a[8303]='\\u206f',a[65279]='\\ufeff',a[65529]='\\ufff9',a[65530]='\\ufffa',a[65531]='\\ufffb',a);Hb=typeof JSON=='object'&&typeof JSON.parse==yC}
function ir(a,b){var c=(a.__eventBits||0)^b;a.__eventBits=b;if(!c)return;c&1&&(a.onclick=b&1?br:null);c&2&&(a.ondblclick=b&2?br:null);c&4&&(a.onmousedown=b&4?br:null);c&8&&(a.onmouseup=b&8?br:null);c&16&&(a.onmouseover=b&16?br:null);c&32&&(a.onmouseout=b&32?br:null);c&64&&(a.onmousemove=b&64?br:null);c&128&&(a.onkeydown=b&128?br:null);c&256&&(a.onkeypress=b&256?br:null);c&512&&(a.onkeyup=b&512?br:null);c&1024&&(a.onchange=b&1024?br:null);c&2048&&(a.onfocus=b&2048?br:null);c&4096&&(a.onblur=b&4096?br:null);c&8192&&(a.onlosecapture=b&8192?br:null);c&16384&&(a.onscroll=b&16384?br:null);c&32768&&(a.onload=b&32768?cr:null);c&65536&&(a.onerror=b&65536?br:null);c&131072&&(a.onmousewheel=b&131072?br:null);c&262144&&(a.oncontextmenu=b&262144?br:null);c&524288&&(a.onpaste=b&524288?br:null);c&1048576&&(a.ontouchstart=b&1048576?br:null);c&2097152&&(a.ontouchmove=b&2097152?br:null);c&4194304&&(a.ontouchend=b&4194304?br:null);c&8388608&&(a.ontouchcancel=b&8388608?br:null);c&16777216&&(a.ongesturestart=b&16777216?br:null);c&33554432&&(a.ongesturechange=b&33554432?br:null);c&67108864&&(a.ongestureend=b&67108864?br:null)}
function zp(b,c){var a,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O;b.g=null;if(b.c){return false}b.c=true;if(!b.f){b.c=false;b.i=0;return false}++b.i;if(b.i>10){b.c=false;b.i=0;throw new Fw('A possible infinite loop has been detected in a Cell Widget. This usually happens when your SelectionModel triggers a SelectionChangeEvent when SelectionModel.isSelection() is called, which causes the table to redraw continuously.')}t=b.j;l=b.f;b.j=b.f;b.f=null;!c&&(c=[]);y=l.i;x=l.g;w=y+x;K=l.n.c;l.e=Uw(0,Vw(l.e,K-1));if((fq(),dq)==b.e){l.e=0;l.f=null}else if(l.b){l.f=K>0?Qp(l,l.e):null}else if(l.f!=null){e=sp(l,l.f,l.e);if(e>=0){l.e=e;l.f=K>0?Qp(l,l.e):null}else{l.e=0;l.f=null}}try{if(cq==b.e&&false){u=t.p;m=K>0?Qp(l,l.e):null;if(m!=null){v=u!=null&&null.Db();n=m!=null&&null.Db();if(Cb(m,u)){n||(l.p=null)}else{v&&null.Db();l.p=m;m!=null&&!n&&null.Db()}}}}catch(a){a=rl(a);if(ph(a,50)){f=a;b.c=false;b.i=0;throw f}else throw a}h=l.b||t.e!=l.e||t.f==null&&l.f!=null;o=new CB;try{for(g=y;g<y+K;++g){Wz(l.n,g-y);M=AB(t.o,Rw(g));M&&Eb(c,g)}}catch(a){a=rl(a);if(ph(a,50)){f=a;b.c=false;b.i=0;throw f}else throw a}H=false;for(J=new qz(l.d);J.c<J.e.rb();){I=nh(oz(J),33);L=I.c;i=I.b;i==0&&(H=true);for(g=L;g<L+i;++g){Eb(c,g)}}if(c.length>0&&h){Eb(c,t.e);Eb(c,l.e)}if(b.f){b.c=false;b.f.p=l.p;b.f.o.hb(o);h&&(b.f.b=true);l.c&&(b.f.c=true);Eb(c,t.e);Eb(c,l.e);if(zp(b,c)){return true}}j=qp(c,y,w);B=j.c>0?nh((az(0,j.c),j.b[0]),33):null;C=j.c>1?nh((az(1,j.c),j.b[1]),33):null;F=0;for(A=new qz(j);A.c<A.e.rb();){z=nh(oz(A),33);F+=z.b}q=t.i;p=t.g;r=t.n.c;D=false;y!=q?(D=true):K<r?(D=true):!C&&!!B&&B.c==y&&(F>=r||F>p)?(D=true):F>=5&&F>0.3*r?(D=true):H&&r==0&&(D=true);N=(!b.f?b.j:b.f).n.c;O=(!b.f?b.j:b.f).k?Vw((!b.f?b.j:b.f).g,(!b.f?b.j:b.f).j-(!b.f?b.j:b.f).i):(!b.f?b.j:b.f).g;N>=O?uo(b.k,(tq(),qq)):N==0?uo(b.k,(tq(),rq)):uo(b.k,(tq(),sq));try{if(D){new lm;qo(b.k,l.n,l.c);so(b.k)}else if(B){d=B.c;E=d-y;new lm;G=new zz(l.n,E,E+B.b);ro(b.k,G,E,l.c);if(C){d=C.c;E=d-y;new lm;G=new zz(l.n,E,E+C.b);ro(b.k,G,E,l.c)}so(b.k)}else if(h){s=t.e;s>=0&&s<K&&to(b.k,s,false,false);k=l.e;k>=0&&k<K&&to(b.k,k,true,l.c)}}catch(a){a=rl(a);if(ph(a,45)){f=a;throw new tb(f)}else throw a}finally{b.c=false}zp(b,null);return true}
function zm(){this.b='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFIAAAAaCAYAAAAkJwuaAAAHt0lEQVR42u1SWVeURxD9fiqLuOFugp5ojjsuzMBIEDXHFSOKRIHI9kNmBgYERkHEhWQcQB47XWtX94xPyaMP91RX1a1bt76ZrG961/XNBPROf3N9syEvzMZ1jDO7jZhtfAMX52fNe4bnjY5oCjetx7rfIl+pXgHfpi+a3/M9sxvdlUboRd/A9MO3+uYySPLTO764wxHyUEv7eRbIa27n4mgRa3/Tt61Zrd7v1prvEG8Bu4nP5l56k3vi+3cbZuKdYW+Wn9rGJDdFwNwjN+nzyW2G9KS2RXFqSznam5IcdO17h3Lo465t5eent7QGnLzujd8KvxdnJsW7eOZcdCd3ON+Kenn0tMX7hC+3hzzcs0Mz0zsufK/taD678deWE/S85ncStc7vHunB+/V2qL+OZ+2cziO3Hmr+DRrxjnrQg9oEoB68mF7k2XqYYE+TW9Gc3qRekv5EvcGz6Ik+cet0B+/Jro1/ddfG6+7a2Fd3dbzmro4BfG0CcgJyJoBTw3jdA7gQsT5RYx7nfv46zGOsoxZwcNZzUB+44zXdQxzag/kYY7zOs7xvvB57klmuiXfSD36CvszVlX+dta5P1I1GTW+jnaQFPb1rvK6a2ZWX/zhAN+PKq5BDvPyy5rrHoO7jq6++ZnPiIP8VzNRofizUr1iO/yG6hQtvbwj7jMvIYbykfd3pXtSuEUCHfZCn4EU0YY/W/b7ul7RHvHVHHmuhZ/Ox+I7L9nuNkW528c+/HeASQ94XRzfNO/QuvKA61GyfdDZDfTTWDJx0T8ClRM/2I51R2nVJdtr3qKlFvKAf8s34vlG6O3DiWXtjWs/OPf/izo8APjt6QxSE/PzIZoD/mOe5h32OCJmF94vPxB2hSDrw/oI6oK/cEbtzE2vnrDZrnROvii+860vQey75Z90pPNl3AfojPDMSe470Rqzm58B9Hr4LxOzs8Ib79dlHd/YpwL+HP3lw7t9Qk/rZpwTo//qMefCG3jDNgx7MYp915Q2RND+aHfQ+gzs+sk7wgH6esY9kBv2g30/sgeIZ2Tn8KdyA7w2e4ZuHrR/pi3/7DT6qBt3CO58xz89lv/zxwUV4AnGDcxOfbHBu37Zn+Jp/CPnQh+/MmRrsHvrQqIWwPesN6nZ/sju9I+pvNJ95Ym568r25eEd2+vG663q05iCe8vHUo/fu1OP3PodoahAfvw/QmXXiD9GMBXKGZIbnI33hroca6q0HP6LNOKX8ddXA95B49L0h63eNdsgs6qyrjvod4nutrvX/iHDafgP0SLzs5werruvBmoNI8O+HnD9cDW/be8i9ByF2ab4WuDrXRCvdYfUeyvya0VnDHxz2dKlHyJtoPmjij+fphtRP7FVvifyYHU362Yl779xJhr7vx2/bOyHv+6s6d/LeqrM6kFtu1MM54Nv5dw3z0v/p/qrRWdW9J4y3Ru3GnannhrsjzmoTT83uDsiO//7WHUOsYDyuWHHUq5pawDGN0K/ifGN8m2iI5kqkGzSqTfYEvWMY35pceFXjZ8XMV6P+MVOLb61GIB8riZ9q5DXdmR25u+KO3Fl2RyF6HGUcubvsUcUevEO9yvwq5XeYyzziVpFHMxKXmVtVrbDTzi4bP5QrF3esqJ76kf3sK3jmaG6wUd/Jjek+ywt3xPzs0O0ld/j2sseSOzS4RBGxrPnhO1SLOIPEOaxYatDAOdFgPYFy73CPIfvCrPEBGIz3HG7iy9ZTNOvbWoO/iLNsbo/7WefAkjs48MbDx1tv8N3pYydE7S26zkGOt0IfZjpvEUf6pLFI87eoTjNmtgFL+qb9S6zdfDbsXWRPcBTvh96g+It9H5R52WfvEx8DokteSPeN8lQD30v6zg70LzrEbws+VtyBAckJ+/sXqOb78MYcepY3wLM+3w86zIX8YKS3EGsjt8KaMAMaC2RSdjP29y+qjwP9wQvpV0iLtaGGWrITovhGVPQGuU/84g2gx98ixAXaIVzR5Vq272bF7bu54Ch6wADEgtTn/Zujx94CcahWCX2o3ZS6iczBOdlxM5n12FuY93tlXyXe15AzV/b2Bz2sS834JlR4hjzs1zl7Z/I9NLee502P3tnevorr6Jtzez06+sAovQnzoe7RwYCj4SCcK8xznMMYtLhWEP689mhHhXXNnNeUumgjZKYwr57En3juKMzpXOSrr2JusHeae4xv2iP3JP1C4GjO3yHb01t2e3rn3J48oQPeHu15rktPOfNab5e65Zh6u9eWt+jG3HLzmDdIZtqtT9vvDXvakxrw2u18bznqx3eU49t7E/9NdgKytlwJhdryJRRoYyGKvp7jCDXmtkvPz1C9zLVy1Fee7MiBru0DShrbolo54ZWNz7moT/vjOu0qNfHEu5Jbgl56j62V1FuqncGHaPWk1p6SRxEXUIR6CQdac0X+YEWqCfiDIz9f5FjmXhF1IdIHL9EO0OgpkT7zW3NsLldkfpk5MiMeJC/r7jbxxse28gfEOnsUDZzP0w1yI91S1D9FvK+sd6AfuU3vK+l9mRzWeqOoH1MPjmpF1yJ5rqQf1H4c5OeKmhNfNIJB1WQd4bXYfTnObxgt2cdaLT3F2K/Z0ZJ4aeX5lh6pWz/El5nYR7JLZsUb9zM19gP/CT8+5P+EfwFEPZjKzXkk0QAAAABJRU5ErkJggg=='}
var uC='',HC=' ',zC='"',TC='&',XC="'",xC='(',GC=')',LC=',',NC=', ',KD=', Size: ',RC='0',ED='0px',CD='100%',BC=':',tC=': ',WC='<',RD='=',VC='>',sC='@',CC='@@',zD='BUTTON',kD='CSS1Compat',PC='Error parsing JSON: ',QD='For input string: "',eD='GPBYFDEBB',LD='INPUT',JD='Index: ',wC='String',$D='UmbrellaException',DC='Unknown',EC='[',dE='[Lcom.google.gwt.user.cellview.client.',fE='[Lcom.google.gwt.user.client.ui.',VD='[Ljava.lang.',FC=']',gD='__gwtCellBasedWidgetImplDispatching',AC='anonymous',bD='blur',hD='button',AD='className',JC='click',mE='com.google.gwt.animation.client.',hE='com.google.gwt.cell.client.',UD='com.google.gwt.core.client.',aE='com.google.gwt.core.client.impl.',pE='com.google.gwt.dom.client.',kE='com.google.gwt.event.dom.client.',cE='com.google.gwt.event.logical.shared.',_D='com.google.gwt.event.shared.',jE='com.google.gwt.json.client.',WD='com.google.gwt.lang.',nE='com.google.gwt.safehtml.shared.',iE='com.google.gwt.storage.client.',qE='com.google.gwt.text.shared.testing.',oE='com.google.gwt.uibinder.client.',bE='com.google.gwt.user.cellview.client.',lE='com.google.gwt.user.client.',XD='com.google.gwt.user.client.ui.',eE='com.google.gwt.view.client.',ZD='com.google.web.bindery.event.shared.',YD='com.todo.client.',PD='complete',lD='dblclick',_C='display',ZC='div',MD='done',jD='error',aD='focus',SD='fromIndex: ',yC='function',UC='g',xD='gesturechange',yD='gestureend',wD='gesturestart',DD='height',SC='html is null',TD='java.lang.',gE='java.util.',cD='keydown',mD='keypress',KC='keyup',iD='load',dD='mousedown',nD='mousemove',oD='mouseout',pD='mouseover',qD='mouseup',rD='mousewheel',ID='msie',$C='none',vC='null',HD='opera',FD='overflow',QC='safari',IC='style',OD='task',YC='todo-gwt',vD='touchcancel',uD='touchend',tD='touchmove',sD='touchstart',fD='true',ND='value',GD='visible',BD='width',MC='{',OC='}';var _,Zl={},dC={9:1,11:1,22:1,23:1,25:1,26:1,28:1,30:1},mC={41:1},lC={35:1},cC={9:1,11:1,22:1,23:1,26:1,28:1,30:1},nC={56:1},jC={29:1,39:1,42:1,44:1},WB={},aC={7:1,10:1},kC={55:1},eC={9:1,11:1,22:1,23:1,25:1,26:1,28:1,30:1,32:1},$B={11:1},qC={39:1,55:1},iC={9:1,11:1,22:1,23:1,24:1,26:1,27:1,28:1,30:1},oC={58:1},hC={9:1,11:1,22:1,23:1,24:1,26:1,28:1,30:1},bC={17:1,39:1},fC={10:1,31:1},gC={8:1,10:1},YB={39:1,46:1,50:1,52:1},pC={57:1},XB={39:1},ZB={3:1,4:1,39:1,42:1,44:1},_B={36:1,39:1,46:1,50:1,52:1};$l(1,-1,WB);_.eQ=function R(a){return this===a};_.gC=function S(){return this.cZ};_.hC=function T(){return Wb(this)};_.tS=function U(){return this.cZ.d+sC+Pw(this.hC())};_.toString=function(){return this.tS()};_.tM=TB;$l(3,1,{});_.f=false;_.g=false;_.i=false;$l(4,1,{});$l(5,4,{});$l(6,5,{},ab);$l(7,5,{},cb);$l(8,1,{});_.d=null;$l(9,1,{},gb);_.b=0;$l(15,1,{39:1,52:1});_.w=function ob(){return this.f};_.tS=function pb(){return nb(this)};_.f=null;$l(14,15,{39:1,46:1,52:1});$l(13,14,YB,rb,tb);$l(12,13,{2:1,39:1,46:1,50:1,52:1},ub);_.w=function Ab(){this.d==null&&(this.e=xb(this.c),this.b=this.b+tC+vb(this.c),this.d=xC+this.e+') '+zb(this.c)+this.b,undefined);return this.d};_.b=uC;_.c=null;_.d=null;_.e=null;var Gb,Hb;$l(22,1,{});var Nb=0,Ob=0,Pb=0,Qb=-1;$l(24,22,{},hc);_.b=null;_.c=null;_.d=null;_.e=false;_.f=null;_.g=null;_.i=null;_.j=false;var $b;$l(25,1,{},oc);_.x=function pc(){this.b.e=true;cc(this.b);this.b.e=false;return this.b.j=dc(this.b)};_.b=null;$l(26,1,{},rc);_.x=function sc(){this.b.e&&mc(this.b.f,1);return this.b.j};_.b=null;$l(29,1,{},Ac);_.z=function Bc(){var a={};var b=[];var c=arguments.callee.caller.caller;while(c){var d=this.A(c.toString());b.push(d);var e=BC+d;var f=a[e];if(f){var g,h;for(g=0,h=f.length;g<h;g++){if(f[g]===c){return b}}}(f||(a[e]=[])).push(c);c=c.caller}return b};_.A=function Cc(a){return tc(a)};_.B=function Dc(a){return []};$l(31,29,{});_.z=function Hc(){return wc(this.B(zc()),this.C())};_.B=function Ic(a){return Gc(this,a)};_.C=function Jc(){return 2};$l(30,31,{});_.z=function Qc(){return Lc(this)};_.A=function Rc(a){var b,c,d,e;if(a.length==0){return AC}e=mx(a);e.indexOf('at ')==0&&(e=lx(e,3));c=e.indexOf(EC);c!=-1&&(e=mx(e.substr(0,c-0))+mx(lx(e,e.indexOf(FC,c)+1)));c=e.indexOf(xC);if(c==-1){d=e;e=uC}else{b=e.indexOf(GC,c);d=e.substr(c+1,b-(c+1));e=mx(e.substr(0,c-0))}c=hx(e,qx(46));c!=-1&&(e=lx(e,c+1));return (e.length>0?e:AC)+CC+d};_.B=function Sc(a){return Oc(this,a)};_.C=function Tc(){return 3};$l(32,30,{},Vc);$l(33,1,{});$l(34,33,{},$c);_.b=uC;$l(49,1,{39:1,42:1,44:1});_.eQ=function xd(a){return this===a};_.hC=function yd(){return Wb(this)};_.tS=function zd(){return this.c};_.c=null;$l(48,49,ZB);var Ad,Bd,Cd,Dd,Ed;$l(50,48,ZB,Id);$l(51,48,ZB,Kd);$l(52,48,ZB,Md);$l(53,48,ZB,Od);var Pd,Qd=false,Rd,Sd,Td;$l(55,1,{},Zd);_.y=function $d(){(Ud(),Qd)&&Vd()};$l(56,1,{},ge);_.b=null;var ae;$l(62,1,{});_.tS=function ne(){return 'An event type'};_.j=null;$l(61,62,{});_.i=false;$l(60,61,{});_.E=function te(){return this.F()};_.b=null;_.c=null;var pe=null;$l(59,60,{});$l(58,59,{});$l(57,58,{},we);_.D=function xe(a){wv(nh(nh(a,5),38).b.b)};_.F=function ye(){return ue};var ue;$l(65,1,{});_.hC=function De(){return this.d};_.tS=function Ee(){return 'Event type'};_.d=0;var Ce=0;$l(64,65,{},Fe);$l(63,64,{6:1},Ge);_.b=null;_.c=null;$l(67,60,{});$l(66,67,{});$l(68,66,{},Me);_.D=function Ne(a){nh(a,7).G(this)};_.F=function Oe(){return Ke};var Ke;$l(69,1,{},Se);_.b=null;$l(71,61,{},Ve);_.D=function We(a){nh(a,8).H(this)};_.E=function Ye(){return Ue};var Ue=null;$l(72,61,{});_.D=function _e(a){uh(a);null.Db()};_.E=function af(){return $e};var $e=null;$l(73,1,$B,ef);_.b=null;_.c=null;$l(76,1,{});$l(75,76,{});_.b=null;_.c=0;_.d=false;$l(74,75,{},tf);$l(77,1,{},vf);_.b=null;$l(79,13,_B,yf);_.b=null;$l(78,79,_B,Bf);$l(80,1,aC,Df);_.G=function Ef(a){};$l(82,1,{});_.J=function Hf(){return null};_.K=function If(){return null};_.L=function Jf(){return null};_.M=function Kf(){return null};$l(81,82,{12:1},Of,Pf);_.eQ=function Qf(a){if(!ph(a,12)){return false}return this.b==nh(a,12).b};_.I=function Rf(){return Vf};_.hC=function Sf(){return Wb(this.b)};_.J=function Tf(){return this};_.tS=function Uf(){return Nf(this)};_.b=null;$l(83,82,{},$f);_.I=function _f(){return cg};_.K=function ag(){return this};_.tS=function bg(){return dw(),uC+this.b};_.b=false;var Xf,Yf;$l(84,13,YB,eg,fg);$l(85,82,{},jg);_.I=function kg(){return mg};_.tS=function lg(){return vC};var hg;$l(86,82,{13:1},og);_.eQ=function pg(a){if(!ph(a,13)){return false}return this.b==nh(a,13).b};_.I=function qg(){return tg};_.hC=function rg(){return th((new xw(this.b)).b)};_.tS=function sg(){return this.b+uC};_.b=0;$l(87,82,{14:1},Ag,Bg);_.eQ=function Cg(a){if(!ph(a,14)){return false}return this.b==nh(a,14).b};_.I=function Dg(){return Hg};_.hC=function Eg(){return Wb(this.b)};_.L=function Fg(){return this};_.tS=function Gg(){var a,b,c,d,e,f;f=new Cx;f.b.b+=MC;a=true;e=vg(this,dh(pl,XB,1,0,0));for(c=0,d=e.length;c<d;++c){b=e[c];a?(a=false):(f.b.b+=NC,f);Bx(f,Lb(b));f.b.b+=BC;Ax(f,wg(this,b))}f.b.b+=OC;return f.b.b};_.b=null;var Ig;$l(89,82,{15:1},Ug);_.eQ=function Vg(a){if(!ph(a,15)){return false}return gx(this.b,nh(a,15).b)};_.I=function Wg(){return $g};_.hC=function Xg(){return xx(this.b)};_.M=function Yg(){return this};_.tS=function Zg(){return Lb(this.b)};_.b=null;$l(90,1,{},_g);_.qI=0;var gh,hh;var sl=null;var Fl=null;var Rl,Sl,Tl,Ul;$l(99,1,{16:1},Xl);$l(104,1,{},dm);_.b=0;_.c=0;_.d=0;_.e=null;$l(105,1,bC,fm);_.N=function gm(){return this.b};_.eQ=function hm(a){if(!ph(a,17)){return false}return gx(this.b,nh(a,17).N())};_.hC=function im(){return xx(this.b)};_.b=null;$l(106,1,{},lm);$l(107,1,bC,nm);_.N=function om(){return this.b};_.eQ=function pm(a){if(!ph(a,17)){return false}return gx(this.b,nh(a,17).N())};_.hC=function qm(){return xx(this.b)};_.b=null;var rm,sm,tm,um,vm;$l(109,1,{18:1,19:1},zm);_.eQ=function Am(a){if(!ph(a,18)){return false}return gx(this.b,nh(nh(a,18),19).b)};_.hC=function Bm(){return xx(this.b)};_.b=null;$l(111,1,{},Hm);_.b=null;var Em=null,Fm=null;$l(112,1,{},Km);$l(115,1,{});$l(116,1,{},Qm);var Pm=null;$l(117,115,{},Tm);var Sm=null;$l(118,1,{},Wm);_.b=null;_.c=null;var Xm=null;$l(120,1,{},an);_.b=null;_.c=null;_.d=null;$l(124,1,{23:1,28:1});_.O=function jn(){throw new Lx};_.tS=function mn(){if(!this.v){return '(null handle)'}return this.v.outerHTML};_.v=null;$l(123,124,cC);_.P=function vn(){};_.Q=function wn(){};_.R=function xn(){return this.r};_.S=function yn(){qn(this)};_.T=function zn(a){rn(this,a)};_.U=function An(){if(!this.R()){throw new Fw("Should only call onDetach when the widget is attached to the browser's document")}try{this.W()}finally{try{this.Q()}finally{this.v.__listener=null;this.r=false}}};_.V=function Bn(){};_.W=function Cn(){};_.X=function Dn(a){tn(this,a)};_.r=false;_.s=0;_.t=null;_.u=null;$l(122,123,dC);_.R=function Gn(){return Fn(this)};_.S=function Hn(){if(this.s!=-1){un(this.q,this.s);this.s=-1}this.q.S();this.v.__listener=this};_.T=function In(a){rn(this,a);this.q.T(a)};_.U=function Jn(){try{this.W()}finally{this.q.U()}};_.O=function Kn(){fn(this,this.q.O());return this.v};_.q=null;$l(121,122,eC);_.Y=function _n(){return xp(this.o)};_.T=function ao(a){var b,c,d,e;!Co&&(Co=new Mo);if(this.k){return}b=rd(a);if(!ld(b)){return}d=b;if(!od(this.v,b)){return}rn(this,a);this.q.T(a);c=a.type;if(gx(aD,c)){this.j=true;To(this)}else if(gx(bD,c)){this.j=false;e=Qo(this);!!e&&id(e,eD)}else gx(cD,c)?(this.j=true):gx(dD,c)&&(!Co&&(Co=new Mo),Do(Co,d))&&(this.j=true);So(this,a)};_.W=function bo(){this.j=false};_.Z=function fo(a,b){Dp(this.o,a,b)};_.$=function go(a,b){Ep(this.o,a,b)};_.j=false;_.k=false;_.n=null;_.o=null;_.p=0;var Ln=null;$l(125,123,cC,io);_.b=null;$l(126,1,fC,lo);_._=function mo(a){var b,c,d,e,f,g,h;d=a.g;b=a.g.type;if(gx(cD,b)&&!a.e){switch(d.keyCode||0){case 40:ko(this,up(this.b.o)+1);a.d=true;a.g.preventDefault();return;case 38:ko(this,up(this.b.o)-1);a.d=true;a.g.preventDefault();return;case 34:g=this.b.o.d;(Zp(),Wp)==g?ko(this,xp(this.b.o).b):Yp==g&&ko(this,up(this.b.o)+30);a.d=true;a.g.preventDefault();return;case 33:h=this.b.o.d;(Zp(),Wp)==h?ko(this,-xp(this.b.o).b):Yp==h&&ko(this,up(this.b.o)-30);a.d=true;a.g.preventDefault();return;case 36:ko(this,-xp(this.b.o).c);a.d=true;a.g.preventDefault();return;case 35:ko(this,tp(this.b.o).j-1);a.d=true;a.g.preventDefault();return;case 32:a.d=true;a.g.preventDefault();return;}}else if(gx(JC,b)){e=a.b.b-xp(this.b.o).c;f=rd(a.g);c=(!Co&&(Co=new Mo),Do(Co,f));Tn(this.b,e,!c)}else if(gx(aD,b)){e=a.b.b-xp(this.b.o).c;if(up(this.b.o)!=e){Tn(this.b,a.b.b,false);return}}};_.b=null;$l(127,1,{},vo);_.b=null;_.c=false;$l(128,1,{},xo);_.y=function yo(){var a;if(!Wo(this.b.b)){a=Qo(this.b.b);!!a&&(a.focus(),undefined)}};_.b=null;$l(129,72,{},Ao);$l(130,1,{});_.c=null;var Co=null;$l(131,130,{});_.b=null;var Go=null;$l(132,131,{},Mo);$l(133,121,eC,Yo);_.P=function $o(){var a,b;try{this.g.S()}catch(a){a=rl(a);if(ph(a,52)){b=a;throw new Dr(vA(b))}else throw a}};_.Q=function _o(){var a,b;try{this.g.U()}catch(a){a=rl(a);if(ph(a,52)){b=a;throw new Dr(vA(b))}else throw a}};_.b=null;_.c=false;_.d=null;_.i=null;var Oo=null;$l(134,1,{},bp);_.y=function cp(){Rn(this.b)};_.b=null;$l(135,1,{},gp);var ep=null,fp=null;$l(136,1,{},jp);_.b=false;$l(140,1,{11:1,32:1},Hp);_.Y=function Ip(){return xp(this)};_.Z=function Jp(a,b){Dp(this,a,b)};_.$=function Kp(a,b){Ep(this,a,b)};_.b=null;_.c=false;_.f=null;_.g=null;_.i=0;_.j=null;_.k=null;$l(141,1,{},Np);_.y=function Op(){this.b.g==this&&zp(this.b,null)};_.b=null;$l(142,1,{},Rp);_.e=0;_.f=null;_.g=0;_.i=0;_.j=0;_.k=false;_.p=null;_.q=false;$l(143,142,{},Tp);_.b=false;_.c=false;$l(144,49,{20:1,39:1,42:1,44:1},$p);_.b=false;var Vp,Wp,Xp,Yp;$l(145,49,{21:1,39:1,42:1,44:1},gq);var bq,cq,dq,eq;$l(146,61,{},lq);_.D=function mq(a){uh(a);null.Db()};_.E=function nq(){return jq};var jq;$l(147,1,{},pq);var qq,rq,sq;var uq=null,vq=null;var Bq;$l(153,1,gC,Eq);_.H=function Fq(a){while((Cq(),Bq).c>0){uh(Wz(Bq,0)).Db()}};var Gq=false,Hq=null;$l(155,61,{},Pq);_.D=function Qq(a){uh(a);null.Db()};_.E=function Rq(){return Nq};var Nq;$l(156,73,$B,Tq);var Uq=false;var Zq=null,$q=null,_q=null,ar=null,br=null,cr=null;$l(162,123,hC);_.P=function nr(){Er(this,(Cr(),Ar))};_.Q=function or(){Er(this,(Cr(),Br))};$l(161,162,hC);_.bb=function ur(){return new xt(this.c)};_.ab=function vr(a){return sr(this,a)};$l(160,161,hC);_.ab=function yr(a){var b;b=sr(this,a);b&&xr(a.v);return b};$l(163,78,_B,Dr);var Ar,Br;$l(164,1,{},Gr);_.cb=function Hr(a){a.S()};$l(165,1,{},Jr);_.cb=function Kr(a){a.U()};$l(168,123,cC);_.S=function Or(){var a;qn(this);a=qd(this.v);-1==a&&(this.v.tabIndex=0,undefined)};$l(167,168,cC);$l(166,167,cC,Rr);$l(169,161,hC,Wr);_.ab=function Xr(a){var b,c;b=nd(a.v);c=sr(this,a);if(c){a.v.style[BD]=uC;a.v.style[DD]=uC;ln(a.v,true);dd(this.v,b);this.b==a&&(this.b=null)}return c};_.b=null;var Tr=null;$l(170,3,{},_r);_.b=null;_.c=null;_.d=false;_.e=null;$l(171,161,hC,ds);$l(173,160,iC);var ms,ns,os;$l(174,1,{},ws);_.cb=function xs(a){a.R()&&a.U()};$l(175,1,gC,zs);_.H=function As(a){ss()};$l(176,173,iC,Cs);$l(177,162,hC,Fs);_.bb=function Hs(){return new Ls};_.ab=function Is(a){return Es(this,a)};_.b=null;$l(178,1,{},Ls);_.db=function Ms(){return false};_.eb=function Ns(){return Ks()};_.fb=function Os(){};$l(181,168,cC);_.T=function Ts(a){var b;b=Vq(a.type);(b&896)!=0?rn(this,a):rn(this,a)};_.V=function Us(){};$l(180,181,cC);$l(179,180,cC);$l(182,49,jC);var Ys,Zs,$s,_s,at;$l(183,182,jC,et);$l(184,182,jC,gt);$l(185,182,jC,it);$l(186,182,jC,kt);$l(187,1,{},st);_.bb=function tt(){return new xt(this)};_.b=null;_.c=null;_.d=0;$l(188,1,{},xt);_.db=function yt(){return this.b<this.c.d-1};_.eb=function zt(){return vt(this)};_.fb=function At(){wt(this)};_.b=-1;_.c=null;$l(191,1,{});_.d=-1;_.e=false;$l(192,1,{10:1,34:1},It);_.b=null;_.c=null;$l(193,61,{},Lt);_.D=function Mt(a){nh(a,31)._(this)};_.E=function Ot(){return Kt};_.b=null;_.c=null;_.d=false;_.e=false;_.f=false;_.g=null;var Kt=null;$l(194,1,fC,Qt);_._=function Rt(a){var b;if(a.e||a.f){return}b=a.c;b.o;return};$l(195,191,{},Ut);_.b=null;$l(196,1,kC,du,eu);_.gb=function fu(a){return Xt(this,a)};_.hb=function gu(a){return Yt(this,a)};_.ib=function hu(){Zt(this)};_.jb=function iu(a){return this.g.jb(a)};_.eQ=function ju(a){return this.g.eQ(a)};_.kb=function ku(a){return this.g.kb(a)};_.hC=function lu(){return this.g.hC()};_.lb=function mu(a){return this.g.lb(a)};_.mb=function nu(){return this.g.mb()};_.bb=function ou(){return new Cu(this)};_.nb=function pu(){return new Cu(this)};_.ob=function qu(a){return new Du(this,a)};_.pb=function ru(a){return bu(this,a)};_.qb=function su(a){return cu(this,a)};_.rb=function tu(){return this.g.rb()};_.sb=function uu(a,b){return new eu(this.o,this.g.sb(a,b),this,a)};_.tb=function vu(){return this.g.tb()};_.b=0;_.c=null;_.d=false;_.f=false;_.g=null;_.i=-2147483648;_.j=2147483647;_.k=false;_.n=0;_.o=null;$l(197,1,{},xu);_.y=function yu(){this.b.f=false;if(this.b.d){this.b.d=false;return}_t(this.b)};_.b=null;$l(198,1,{},Cu,Du);_.db=function Eu(){return this.b<this.d.g.rb()};_.ub=function Fu(){return this.b>0};_.eb=function Gu(){return Au(this)};_.vb=function Hu(){if(this.b<=0){throw new RB}return au(this.d,this.c=--this.b)};_.fb=function Iu(){Bu(this)};_.b=0;_.c=-1;_.d=null;$l(199,1,{33:1,39:1},Ku);_.eQ=function Lu(a){var b;if(!ph(a,33)){return false}b=nh(a,33);return this.c==b.c&&this.b==b.b};_.hC=function Mu(){return this.b*31^this.c};_.tS=function Nu(){return 'Range('+this.c+LC+this.b+GC};_.b=0;_.c=0;$l(200,61,{},Ru);_.D=function Su(a){Qu(nh(a,34))};_.E=function Uu(){return Pu};var Pu=null;$l(201,1,{},Xu);_.b=null;_.c=null;_.d=null;$l(202,1,lC,Zu);_.y=function $u(){lf(this.b,this.d,this.c)};_.b=null;_.c=null;_.d=null;$l(203,1,lC,av);_.y=function bv(){nf(this.b,this.d,this.c)};_.b=null;_.c=null;_.d=null;$l(205,179,cC,dv);$l(206,8,{},mv);_.b=false;_.c=null;$l(208,1,{37:1},sv,tv);_.b=false;_.c=null;_.d=null;$l(209,1,{},Dv);_.b=false;_.d=null;$l(210,1,{},Gv);_.b=null;$l(211,122,dC,Mv);_.b=null;_.c=null;_.d=null;_.e=null;_.f=null;_.g=null;_.i=null;_.k=null;$l(212,1,{22:1},Ov);_.T=function Pv(a){Fv(this.c,!!this.b.k.checked)};_.b=null;_.c=null;$l(213,1,aC,Rv);_.G=function Sv(a){(a.b.keyCode||0)==13&&vv(this.b.b)};_.b=null;$l(214,1,{5:1,10:1,38:1},Uv);_.b=null;$l(215,1,{},Xv);_.b=null;_.c=null;_.d=null;_.e=null;_.f=null;_.g=null;_.i=null;_.j=null;_.k=null;_.n=null;_.o=null;_.p=null;_.q=null;$l(217,13,YB,_v);$l(218,13,YB,bw);$l(219,1,{39:1,40:1,42:1},ew);_.eQ=function fw(a){return ph(a,40)&&nh(a,40).b==this.b};_.hC=function gw(){return this.b?1231:1237};_.tS=function hw(){return this.b?fD:'false'};_.b=false;$l(221,1,{},kw);_.tS=function rw(){return ((this.b&2)!=0?'interface ':(this.b&1)!=0?uC:'class ')+this.d};_.b=0;_.c=0;_.d=null;$l(222,13,YB,tw);$l(224,1,{39:1,49:1});$l(223,224,{39:1,42:1,43:1,49:1},xw);_.eQ=function yw(a){return ph(a,43)&&nh(a,43).b==this.b};_.hC=function zw(){return th(this.b)};_.tS=function Aw(){return uC+this.b};_.b=0;$l(225,13,YB,Cw);$l(226,13,YB,Ew,Fw);$l(227,13,{39:1,46:1,47:1,50:1,52:1},Hw,Iw);$l(228,224,{39:1,42:1,48:1,49:1},Kw);_.eQ=function Lw(a){return ph(a,48)&&nh(a,48).b==this.b};_.hC=function Mw(){return this.b};_.tS=function Qw(){return uC+this.b};_.b=0;var Sw;$l(231,13,YB,Xw,Yw);var Zw;$l(233,225,YB,ax);$l(234,1,{39:1,51:1},cx);_.tS=function dx(){return this.b+'.'+this.e+xC+(this.c!=null?this.c:'Unknown Source')+(this.d>=0?BC+this.d:uC)+GC};_.b=null;_.c=null;_.d=0;_.e=null;_=String.prototype;_.cM={1:1,39:1,41:1,42:1};_.eQ=function px(a){return gx(this,a)};_.hC=function rx(){return xx(this)};_.tS=_.toString;var sx,tx=0,ux;$l(236,1,mC,Cx);_.tS=function Dx(){return this.b.b};$l(237,1,mC,Hx,Ix);_.tS=function Jx(){return this.b.b};$l(238,13,{39:1,46:1,50:1,52:1,53:1},Lx,Mx);$l(239,1,{});_.gb=function Qx(a){throw new Mx('Add not supported on this collection')};_.hb=function Rx(a){var b,c;c=a.bb();b=false;while(c.db()){this.gb(c.eb())&&(b=true)}return b};_.jb=function Sx(a){var b;b=Ox(this.bb(),a);return !!b};_.mb=function Tx(){return this.rb()==0};_.qb=function Ux(a){var b;b=Ox(this.bb(),a);if(b){b.fb();return true}else{return false}};_.tb=function Vx(){return this.wb(dh(nl,XB,0,this.rb(),0))};_.wb=function Wx(a){var b,c,d;d=this.rb();a.length<d&&(a=bh(a,d));c=this.bb();for(b=0;b<d;++b){fh(a,b,c.eb())}a.length>d&&fh(a,d,null);return a};_.tS=function Xx(){return Px(this)};$l(241,1,nC);_.eQ=function _x(a){var b,c,d,e,f;if(a===this){return true}if(!ph(a,56)){return false}e=nh(a,56);if(this.e!=e.e){return false}for(c=new Hy((new zy(e)).b);nz(c.b);){b=c.c=nh(oz(c.b),57);d=b.yb();f=b.zb();if(!(d==null?this.d:ph(d,1)?BC+nh(d,1) in this.f:jy(this,d,~~Db(d)))){return false}if(!SB(f,d==null?this.c:ph(d,1)?iy(this,nh(d,1)):hy(this,d,~~Db(d)))){return false}}return true};_.hC=function ay(){var a,b,c;c=0;for(b=new Hy((new zy(this)).b);nz(b.b);){a=b.c=nh(oz(b.b),57);c+=a.hC();c=~~c}return c};_.tS=function by(){var a,b,c,d;d=MC;a=false;for(c=new Hy((new zy(this)).b);nz(c.b);){b=c.c=nh(oz(c.b),57);a?(d+=NC):(a=true);d+=uC+b.yb();d+=RD;d+=uC+b.zb()}return d+OC};$l(240,241,nC);_.xb=function ty(a,b){return sh(a)===sh(b)||a!=null&&Cb(a,b)};_.b=null;_.c=null;_.d=false;_.e=0;_.f=null;$l(243,239,oC);_.eQ=function wy(a){var b,c,d;if(a===this){return true}if(!ph(a,58)){return false}c=nh(a,58);if(c.rb()!=this.rb()){return false}for(b=c.bb();b.db();){d=b.eb();if(!this.jb(d)){return false}}return true};_.hC=function xy(){var a,b,c;a=0;for(b=this.bb();b.db();){c=b.eb();if(c!=null){a+=Db(c);a=~~a}}return a};$l(242,243,oC,zy);_.jb=function Ay(a){return yy(this,a)};_.bb=function By(){return new Hy(this.b)};_.qb=function Cy(a){var b;if(yy(this,a)){b=nh(a,57).yb();py(this.b,b);return true}return false};_.rb=function Dy(){return this.b.e};_.b=null;$l(244,1,{},Hy);_.db=function Iy(){return nz(this.b)};_.eb=function Jy(){return Fy(this)};_.fb=function Ky(){Gy(this)};_.b=null;_.c=null;_.d=null;$l(246,1,pC);_.eQ=function Ny(a){var b;if(ph(a,57)){b=nh(a,57);if(SB(this.yb(),b.yb())&&SB(this.zb(),b.zb())){return true}}return false};_.hC=function Oy(){var a,b;a=0;b=0;this.yb()!=null&&(a=Db(this.yb()));this.zb()!=null&&(b=Db(this.zb()));return a^b};_.tS=function Py(){return this.yb()+RD+this.zb()};$l(245,246,pC,Qy);_.yb=function Ry(){return null};_.zb=function Sy(){return this.b.c};_.Ab=function Ty(a){return ny(this.b,a)};_.b=null;$l(247,246,pC,Vy);_.yb=function Wy(){return this.b};_.zb=function Xy(){return iy(this.c,this.b)};_.Ab=function Yy(a){return oy(this.c,this.b,a)};_.b=null;_.c=null;$l(248,239,kC);_.Bb=function $y(a,b){throw new Mx('Add not supported on this list')};_.gb=function _y(a){this.Bb(this.rb(),a);return true};_.ib=function bz(){this.Cb(0,this.rb())};_.eQ=function cz(a){var b,c,d,e,f;if(a===this){return true}if(!ph(a,55)){return false}f=nh(a,55);if(this.rb()!=f.rb()){return false}d=new qz(this);e=f.bb();while(d.c<d.e.rb()){b=oz(d);c=e.eb();if(!(b==null?c==null:Cb(b,c))){return false}}return true};_.hC=function dz(){var a,b,c;b=1;a=new qz(this);while(a.c<a.e.rb()){c=oz(a);b=31*b+(c==null?0:Db(c));b=~~b}return b};_.lb=function ez(a){var b,c;for(b=0,c=this.rb();b<c;++b){if(a==null?this.kb(b)==null:Cb(a,this.kb(b))){return b}}return -1};_.bb=function gz(){return new qz(this)};_.nb=function hz(){return new vz(this,0)};_.ob=function iz(a){return new vz(this,a)};_.pb=function jz(a){throw new Mx('Remove not supported on this list')};_.Cb=function kz(a,b){var c,d;d=new vz(this,a);for(c=a;c<b;++c){oz(d);pz(d)}};_.sb=function lz(a,b){return new zz(this,a,b)};$l(249,1,{},qz);_.db=function rz(){return nz(this)};_.eb=function sz(){return oz(this)};_.fb=function tz(){pz(this)};_.c=0;_.d=-1;_.e=null;$l(250,249,{},vz);_.ub=function wz(){return this.c>0};_.vb=function xz(){if(this.c<=0){throw new RB}return this.b.kb(this.d=--this.c)};_.b=null;$l(251,248,kC,zz);_.Bb=function Az(a,b){az(a,this.c+1);++this.c;this.d.Bb(this.b+a,b)};_.kb=function Bz(a){az(a,this.c);return this.d.kb(this.b+a)};_.pb=function Cz(a){var b;az(a,this.c);b=this.d.pb(this.b+a);--this.c;return b};_.rb=function Dz(){return this.c};_.b=0;_.c=0;_.d=null;$l(252,243,oC,Gz);_.jb=function Hz(a){return fy(this.b,a)};_.bb=function Iz(){return Fz(this)};_.rb=function Jz(){return this.c.b.e};_.b=null;_.c=null;$l(253,1,{},Mz);_.db=function Nz(){return nz(this.b.b)};_.eb=function Oz(){return Lz(this)};_.fb=function Pz(){Gy(this.b)};_.b=null;$l(254,248,qC,aA,bA);_.Bb=function cA(a,b){Sz(this,a,b)};_.gb=function dA(a){return Tz(this,a)};_.hb=function eA(a){return Uz(this,a)};_.ib=function fA(){Vz(this)};_.jb=function gA(a){return Xz(this,a,0)!=-1};_.kb=function hA(a){return Wz(this,a)};_.lb=function iA(a){return Xz(this,a,0)};_.mb=function jA(){return this.c==0};_.pb=function kA(a){return Yz(this,a)};_.qb=function lA(a){return Zz(this,a)};_.Cb=function mA(a,b){var c;az(a,this.c);(b<a||b>this.c)&&fz(b,this.c);c=b-a;oA(this.b,a,c);this.c-=c};_.rb=function nA(){return this.c};_.tb=function rA(){return ah(this.b,this.c)};_.wb=function sA(a){return _z(this,a)};_.c=0;var tA;$l(256,248,qC,yA);_.jb=function zA(a){return false};_.kb=function AA(a){throw new Hw};_.rb=function BA(){return 0};$l(257,1,{});_.gb=function EA(a){throw new Lx};_.hb=function FA(a){throw new Lx};_.ib=function GA(){throw new Lx};_.jb=function HA(a){return this.c.jb(a)};_.bb=function IA(){return new OA(this.c.bb())};_.qb=function JA(a){throw new Lx};_.rb=function KA(){return this.c.rb()};_.tb=function LA(){return this.c.tb()};_.tS=function MA(){return this.c.tS()};_.c=null;$l(258,1,{},OA);_.db=function PA(){return this.c.db()};_.eb=function QA(){return this.c.eb()};_.fb=function RA(){throw new Lx};_.c=null;$l(259,257,kC,TA);_.eQ=function UA(a){return this.b.eQ(a)};_.kb=function VA(a){return this.b.kb(a)};_.hC=function WA(){return this.b.hC()};_.lb=function XA(a){return this.b.lb(a)};_.mb=function YA(){return this.b.mb()};_.nb=function ZA(){return new cB(this.b.ob(0))};_.ob=function $A(a){return new cB(this.b.ob(a))};_.pb=function _A(a){throw new Lx};_.sb=function aB(a,b){return new TA(this.b.sb(a,b))};_.b=null;$l(260,258,{},cB);_.ub=function dB(){return this.b.ub()};
_.vb=function eB(){return this.b.vb()};_.b=null;$l(261,259,kC,gB);$l(262,257,oC,iB);_.eQ=function jB(a){return this.c.eQ(a)};_.hC=function kB(){return this.c.hC()};$l(263,1,{39:1,42:1,54:1},mB);_.eQ=function nB(a){return ph(a,54)&&Gl(Hl(this.b.getTime()),Hl(nh(a,54).b.getTime()))};_.hC=function oB(){var a;a=Hl(this.b.getTime());return Ol(Ql(a,Ml(a,32)))};_.tS=function qB(){var a,b,c;c=-this.b.getTimezoneOffset();a=(c>=0?'+':uC)+~~(c/60);b=(c<0?-c:c)%60<10?RC+(c<0?-c:c)%60:uC+(c<0?-c:c)%60;return (tB(),rB)[this.b.getDay()]+HC+sB[this.b.getMonth()]+HC+pB(this.b.getDate())+HC+pB(this.b.getHours())+BC+pB(this.b.getMinutes())+BC+pB(this.b.getSeconds())+' GMT'+a+b+HC+this.b.getFullYear()};_.b=null;var rB,sB;$l(265,240,{39:1,56:1},wB,xB);$l(266,243,{39:1,58:1},CB,DB);_.gb=function EB(a){return zB(this,a)};_.jb=function FB(a){return fy(this.b,a)};_.mb=function GB(){return this.b.e==0};_.bb=function HB(){return Fz($x(this.b))};_.qb=function IB(a){return BB(this,a)};_.rb=function JB(){return this.b.e};_.tS=function KB(){return Px($x(this.b))};_.b=null;$l(267,246,pC,MB);_.yb=function NB(){return this.b};_.zb=function OB(){return this.c};_.Ab=function PB(a){var b;b=this.c;this.c=a;return b};_.b=null;_.c=null;$l(268,13,YB,RB);var rC=Tb;var xk=mw(TD,'Object',1),Dh=mw(UD,'JavaScriptObject$',16),nl=lw(VD,'Object;',273),Dk=mw(TD,'Throwable',15),pk=mw(TD,'Exception',14),yk=mw(TD,'RuntimeException',13),zk=mw(TD,'StackTraceElement',234),ol=lw(VD,'StackTraceElement;',275),ti=mw(WD,'LongLibBase$LongEmul',99),hl=lw('[Lcom.google.gwt.lang.','LongLibBase$LongEmul;',276),ui=mw(WD,'SeedUtil',100),ok=mw(TD,'Enum',49),kk=mw(TD,'Boolean',219),wk=mw(TD,'Number',224),fl=lw(uC,'[C',277),mk=mw(TD,'Class',221),nk=mw(TD,'Double',223),tk=mw(TD,'Integer',228),ml=lw(VD,'Integer;',278),Ck=mw(TD,wC,2),pl=lw(VD,'String;',274),lk=mw(TD,'ClassCastException',222),Bk=mw(TD,'StringBuilder',237),jk=mw(TD,'ArrayStoreException',218),Ch=mw(UD,'JavaScriptException',12),yj=mw(XD,'UIObject',124),Hj=mw(XD,'Widget',123),kj=mw(XD,'Composite',122),hk=mw(YD,'ToDoView',211),dk=mw(YD,'ToDoView$1',212),ek=mw(YD,'ToDoView$2',213),fk=mw(YD,'ToDoView$3',214),ck=mw(YD,'ToDoPresenter',209),bk=mw(YD,'ToDoPresenter$1',210),pj=mw(XD,'Panel',162),jj=mw(XD,'ComplexPanel',161),dj=mw(XD,'AbsolutePanel',160),Zj=mw(ZD,$D,79),ji=mw(_D,$D,78),gj=mw(XD,'AttachDetachException',163),ej=mw(XD,'AttachDetachException$1',164),fj=mw(XD,'AttachDetachException$2',165),tj=mw(XD,'RootPanel',173),sj=mw(XD,'RootPanel$DefaultRootPanel',176),qj=mw(XD,'RootPanel$1',174),rj=mw(XD,'RootPanel$2',175),ik=mw(TD,'ArithmeticException',217),Nh=mw(aE,'StringBufferImpl',33),Mi=mw(bE,'AbstractHasData',121),Ii=mw(bE,'AbstractHasData$DefaultKeyboardSelectionHandler',126),Li=mw(bE,'AbstractHasData$View',127),Ji=mw(bE,'AbstractHasData$View$1',128),Uj=mw(ZD,'Event',62),fi=mw(_D,'GwtEvent',61),di=mw(cE,'ValueChangeEvent',72),Ki=mw(bE,'AbstractHasData$View$2',129),Hi=mw(bE,'AbstractHasData$1',125),Yi=nw(bE,'HasKeyboardPagingPolicy$KeyboardPagingPolicy',144,_p),il=lw(dE,'HasKeyboardPagingPolicy$KeyboardPagingPolicy;',279),Zi=nw(bE,'HasKeyboardSelectionPolicy$KeyboardSelectionPolicy',145,hq),jl=lw(dE,'HasKeyboardSelectionPolicy$KeyboardSelectionPolicy;',280),Kj=mw(eE,'CellPreviewEvent',193),Sj=mw(ZD,'Event$Type',65),ei=mw(_D,'GwtEvent$Type',64),Xi=mw(bE,'HasDataPresenter',140),Vi=mw(bE,'HasDataPresenter$DefaultState',142),Wi=mw(bE,'HasDataPresenter$PendingState',143),Ui=mw(bE,'HasDataPresenter$2',141),Eh=mw(UD,'Scheduler',22),Ti=mw(bE,'CellList',133),Qi=mw(bE,'CellList$1',134),nj=mw(XD,'FocusWidget',168),hj=mw(XD,'ButtonBase',167),ij=mw(XD,'Button',166),Ej=mw(XD,'ValueBoxBase',181),wj=mw(XD,'TextBoxBase',180),xj=mw(XD,'TextBox',179),$j=mw(YD,'TextBoxWithPlaceholder',205),Dj=nw(XD,'ValueBoxBase$TextAlignment',182,ct),kl=lw(fE,'ValueBoxBase$TextAlignment;',281),zj=nw(XD,'ValueBoxBase$TextAlignment$1',183,null),Aj=nw(XD,'ValueBoxBase$TextAlignment$2',184,null),Bj=nw(XD,'ValueBoxBase$TextAlignment$3',185,null),Cj=nw(XD,'ValueBoxBase$TextAlignment$4',186,null),ki=mw('com.google.gwt.i18n.client.','AutoDirectionHandler',80),Jj=mw(eE,'AbstractDataProvider',191),Pj=mw(eE,'ListDataProvider',195),Oj=mw(eE,'ListDataProvider$ListWrapper',196),Nj=mw(eE,'ListDataProvider$ListWrapper$WrappedListIterator',198),Mj=mw(eE,'ListDataProvider$ListWrapper$1',197),Ij=mw(eE,'AbstractDataProvider$1',192),Qj=mw(eE,'RangeChangeEvent',200),Sk=mw(gE,'AbstractMap',241),Kk=mw(gE,'AbstractHashMap',240),bl=mw(gE,'HashMap',265),Fk=mw(gE,'AbstractCollection',239),Tk=mw(gE,'AbstractSet',243),Hk=mw(gE,'AbstractHashMap$EntrySet',242),Gk=mw(gE,'AbstractHashMap$EntrySetIterator',244),Rk=mw(gE,'AbstractMapEntry',246),Ik=mw(gE,'AbstractHashMap$MapEntryNull',245),Jk=mw(gE,'AbstractHashMap$MapEntryString',247),Qk=mw(gE,'AbstractMap$1',252),Pk=mw(gE,'AbstractMap$1$1',253),cl=mw(gE,'HashSet',266),Lh=mw(aE,'StackTraceCreator$Collector',29),Kh=mw(aE,'StackTraceCreator$CollectorMoz',31),Jh=mw(aE,'StackTraceCreator$CollectorChrome',30),Ih=mw(aE,'StackTraceCreator$CollectorChromeNoSourceMap',32),Mh=mw(aE,'StringBufferImplAppend',34),Hh=mw(aE,'SchedulerImpl',24),Fh=mw(aE,'SchedulerImpl$Flusher',25),Gh=mw(aE,'SchedulerImpl$Rescuer',26),Ah=mw(hE,'AbstractCell',8),_j=mw(YD,'ToDoCell',206),Bh=mw(hE,'Cell$Context',9),gk=mw(YD,'ToDoView_ToDoViewUiBinderImpl$Widgets',215),rk=mw(TD,'IllegalStateException',226),Bi=mw(iE,'Storage',111),Ai=mw(iE,'Storage$StorageSupportDetector',112),si=mw(jE,'JSONValue',82),li=mw(jE,'JSONArray',81),qi=mw(jE,'JSONObject',87),ri=mw(jE,'JSONString',89),mi=mw(jE,'JSONBoolean',83),ak=mw(YD,'ToDoItem',208),Gj=mw(XD,'WidgetCollection',187),ll=lw(fE,'Widget;',282),Fj=mw(XD,'WidgetCollection$WidgetIterator',188),uk=mw(TD,'NullPointerException',231),qk=mw(TD,'IllegalArgumentException',225),Ok=mw(gE,'AbstractList',248),Uk=mw(gE,'ArrayList',254),Lk=mw(gE,'AbstractList$IteratorImpl',249),Mk=mw(gE,'AbstractList$ListIteratorImpl',250),Nk=mw(gE,'AbstractList$SubList',251),Xh=mw(kE,'DomEvent',60),$h=mw(kE,'KeyEvent',67),Zh=mw(kE,'KeyCodeEvent',66),_h=mw(kE,'KeyUpEvent',68),Wh=mw(kE,'DomEvent$Type',63),Yh=mw(kE,'HumanInputEvent',59),ai=mw(kE,'MouseEvent',58),Vh=mw(kE,'ClickEvent',57),Ek=mw(TD,'UnsupportedOperationException',238),Ak=mw(TD,'StringBuffer',236),bj=mw(lE,'Window$ClosingEvent',155),hi=mw(_D,'HandlerManager',73),cj=mw(lE,'Window$WindowHandlers',156),Tj=mw(ZD,'EventBus',76),Yj=mw(ZD,'SimpleEventBus',75),gi=mw(_D,'HandlerManager$Bus',74),Vj=mw(ZD,'SimpleEventBus$1',201),Wj=mw(ZD,'SimpleEventBus$2',202),Xj=mw(ZD,'SimpleEventBus$3',203),Si=mw(bE,'CellList_Resources_default_InlineClientBundleGenerator',135),Ri=mw(bE,'CellList_Resources_default_InlineClientBundleGenerator$1',136),mj=mw(XD,'DeckPanel',169),zh=mw(mE,'Animation',3),lj=mw(XD,'DeckPanel$SlideAnimation',170),yh=mw(mE,'AnimationScheduler',4),vj=mw(XD,'SimplePanel',177),uj=mw(XD,'SimplePanel$1',178),Pi=mw(bE,'CellBasedWidgetImpl',130),ni=mw(jE,'JSONException',84),ci=mw(cE,'CloseEvent',71),dl=mw(gE,'MapEntryImpl',267),sk=mw(TD,'IndexOutOfBoundsException',227),Vk=mw(gE,'Collections$EmptyList',256),Xk=mw(gE,'Collections$UnmodifiableCollection',257),Zk=mw(gE,'Collections$UnmodifiableList',259),$k=mw(gE,'Collections$UnmodifiableRandomAccessList',261),_k=mw(gE,'Collections$UnmodifiableSet',262),Wk=mw(gE,'Collections$UnmodifiableCollectionIterator',258),Yk=mw(gE,'Collections$UnmodifiableListIterator',260),Oi=mw(bE,'CellBasedWidgetImplStandard',131),Ni=mw(bE,'CellBasedWidgetImplStandardBase',132),oj=mw(XD,'HTMLPanel',171),pi=mw(jE,'JSONNumber',86),oi=mw(jE,'JSONNull',85),bi=mw(kE,'PrivateMap',69),ii=mw(_D,'LegacyHandlerWrapper',77),Rj=mw(eE,'Range',199),el=mw(gE,'NoSuchElementException',268),Lj=mw(eE,'DefaultSelectionEventManager',194),yi=mw(nE,'SafeHtmlString',107),Fi=mw(oE,'LazyDomElement',118),Sh=nw(pE,'Style$Display',48,Gd),gl=lw('[Lcom.google.gwt.dom.client.','Style$Display;',283),Oh=nw(pE,'Style$Display$1',50,null),Ph=nw(pE,'Style$Display$2',51,null),Qh=nw(pE,'Style$Display$3',52,null),Rh=nw(pE,'Style$Display$4',53,null),Gi=mw(oE,'UiBinderUtil$TempAttachment',120),wi=mw(nE,'OnlyToBeUsedInGeneratedCodeStringBlessedAsSafeHtml',105),xi=mw(nE,'SafeHtmlBuilder',106),Uh=mw(pE,'StyleInjector$StyleInjectorImpl',56),Th=mw(pE,'StyleInjector$1',55),_i=mw(bE,'LoadingStateChangeEvent',146),$i=mw(bE,'LoadingStateChangeEvent$DefaultLoadingState',147),vk=mw(TD,'NumberFormatException',233),vi=mw('com.google.gwt.resources.client.impl.','ImageResourcePrototype',104),Ci=mw('com.google.gwt.text.shared.','AbstractRenderer',115),Ei=mw(qE,'PassthroughRenderer',117),Di=mw(qE,'PassthroughParser',116),zi=mw(nE,'SafeUriString',109),al=mw(gE,'Date',263),xh=mw(mE,'AnimationSchedulerImpl',5),vh=mw(mE,'AnimationSchedulerImplTimer',6),aj=mw(lE,'Timer$1',153),wh=mw(mE,'AnimationSchedulerImplWebkit',7);$stats && $stats({moduleName:'gwttodo',sessionId:$sessionId,subSystem:'startup',evtGroup:'moduleStartup',millis:(new Date()).getTime(),type:'moduleEvalEnd'});if (gwttodo && gwttodo.onScriptLoad)gwttodo.onScriptLoad(gwtOnLoad);})();