# Changelog


## 1.0.1 - 2012-10-09

- All main apps have been completely rewritten for consistency
- Routing has been added to many of these
- We now have 30+ apps being worked on in Labs
- We're using a kick-ass new template
- Framework authors and contributors have been consulted to ensure our apps adhere to best practices
- We're helping AMD users by adding AMD versions of many apps
