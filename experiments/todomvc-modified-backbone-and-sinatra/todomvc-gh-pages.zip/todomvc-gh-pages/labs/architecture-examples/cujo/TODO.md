TODO before release
---

* implement filters (using routing or another method)
* build javascript using cram.js
* use curl's preloads feature rather than .next() in run.js
* use a theme.css file
