define({
	title: 'todos',
	todo: {
		placeholder: 'What needs to be done?'
	}
});
