steal("jquery/dom/dimensions",
 	'jquery/view/micro',
 	'funcunit/qunit').then(function(){

module("jquery/dom/dimensions");




test("outerHeight and width",function(){
	$("#qunit-test-area").html("//jquery/dom/dimensions/test/curStyles.micro",{})
})

});