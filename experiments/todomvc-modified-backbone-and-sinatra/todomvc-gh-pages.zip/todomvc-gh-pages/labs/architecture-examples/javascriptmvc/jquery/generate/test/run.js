load("jquery/generate/test/app_plugin_model_controller.js");

load("jquery/generate/test/scaffold.js");
