# Dermis TodoMVC app

A todo app built using [dermis](https://github.com/wearefractal/dermis)

dermis is a tiny framework that provides models, collections, controllers, and data-binding out of the box. dermis is designed to be the simplest possible solution for creating complex applications

## Run

Start the HTTP server and visit http://localhost/labs/architecture-examples/dermis/